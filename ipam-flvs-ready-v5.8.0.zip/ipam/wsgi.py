import click
from app import create_app, db
from app.models import User, Group, Role

app = create_app()


@app.cli.command("create-admin")
@click.argument("username")
@click.argument("email")
@click.password_option()
def create_admin(username, email, password):
    """Create a local admin user. Usage: flask create-admin <username> <email>"""
    with app.app_context():
        if User.query.filter_by(username=username).first():
            click.echo(f"Error: user '{username}' already exists.", err=True)
            raise SystemExit(1)
        user = User(username=username, email=email, display_name=username,
                    role=Role.ADMIN, is_active=True)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        click.echo(f"Admin user '{username}' created successfully.")


@app.cli.command("reset-password")
@click.argument("username")
@click.password_option()
def reset_password(username, password):
    """Set a new password for a local user (e.g. a forgotten admin password)."""
    user = User.query.filter_by(username=username).first()
    if not user:
        click.echo(f"Error: user '{username}' not found.", err=True)
        raise SystemExit(1)
    if user.is_ad_user:
        click.echo("Error: that is an AD account; its password is managed in Active Directory.", err=True)
        raise SystemExit(1)
    if len(password) < 10:
        click.echo("Error: password must be at least 10 characters.", err=True)
        raise SystemExit(1)
    user.set_password(password)
    user.is_active = True
    db.session.commit()
    click.echo(f"Password for '{username}' updated.")


@app.cli.command("create-default-groups")
def create_default_groups():
    """Create the three default IPAM groups."""
    defaults = [
        ("IPAM-Admins",     Role.ADMIN,     "Full administrative access"),
        ("IPAM-ReadWrite",  Role.READWRITE,  "Can create and edit subnets and IPs"),
        ("IPAM-ReadOnly",   Role.READONLY,   "Read-only access"),
    ]
    for name, role, desc in defaults:
        if not Group.query.filter_by(name=name).first():
            db.session.add(Group(name=name, role=role, description=desc))
            click.echo(f"Created group: {name}")
        else:
            click.echo(f"Group already exists: {name}")
    db.session.commit()


@app.cli.command("version")
def version_cmd():
    """Show the installed IPAM version, what it supports, and the database state."""
    from app.version import __version__, RELEASED, FEATURES, CREATOR
    from sqlalchemy import inspect
    click.echo(f"IPAM {__version__} (released {RELEASED}) - created by {CREATOR}")
    for f in FEATURES:
        click.echo(f"  - {f}")
    try:
        insp = inspect(db.engine)
        tables = set(insp.get_table_names())
        need = {"servers", "web_apps", "resource_links", "app_settings", "dns_records"}
        cols = {c["name"] for c in insp.get_columns("ip_addresses")} if "ip_addresses" in tables else set()
        ucols = {c["name"] for c in insp.get_columns("users")} if "users" in tables else set()
        scols = {c["name"] for c in insp.get_columns("servers")} if "servers" in tables else set()
        ok = need <= tables and {"server_id", "interface"} <= cols and "entra_oid" in ucols and "dns_name" in scols
        click.echo("Database: " + ("up to date" if ok else "NEEDS UPGRADE - run: sudo ipam-admin upgrade-db"))
    except Exception as exc:
        click.echo(f"Database: could not check ({exc})")


@app.cli.command("import-runbook")
@click.argument("workbook", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--dry-run", is_flag=True, help="Read everything and show the results, but change nothing.")
@click.option("--report", "report_path", default="/tmp/ipam-runbook-import-report.csv", show_default=True,
              help="Where to write the list of items that need a look.")
def import_runbook(workbook, dry_run, report_path):
    """Import the consolidated runbook (VLANs, servers, IPs, Azure web apps, links)."""
    import csv
    from app.services.schema import upgrade_schema
    from app.services.runbook_import import run_import
    from app.services.audit import log_action
    upgrade_schema()
    report = run_import(workbook, dry_run=dry_run)
    with open(report_path, "w", newline="") as fh:
        csv.writer(fh).writerows(report.to_csv_rows())
    click.echo(("DRY RUN - nothing was saved.\n" if dry_run else "Import complete.\n") + report.summary())
    click.echo(f"\nDetails: {report_path}")
    if not dry_run:
        log_action("IMPORT", "runbook", resource_repr=workbook, details=dict(report.counts))


@app.cli.command("import-dns")
@click.argument("zonefile", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--dry-run", is_flag=True, help="Read everything and show the results, but change nothing.")
@click.option("--zone", default=None, help="DNS zone name (default: worked out from the SOA/NS records, e.g. prod.local).")
@click.option("--no-align", is_flag=True, help="Skip the step that sets DNS names from the server inventory.")
@click.option("--include-public", is_flag=True, help="Also add public (internet) IPs that are not in any IPAM subnet (default: skip them).")
@click.option("--report", "report_path", default="/tmp/ipam-dns-import-report.csv", show_default=True,
              help="Where to write the detailed report.")
def import_dns(zonefile, dry_run, zone, no_align, include_public, report_path):
    """Update IPAM from one DNS zone export (Windows DNS Manager 'Export List' text file). Run once per zone."""
    import csv
    from app.services.schema import upgrade_schema
    from app.services import dns_import
    from app.services.audit import log_action
    upgrade_schema()
    with open(zonefile, encoding="utf-8-sig", errors="replace") as fh:
        text = fh.read()
    report = dns_import.run_import(text, dry_run=dry_run, zone=zone, align=not no_align, include_public=include_public)
    with open(report_path, "w", newline="") as fh:
        csv.writer(fh).writerows(report.to_csv_rows())
    click.echo(("DRY RUN - nothing was saved.\n" if dry_run else "DNS import complete.\n") + f"Zone: {report.zone}\n" + report.summary())
    click.echo(f"\nDetails: {report_path}")
    if not dry_run:
        log_action("IMPORT", "dns_zone", resource_repr=f"{report.zone} ({zonefile})", details=dict(report.counts))


@app.cli.command("dns-reset")
@click.option("--dry-run", is_flag=True, help="Show what would be removed, remove nothing.")
@click.option("--yes", is_flag=True, help="Do not ask for confirmation.")
@click.option("--keep-zone", "keep", multiple=True, help="Leave this zone's records alone (repeatable).")
@click.option("--report", "report_path", default="/tmp/ipam-dns-reset-report.csv", show_default=True)
def dns_reset(dry_run, yes, keep, report_path):
    """Remove what the DNS imports added (DNS records, IPs they created, empty auto-created subnets) to start over."""
    import csv
    from app.services import dns_import
    from app.services.audit import log_action
    from app.services.schema import upgrade_schema
    upgrade_schema()
    if not dry_run and not yes:
        click.confirm("Remove all imported DNS records and the IPs/subnets the DNS imports created?", abort=True)
    report = dns_import.reset_dns(dry_run=dry_run, keep_zones=keep)
    with open(report_path, "w", newline="") as fh:
        csv.writer(fh).writerows(report.to_csv_rows())
    click.echo(("DRY RUN - nothing was removed.\n" if dry_run else "Done.\n") + report.summary())
    click.echo(f"\nDetails: {report_path}")
    if not dry_run:
        log_action("DELETE", "dns_import", resource_repr="DNS import reset", details=dict(report.counts))


@app.cli.command("align-dns-names")
@click.option("--dry-run", is_flag=True, help="Show what would change, change nothing.")
@click.option("--report", "report_path", default="/tmp/ipam-dns-align-report.csv", show_default=True)
def align_dns_names(dry_run, report_path):
    """Set every active server's DNS name to <server name>.<domain> using the zones already imported."""
    import csv
    from app.services import dns_import
    from app.services.audit import log_action
    from app.services.schema import upgrade_schema
    upgrade_schema()
    report = dns_import.run_align(dry_run=dry_run)
    with open(report_path, "w", newline="") as fh:
        csv.writer(fh).writerows(report.to_csv_rows())
    click.echo(("DRY RUN - nothing was saved.\n" if dry_run else "Done.\n") + report.summary())
    click.echo(f"\nDetails: {report_path}")
    if not dry_run:
        log_action("UPDATE", "dns_names", resource_repr="aligned with server names", details=dict(report.counts))


@app.cli.command("data-cleanup")
@click.option("--apply", "do_apply", is_flag=True, help="Make the changes (the default only shows what would change).")
def data_cleanup(do_apply):
    """Safe automatic clean-ups: unify spelling variants and name auto-created subnets."""
    from app.services import data_quality as dq
    from app.services.audit import log_action
    spelling, names = dq.find_spelling_variants(), dq.find_subnet_name_suggestions()
    for v in spelling:
        click.echo(f"  {v['field']}: " + ", ".join(f"'{x}'" for x, _ in v["variants"]) + f" -> '{v['canonical']}'")
    for r in names:
        click.echo(f"  subnet {r['subnet'].network}: '{r['current']}' -> '{r['suggested']}'")
    if not spelling and not names:
        click.echo("Nothing to clean up automatically.")
    elif do_apply:
        n1, n2 = dq.apply_spelling(spelling), dq.apply_subnet_names(names)
        log_action("CLEANUP", "data_quality", resource_repr=f"CLI: {n1} spelling fixes, {n2} subnets renamed")
        click.echo(f"Done: {n1} value(s) unified, {n2} subnet(s) renamed.")
    else:
        click.echo("\nPreview only - run again with --apply to make these changes.")
    s = dq.summary()
    click.echo(f"\nNeeds a person (Admin -> Data Quality): {s['shared_ips']} IPs on two servers, "
               f"{s['unnamed']} servers without a real name, {s['no_ip']} active servers with no IP.")


@app.cli.command("apply-decisions")
@click.argument("worksheet", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--dry-run", is_flag=True, help="Show what would happen without changing anything.")
def apply_decisions_cmd(worksheet, dry_run):
    """Apply a filled-in shared-ips-to-review.csv (decision column: keep / free / give to <server>)."""
    from app.services import data_quality as dq
    from app.services.audit import log_action
    with open(worksheet, "rb") as fh:
        try:
            rows = dq.read_decisions(fh)
        except ValueError as exc:
            click.echo(f"Error: {exc}", err=True)
            raise SystemExit(1)
    results = dq.apply_decisions(rows, dry_run=dry_run)
    for _, _, ok, msg in results:
        click.echo(("  ok    " if ok else "  SKIP  ") + msg)
    done = sum(1 for r in results if r[2])
    click.echo(("DRY RUN - nothing saved. " if dry_run else "") + f"{done} decision(s) {'would be ' if dry_run else ''}applied, "
               f"{len(results) - done} skipped, {len(rows) - len(results)} row(s) left blank.")
    if not dry_run and done:
        log_action("CLEANUP", "data_quality", resource_repr=f"CLI worksheet: {done} decision(s) applied")


@app.cli.command("generate-token")
@click.argument("username")
def generate_token(username):
    """Generate and print a new REST API token for USERNAME."""
    user = User.query.filter_by(username=username).first()
    if not user:
        click.echo(f"Error: user '{username}' not found.", err=True)
        raise SystemExit(1)
    token = user.generate_api_token()
    db.session.commit()
    click.echo(token)


@app.cli.command("ad-test")
def ad_test():
    """Test the AD/LDAP connection using the settings in /etc/ipam/ipam.env."""
    from app.services.ad_auth import ADAuthService
    from app.services import settings_store
    try: settings_store.apply(app)          # settings saved in the GUI override the env file
    except Exception: pass
    result = ADAuthService().test_connection()
    click.echo(("OK: " if result["ok"] else "FAILED: ") + result["message"])
    raise SystemExit(0 if result["ok"] else 1)


@app.cli.command("entra-test")
def entra_test():
    """Test the Microsoft Entra ID app registration (tenant, client id, client secret)."""
    from app.services import entra_auth, settings_store
    try: settings_store.apply(app)
    except Exception: pass
    result = entra_auth.test_connection()
    click.echo(("OK: " if result["ok"] else "FAILED: ") + result["message"])
    raise SystemExit(0 if result["ok"] else 1)


@app.cli.command("init-db")
def init_db():
    """Create database tables (and bring an older database up to date)."""
    from app.services.schema import upgrade_schema
    for line in upgrade_schema():
        click.echo("  " + line)
    click.echo("Database is up to date.")


@app.cli.command("upgrade-db")
def upgrade_db():
    """Add any tables/columns introduced by newer versions. Safe to run repeatedly."""
    from app.services.schema import upgrade_schema
    changes = upgrade_schema()
    for line in changes:
        click.echo("  " + line)
    click.echo("Database upgraded." if changes else "Database already up to date.")


if __name__ == "__main__":
    app.run()
