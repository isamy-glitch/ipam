# IPAM — Network IP Address Manager

A self-hosted, Linux-deployable IPAM system built on Python/Flask + MySQL,
with Active Directory integration, REST API, and full audit logging.

---

## Feature Summary

### IP Management
- **Subnet management** — add, edit, delete IPv4 subnets with CIDR notation
- **Auto-population** — bulk-create all host IP records for a subnet on add
- **IP assignment** — assign/reserve/mark IPs with hostname, MAC, owner, device type, location
- **Auto next-free** — one-click or API-driven assignment of the next available IP
- **IP release** — return IPs to the free pool with full audit trail
- **Search** — global search across all IP addresses by IP, hostname, MAC, owner
- **Utilization tracking** — per-subnet used/free/total counts and % bar
- **CSV export** — per-subnet export for reporting or import elsewhere
- **CSV import** — bulk-load assignments via CSV file

### VLAN Management
- Create and manage VLANs (ID 1–4094) with name, site, and description
- Link subnets to VLANs for topology awareness

### User Management
- **Local accounts** — username/password with bcrypt hashing, min 10-char policy
- **AD/LDAP accounts** — auto-provisioned on first login, role from AD groups
- **Self-service password change** for local accounts
- **Account enable/disable** by admins

### Role-Based Access Control (RBAC)
| Role       | Capabilities                                      |
|------------|---------------------------------------------------|
| admin      | Full access including user, group, and audit mgmt |
| readwrite  | Create/edit/delete subnets, IPs, VLANs            |
| readonly   | View all data, no modifications                   |

- Roles assigned directly on users **or** inherited from group membership
- Highest role wins across all group memberships

### Group Management
- Create named groups with a role assignment
- Assign users to multiple groups
- Map groups to AD group DNs for documentation and auto-role resolution

### Sign in with Microsoft (Entra ID app registration) - recommended
- OpenID Connect through an app registration: no LDAP, no service-account password, MFA / Conditional Access apply
- Roles from App Roles (`IPAM.Admin`, `IPAM.ReadWrite`, `IPAM.ReadOnly`) or Entra group Object IDs, refreshed at every sign-in
- Users created on first sign-in; former LDAP users are linked, local accounts are never taken over
- Configure in the web GUI (**Administration → Sign-in Settings**) or with `sudo ipam-enable-entra`; needs HTTPS (`sudo ipam-enable-https`); guide: [`docs/ENTRA_ID.md`](docs/ENTRA_ID.md)

### Active Directory (LDAP) Integration - legacy alternative
- LDAP/LDAPS bind against any AD domain (defaults and examples use prod.local)
- Service account bind for directory searches
- User DN lookup + password bind for authentication
- Auto-provisioning of AD users on first login
- Role resolved from `memberOf` AD groups on every login
- Configurable admin/readwrite/readonly group names
- Automatic fallback to local auth if AD is unreachable
- Connection test UI in admin panel

### Audit Logging
- Every create, update, delete, login, and logout is logged
- Records: user, action, resource type, resource ID, before/after diff, client IP, timestamp
- Filterable, paginated audit log in the admin UI

### REST API
- Bearer token authentication (generated per-user, configurable expiry)
- Endpoints: subnets, IP addresses, VLANs, next-free, search, assign, update
- PowerShell-compatible (see `docs/API.md`)
- Designed for integration with your existing PowerShell automation scripts

### Dashboard
- Summary cards (Active Subnets, IPs in Use, VLANs) that link to their pages; the IPs card opens IP Search filtered to in-use addresses
- Utilization heat-bar for all subnets
- Recent activity feed

### DNS import - one zone per domain (admin only)
- **Administration → DNS Import**: upload a DNS Manager zone export (right-click the zone → *Export List…*, tab-delimited) for
  **each domain** (prod.local, flvs.net, qa.local - in any order, whenever you have it), **Preview**, then **Apply**.
  CLI: `sudo ipam-admin import-dns /tmp/prod.txt --dry-run`, then without `--dry-run`; repeat per zone.
- Every record is stored per zone and shown on the server and IP pages ("DNS entries"). Re-importing a zone replaces only that zone.
- IPs missing from IPAM are added (a /24 subnet is created if none contains them); existing hostnames are never overwritten
  (conflicts are listed); empty hostnames are filled; dynamic records not refreshed for 30+ days are flagged as possibly stale.
- **Names from the server inventory:** after each import every active server's DNS name becomes `<server name>.<domain>` (on the
  server and on each of its IPs). The domain comes from a domain in the name, the zone holding one of its IPs, or its Environment
  (editable mapping on the page: `Prod Colo=prod.local`, `QA=qa.local`, ...). The report lists **names missing in DNS**, names that
  point at a **different IP**, servers with **no known domain**, and server names that can't be DNS names (spaces, digits only).
  `sudo ipam-admin align-dns-names` (or *Re-check server names*) repeats just this step after you change the mapping.
- IPAM never changes the DNS server. DNS Check then queries the full DNS names.

### Deleting records
- **IP:** Delete button on the subnet's IP list, the IP page and the edit page (Release keeps the row as a free address; Delete removes it). Admins and read/write users.
- **Server:** Delete button on the Servers list and the server page; you choose whether its IPs are kept, released to the free pool, or deleted too. Admins and read/write users.
- Every delete is written to the audit log.

### Server Inventory (from the consolidated runbook)
- **Servers** — every server/appliance with its function, suite, product, technology, OS, environment, VLAN, site,
  host platform, owner and notes; search by name, IP, function, site or notes; filter by suite, environment, status
- Each server's IPs are real IPAM addresses (click through to the subnet); **decommissioned** servers are kept as
  history with their former IPs, which read as free
- **Web Apps** — the Azure web / function / API apps (priority, state, tier, hostnames, resource group, repo)
- **Resources** — the runbook / wiki / vendor-contact links
- CSV export of the server list; read-only API: `GET /api/v1/servers`, `/servers/<id>`, `/apps`
- Load it with `sudo ipam-admin import-runbook` (see *Loading the runbook* below)

### Data Quality (admin only)
- **Admin → Data Quality** — a clean-up work queue for the imported inventory: unify spelling variants, name the
  auto-created subnets, and resolve IPs the runbook lists for more than one server (keep / give to the other / free)
- `sudo ipam-admin data-cleanup` previews the automatic fixes; add `--apply` to make them
- **Decide offline, then import:** fill in the `decision` column of `shared-ips-to-review.csv` with `keep`, `free`
  or `give to <server name>` (blank = leave alone), then either upload it on the Data Quality page (tick *Preview only*
  first) or run `sudo ipam-admin apply-decisions /tmp/shared-ips-to-review.csv --dry-run` and again without `--dry-run`.
  Re-applying the same file is harmless.

### DNS Validation (admin only)
- **Admin → DNS Check** — one page that validates every in-use address that has a hostname
- **Forward:** the name (short names get the subnet's DNS domain appended) must resolve to the IP on record
- **Reverse:** the IP must have a PTR record pointing back at that name
- Filter by subnet, show only problems, jump straight to the record to fix it; each run is audit-logged
- Uses the server's own resolver (so it checks against whatever `/etc/resolv.conf` points at — your AD DNS
  servers on a domain-joined host); runs only when you click *Run DNS check*, capped at 500 records per run

---

## Quick Start

### Requirements
- Ubuntu 22.04/24.04 or RHEL/Rocky/Alma 8/9
- 2 GB RAM minimum, 4 GB recommended
- MySQL 8 (installed by the script)
- Python 3.10+

### Installation

```bash
git clone https://github.com/yourorg/ipam.git
cd ipam
sudo bash scripts/install.sh --domain ipam.prod.local
```

For HTTP-only (internal lab, browsing by IP such as `http://10.50.3.30`):
```bash
sudo bash scripts/install.sh --no-ssl
```
`--no-ssl` also turns off the "Secure" session-cookie flag; without that, browsers silently drop the
login cookie on plain http and every sign-in bounces back to the login page.

### First Admin User

```bash
sudo ipam-admin create-admin admin svc_netipam@prod.local
```

If it says the user already exists, the account is there already: sign in, or set a new password with
`sudo ipam-admin reset-password admin`.

The last argument is just the contact email stored on the account. Keep the *username* as `admin`
(not `svc_netipam`): that name belongs to the AD service account, and a local account with the same
name would be matched to it at AD login and have its role reset to read-only.

`/opt/ipam` is owned by the `ipam` service user and closed to everyone else (mode 750), so you
can't `cd` into it as a normal admin — that's intentional. `ipam-admin` (installed by
`install.sh`) runs IPAM commands as the service user with `/etc/ipam/ipam.env` loaded.
On a server installed before this helper existed, use the long form from any directory:

```bash
sudo -u ipam bash -c 'cd /opt/ipam && set -a && source /etc/ipam/ipam.env && set +a && ./venv/bin/flask --app wsgi create-admin admin svc_netipam@prod.local'
```

### Enable Microsoft (Entra ID) sign-in

Easiest: **Administration → Sign-in Settings** in the web GUI (Entra ID and AD/LDAP cards with Save / Test / Enable; secrets
stored encrypted; no restart). Or from the command line:

```bash
sudo ipam-enable-https     # Microsoft only accepts https redirect addresses
sudo ipam-enable-entra     # tenant ID, client ID, client secret; tests them with Microsoft
```

Create the app registration first - step by step in [`docs/ENTRA_ID.md`](docs/ENTRA_ID.md). Test any time with
`sudo ipam-admin entra-test` or **Administration → Sign-in Status**. The **About** page (sidebar) shows the version and creator.

### Enable AD Integration (LDAP, legacy)

1. In AD, create the service account `svc_netipam` — a normal, **unprivileged** domain user with a
   non-expiring password. It only needs to read users and groups; it does not need local or domain
   admin rights (details in the AD guide).
2. On the IPAM server run `sudo ipam-enable-ad`. It asks for the domain controller name and the
   account password, writes `/etc/ipam/ipam.env`, restarts IPAM and tests the bind.
   (On an older install, run `sudo bash scripts/enable-ad.sh` from the unzipped folder.)
3. Decide who is admin: put people in the AD group `IPAM-Admins`, or list their usernames in
   `AD_ADMIN_USERS` (handy in a lab). Everyone else signs in as read-only or by their AD group.
4. Test any time via **Administration → Sign-in Status**, or `sudo ipam-admin ad-test`.

Full details: [`docs/AD_INTEGRATION.md`](docs/AD_INTEGRATION.md)

---

## Which version is installed?

```bash
sudo ipam-admin version          # version, what it supports, and whether the database needs an upgrade
```

The version is also shown at the bottom of the sidebar and on the login page, and `GET /api/v1/health` returns it.
If the command says `No such command 'version'`, the install is older than 5.3 — run `sudo bash scripts/update.sh`
from the unzipped newer package. `update.sh` prints *installed version -> package version* before it changes anything.

## Loading the runbook (Consolidated_RunBook.xlsx)

```bash
# 1. on an existing install, bring it up to this version first (backs up the database; keeps users + AD settings)
sudo bash scripts/update.sh

# 2. put the workbook where the 'ipam' service user can read it (it cannot read your home folder)
cp ~/Desktop/Consolidated_RunBook.xlsx /tmp/runbook.xlsx && chmod 644 /tmp/runbook.xlsx

# 3. preview, then import
sudo ipam-admin import-runbook /tmp/runbook.xlsx --dry-run
sudo ipam-admin import-runbook /tmp/runbook.xlsx
```

What it does:

| Sheet | Goes to |
|---|---|
| Prod_VLANs | VLANs and their subnets (`Non-Routable` VLANs are kept without a subnet) |
| Main_Servers_Data | Servers (status *active*) and their IP addresses |
| Decomissioned (+ rows marked DECOMMISSIONED / Decom = Yes) | Servers with status *decommissioned*; their IPs are listed as *former IPs* and **not** held |
| Azure_Web_Apps | Web Apps |
| Wiki_References, System_Catalog | Resources |

- IPs outside the listed subnets get an auto-created **/24** tagged `derived-from-runbook` — the mask is a guess, so
  correct those subnets when you know the real range.
- **Public IPs** are stored on the server record (text), not as IP addresses.
- If the same IP is listed for two servers, the first one owns it and the other is noted in the description
  (these are usually VIPs, cluster addresses or old names — see the report).
- Rows with the same server name (e.g. a Nutanix host listed once per network) become **one** server.
- Re-running is safe: runbook-sourced servers/apps/links are refreshed; anything added by hand is left alone.
- Everything odd (typos it repaired, text in IP cells, duplicate IPs...) is written to
  `/tmp/ipam-runbook-import-report.csv` (`--report PATH` to change).

---

## Service Management

```bash
systemctl status ipam          # status
systemctl restart ipam         # restart after config changes
journalctl -u ipam -f          # live logs
tail -f /var/log/ipam/ipam.log # application log
```

---

## File Layout

```
/opt/ipam/               Application root
  app/
    models/              SQLAlchemy models (User, Group, Subnet, IPAddress, VLAN, AuditLog)
    routes/              Flask blueprints (auth, dashboard, subnets, addresses, vlans, admin, api)
    services/            Business logic (ad_auth, audit, ipam)
    templates/           Jinja2 HTML templates
  scripts/install.sh     Installation script
  scripts/enable-ad.sh   AD setup helper (installed as ipam-enable-ad)
  scripts/update.sh      Upgrade an existing install (backup, code, packages, database)
  docs/                  Documentation
  wsgi.py                Entry point + CLI commands
  requirements.txt

/etc/ipam/ipam.env       Environment config (credentials, AD settings)
/var/log/ipam/           Application and access logs
/run/ipam/ipam.sock      Gunicorn UNIX socket
```

## Loading the DNS zones (v5.8)

One command loads every zone export (prod.local, qa.local, flvs.net) - backup, preview, your OK, import, server-name alignment:

```bash
sudo ipam-load-dns --prod "dns prod local.txt" --qa qa-dns.txt --flvs dns-fvs.txt
sudo ipam-load-dns --reset ...        # first remove what earlier DNS imports added, then load again from scratch
sudo ipam-load-dns --preview-only ... # show everything, change nothing
```

Public (internet) addresses in a zone such as flvs.net stay in that zone's DNS records and are not added to IPAM
unless they fall inside an existing IPAM subnet (`--include-public` changes that). `sudo ipam-admin dns-reset` is the
stand-alone undo (DNS records, IPs a DNS import created, empty auto-created subnets; IPs that existed before are kept).

## User guide (v5.8.0)

`docs/` is for administrators; end users have the **User Guide**: a single self-contained HTML file (about 1 MB, screenshots included,
no scripts or external files) plus a PDF copy. Inside IPAM it opens from **User Guide** in the sidebar (`/user-guide`, also
`/user-guide/pdf` and `/user-guide/download`); both files live in `app/docs/` and can be copied to SharePoint or a file share as they are.
