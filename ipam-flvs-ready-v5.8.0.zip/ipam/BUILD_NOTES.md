# Build Notes — IPAM for FLVS

Prepared: August 26, 2026

This package is the app you uploaded, after a full smoke test in a sandboxed
environment (Python 3.11, SQLite standing in for MySQL) — every page and
CRUD flow was exercised end to end, real bugs were fixed, and the results
are recorded below. Nothing here has touched a real FLVS server or AD
domain controller — that step is still ahead of you, and the deployment
guide below is written for it.

---

## What was removed

The uploaded zip contained two different, incompatible generations of the
app bundled together:

1. **The real app** — `app/`, `config/`, `wsgi.py`, `scripts/install.sh`,
   `docs/AD_INTEGRATION.md`, `docs/API.md`, and the top-level `README.md`.
   This is a Flask + SQLAlchemy + MySQL app with proper password hashing,
   CSRF protection, and role-based access. This is what `install.sh` and
   `wsgi.py`'s CLI commands actually run.

2. **An abandoned earlier prototype** — `backend/app.py` (a separate
   single-file Flask+SQLite API using unsalted SHA256 password hashes),
   `frontend/index.html` (a matching SPA), `scripts/ipam-cli.py` (a CLI
   tool built against the prototype's SQLite schema — different table
   columns, different role names), and `docs/README.md` (documentation
   for that prototype). None of this is wired to the real app — `wsgi.py`
   and `install.sh` never reference it — and running it side by side with
   the real app would create a second, insecure, out-of-sync copy of your
   IP data.

I removed all of #2 from this package. If you want the CLI-admin-tool
functionality it hinted at, that's straightforward to add as a proper
`flask` CLI command against the real models — just ask.

Also removed: a handful of empty, oddly-named directories
(e.g. `{app/{models,routes,services,templates,static/{css,js}}...}`) left
behind by a `mkdir -p` that ran under a shell without brace expansion.
Harmless, but cleaned up.

---

## Bugs found and fixed

All of these were found by actually running the app and clicking/curling
through every page and API endpoint — not just reading the code.

1. **REST API crashed on every authenticated request.**
   `api.py`'s token-expiry check compared a timezone-aware "now" against
   the timezone-naive expiry timestamp SQLAlchemy hands back from the
   database, which raises `TypeError: can't compare offset-naive and
   offset-aware datetimes`. This took down `/api/v1/subnets`,
   `/next-free`, `/ips/search` — every GET past the auth decorator.
   Fixed by storing and comparing the expiry consistently as naive UTC.
   This is the single most important fix: the README lists the REST API
   as a primary feature for PowerShell automation, and it was completely
   unusable.

2. **Every write to the REST API was blocked by CSRF protection.**
   Flask-WTF's CSRF protection is global by default and was rejecting
   every POST/PATCH to `/api/v1/*` with "400: The CSRF token is missing"
   — even with a valid Bearer token. CSRF protection exists to stop a
   browser's session cookie being abused cross-site; it doesn't apply to
   Bearer-token API calls, and a PowerShell script has no CSRF token to
   send. Fixed by exempting the API blueprint from CSRF checks.

3. **Admin → Groups page crashed (500).** The template called
   `g.users.count()` assuming a lazy/dynamic relationship, but the
   `Group.users` backref is a plain list, so `.count()` fails. Fixed by
   switching to `{{ g.users|length }}`.

4. **CSV export would fail on IPv6 subnets, even on MySQL in production.**
   It sorted rows using MySQL's `INET_ATON()`, which only understands
   IPv4 — a comment in the code claimed a "fallback" for non-MySQL
   backends that didn't actually exist. Fixed by sorting numerically in
   Python (`ipaddress.ip_address`), which works for IPv4, IPv6, and any
   database backend.

5. **No way to delete a subnet or VLAN from the web UI.** The routes and
   permission checks existed server-side and worked correctly when called
   directly, but no template rendered a delete button — an admin had no
   way to reach that functionality. Added admin-only "Delete Subnet" and
   "Delete VLAN" buttons (with confirmation prompts) to the subnet detail
   page and VLAN list.

## What was verified working, as-is

Login (local), session cookies, RBAC enforcement (a read-only user is
correctly blocked from every write and admin route), subnet creation with
auto-population of host records, IP assignment (both manual and
next-free), IP release, VLAN CRUD, user and group CRUD, audit logging,
API token generation, the full REST API read/write surface once fixed
above, and the AD-unreachable-falls-back-to-local-auth behavior (tested
by pointing `AD_ENABLED=true` at a nonexistent LDAP host — it logs the
LDAP error and falls through to local auth without crashing, exactly as
`docs/AD_INTEGRATION.md` describes).

**Not tested — and can't be, from here:** an actual bind against a real
`prod.local` domain controller. That requires network reachability to your
DC from wherever this runs, which this sandbox doesn't have. The AD code
path itself (service-account bind, user search, password verify, group →
role mapping, disabled-account check) was read carefully and the
unreachable-server failure path was exercised — but do the real
connectivity test (`Administration → AD Integration` in the web UI, or
the `AD_INTEGRATION.md` CLI snippet) once it's on a server that can reach
your DCs, before relying on it.

---

## Deploying this to a real FLVS server

This step needs to happen on an actual Ubuntu/RHEL VM your Infrastructure
team controls — nothing in this sandbox can reach FLVS's network to do it
for you. Once you have a target VM (2 vCPU / 4 GB RAM minimum) reachable
from your DNS/DHCP infrastructure:

```bash
# copy this whole folder to the VM, then:
cd ipam
sudo bash scripts/install.sh --domain ipam.prod.local
```

This provisions MySQL, a Python venv, gunicorn + systemd service, and
nginx with a self-signed cert (swap in a real internal-CA cert afterward
if you want browsers to trust it without a warning).

Then:

```bash
sudo ipam-admin create-admin admin svc_netipam@prod.local
```

(`/opt/ipam` is closed to everyone but the `ipam` service user, so you can't `cd` into it
as a normal admin; `ipam-admin` runs the command as that user with the env file loaded.
If the server was installed before that helper existed, see the long form in `README.md`.)

To turn on AD login, edit `/etc/ipam/ipam.env`:

```
AD_ENABLED=true
AD_SERVER=ldaps://<your-dc-hostname>.prod.local
AD_DOMAIN=prod.local
AD_BASE_DN=DC=prod,DC=local
AD_BIND_USER=svc_netipam@prod.local
AD_BIND_PASS=<service account password>
```

then `systemctl restart ipam`, create the `IPAM-Admins` /
`IPAM-ReadWrite` / `IPAM-ReadOnly` security groups in AD, and use
**Administration → AD Integration** in the web UI to test the connection
before relying on it. Full details in `docs/AD_INTEGRATION.md`.

## Suggested next check before go-live

Run through the go-live checklist in the feature-list document from
earlier in this conversation (strong passwords, HTTPS enforced, AD tested
against a real account, backup script scheduled) — it applies here
unchanged.

---

## Added after the first delivery: DNS Check page

`Administration → DNS Check` (admins only — the sidebar link is hidden from other
roles and the URL returns 403 for them). It validates in-use addresses against live
DNS: forward (name → IP on record) and reverse (PTR → name), with OK / Missing /
Mismatch / Error / Timeout per direction, a subnet filter, a "show only problems"
toggle, an edit link per row, and an audit-log entry per run.

Files: `app/services/dns_check.py` (lookup engine, no Flask dependency),
`app/templates/admin/dns_check.html`, a `dns_check` route at the bottom of
`app/routes/admin.py`, and the link in `app/templates/base.html`.

Tested with a mocked resolver (every status path, IPv6, resolver errors, a slow
resolver that must not hang the page, parallelism), a real lookup against the
sandbox resolver, and page-level tests against the real app (anonymous / read-only /
read-write blocked, admin allowed, link visibility per role, filters, the 500-record
cap, audit logging). **Not testable from the sandbox:** lookups against your real
AD DNS — run it once on the deployed server and spot-check a few rows.

---

## Corrections after the first live install

- **Directory is `prod.local`.** All defaults and examples (`install.sh` env template, docs,
  placeholders) now use `prod.local` / `DC=prod,DC=local`. `dc01.prod.local` is a placeholder:
  set `AD_SERVER` to a real domain controller name.
- **`/opt/ipam` is intentionally not browsable by normal admins** (owned by `ipam`, mode 750).
  The earlier "cd /opt/ipam, then sudo -u ipam ..." instructions were wrong (the `cd` runs as
  you) and also omitted `set -a`, so the env file's settings never reached Flask. New installs get
  `/usr/local/bin/ipam-admin`; use `sudo ipam-admin create-admin|generate-token|ad-test|init-db`.
  On an existing server, see the long form under "First Admin User" in `README.md`.

## Lab server with AD (svc_netipam)

The lab server (`netipam1010`, 10.50.3.30) stays a normal server install; a desktop-only rewrite
was considered and dropped. What changed for the lab:

- **AD login through `svc_netipam@prod.local`.** New `sudo ipam-enable-ad` (source:
  `scripts/enable-ad.sh`) asks for the DC and the password, writes the `AD_*` values (quoted, so
  passwords with `$ # &` survive both systemd and `source`), restarts IPAM and runs the bind test.
- **No local-admin rights for the service account.** Binding and searching need read access only,
  which any domain user has; elevated rights would only add risk. Documented in the AD guide.
- **`AD_ADMIN_USERS`** — usernames that are always IPAM admins, so the lab doesn't need the three AD
  groups first. (Without it, roles are re-read from AD groups at every login, so promoting an AD user
  by hand in the Users page would be undone at their next sign-in.)
- **`AD_CA_FILE`** — trust an internal CA for LDAPS without touching the system trust store.
- **`AD_FALLBACK_LOCAL`** — now a real setting (it was referenced but never defined); default on, so
  the local `admin` account always works.
- **`--no-ssl` login fix** — the production cookie was always `Secure`, so plain-http installs
  couldn't stay logged in. `install.sh --no-ssl` now writes `SESSION_COOKIE_SECURE=false`; existing
  `--no-ssl` installs can add that line to `/etc/ipam/ipam.env` and restart.
- **DNS Check resolver line** — on Ubuntu it showed `127.0.0.53` (systemd-resolved's stub); it now
  shows the real upstream DNS servers.
- Default user/group search base is the whole domain (`DC=prod,DC=local`) instead of `CN=Users`, so
  accounts in OUs are found.
- **502 Bad Gateway after install** — `/run/ipam` was created with mode 0750 (owner `ipam`), but nginx runs as
  `www-data`, so it couldn't reach `ipam.sock` ("connect() ... failed (13: Permission denied)" in
  `/var/log/nginx/error.log`). The service unit now uses `RuntimeDirectoryMode=0755`. On an existing server:
  `sudo sed -i 's/^RuntimeDirectoryMode=.*/RuntimeDirectoryMode=0755/' /etc/systemd/system/ipam.service && sudo systemctl daemon-reload && sudo systemctl restart ipam`.

## Runbook import and server inventory (v5)

**Database changes** (applied by `sudo ipam-admin upgrade-db`, run automatically by `update.sh` and `import-runbook`;
idempotent): new tables `servers`, `web_apps`, `resource_links`; new columns `ip_addresses.server_id` and
`ip_addresses.interface`. Existing data is untouched. (`init-db` now also upgrades an older database.)

**Importer** (`app/services/runbook_import.py`, `flask import-runbook`) — read from the real workbook, not assumed:

- The *Decomissioned* sheet has two layouts. Rows from the old Educator estate have the environment in the VLAN
  column and everything from "Old Name" onward shifted one column left of the headers; they are detected and
  re-mapped (suite, technology, site, host platform, OS).
- VLAN numbers on the main sheet are formulas; 39 evaluate to `#VALUE!`, 4 to `#N/A`. Those are ignored and the VLAN
  is taken from the subnet the IP sits in.
- Typos repaired and reported: `10.60..13.118` -> `10.60.13.118`; `192.168.0.160/` -> `192.168.0.160`;
  a host-bit network (`10.50.127.251/22` -> `10.50.124.0/22`). Text in IP cells (`Squad 1`, `ds`) is kept as a note.
- Row 2's server name is the number `50`; one row has no name at all (recorded as `(unnamed 10.40.3.229)`).
  Names that are device labels with spaces ("Prism Central vIP") are kept as the server name but are **not** put
  into the IP's hostname field, so the DNS Check page doesn't report false failures for them.
- 55 IPs are listed for two (one for three) different servers — 56 extra claims (old and new names, VIPs, chassis modules...). The first server keeps the IP; resolve them in **Admin → Data Quality**.
- Servers marked `Decom = Yes`, notes starting `DECOMMISSIONED`, or Old Name `DECOM` on the main sheet are
  imported as decommissioned. A Decom value of `r` is not understood and is left active (flagged).
- Hand-made changes to a runbook-sourced record are overwritten by a re-import of the same workbook; records
  created in IPAM itself are never touched.

**Also fixed in v5:** `RuntimeDirectoryMode=0755` (nginx 502, see above) is in `install.sh` and `update.sh`;
`update.sh` is the supported way to upgrade a working server (do not re-run `install.sh`: it regenerates the database
password, the secret key and the env file).

## Data cleanup (v5.1)

**Admin -> Data Quality** (and `sudo ipam-admin data-cleanup [--apply]`) — a work queue; nothing changes until an
admin presses a button, and each change is audit-logged (`CLEANUP`).

- *Spelling variants* — values that differ only by case/punctuation (`CentOS 7` / `CentOs 7` / `Centos 7`,
  `VMware vSphere` / `VMWare vSphere`, `IS-DATA` / `IS-Data`, `other` / `Other`...). The most-used spelling wins;
  the copies on the IP rows (tags / device type / location) are kept in step. Also available from the CLI.
- *Auto-created subnets* — the 28 `Imported 10.x.x.0/24` subnets are renamed after the main environment of their
  servers (`QA 10.40.3.0/24`). They stay tagged `derived-from-runbook`; the /24 masks are still guesses. A subnet
  somebody already renamed is never touched. VLAN links are deliberately **not** guessed: the "VLAN" column in the
  workbook is a formula that, for these ranges, just echoes the third octet of the IP.
- *IPs on more than one server* — 55 IPs. Per IP: **Keep owner** (the others are old names / VIPs), **Give to X**
  (swap), or **Free it**. These need someone who knows which server really has the address; the page does not guess.
- *Needs a person* — servers named `50` / `(unnamed ...)`, and active servers with no IP (96 minus those with only a
  public IP). Links go straight to the edit form.
- *Worksheet import (v5.2)* — `shared-ips-to-review.csv` has a `decision` column per IP: `keep`, `free`, `give to <name>`
  (case-insensitive; `give <name>` / `give: <name>` also work); blank rows are skipped; unreadable decisions or names
  that aren't among the servers listed for that IP are reported and left untouched. Comma, semicolon and tab files are
  all read (Excel's regional settings change the delimiter). Upload on the page (with a preview option) or
  `ipam-admin apply-decisions FILE [--dry-run]`.

## Version check (v5.3)

`app/version.py` holds the version. `sudo ipam-admin version` prints it, the features this build has, and whether the
database needs `upgrade-db`; it is also in the sidebar, on the login page, in `/api/v1/health`, and `update.sh` shows
*installed -> package*. Installs older than 5.3 have no `version` command at all, which itself identifies them as old.

- **v5.3.1 — `update.sh` exited silently (exit code 2) on an install that has no `app/version.py`** (any server older than 5.3). The
  version reader's `grep` failed on the missing file and, under `set -e` + `pipefail`, ended the script without a message.
  Fixed; the reader now returns nothing instead of failing.


## Dashboard links (v5.3.2)

The Active Subnets, IPs in Use, IPs Available and VLANs cards on the dashboard are now links (Subnets list, IP Search filtered
to in-use / free, VLANs list). To make the IP cards useful, **IP Search** (`/addresses/search`) gained a status filter
(`?status=in_use|free|assigned|reserved|dhcp`) and now lists matching IPs even with no search text (up to 500, ordered by subnet).

## v5.4.0 - About page, Entra ID sign-in, HTTPS helper

* **About** (`/about`, sidebar > Account; the sidebar version footer links to it): version, release date, creator (ILA Periasamy,
  from `app/version.py` `CREATOR`), sign-in method; admins also see Python/Flask/DB versions and the feature list.
* **Dashboard**: the *IPs Available* card was removed; Active Subnets, IPs in Use and VLANs are links.
* **Entra ID sign-in** (`app/services/entra_auth.py`, routes `/auth/entra/login` + `/auth/entra/callback` in `routes/auth.py`):
  OIDC authorization-code flow with PKCE/state/nonce through `msal` (new dependency). Role from the token's `roles` claim
  (App Roles) or `groups` claim (GUIDs, with Graph `getMemberObjects` fallback on overage). Users keyed on the Entra object id
  (`users.entra_oid`, added by `upgrade-db`). Former LDAP users are linked by name/e-mail; local accounts are never linked.
  `entra-test` / **Sign-in Status** prove tenant+client+secret by requesting an app-only Graph token. LDAP code is untouched.
* `ipam-enable-entra` (writes ENTRA_* to ipam.env, tests) and `ipam-enable-https` (nginx 443 + self-signed or supplied cert,
  secure cookies, rewrites an http redirect URI) - Entra refuses non-https redirect URIs, so a `--no-ssl` install needs the latter.
* Security: `next=` redirects on both login paths now accept same-site relative paths only (was an open redirect on `/login?next=`).
* Not covered by automated tests: the real round-trip to Microsoft (the sandbox has no route to it) - msal is faked in
  `test_entra.py`; run `sudo ipam-admin entra-test` and one real sign-in after setup.

## v5.5.0 - Sign-in settings GUI, delete Server / IP

* **Administration > Sign-in Settings** (`routes/admin.py` `signin_settings*`, template `admin/signin_settings.html`): Entra ID and AD/LDAP
  cards with Save, *Test saved settings* (works while the method is off, so test before enabling) and an enable switch.
* Storage: new table `app_settings` (created by `upgrade-db`/`update.sh`). Values override the env file. Secrets (`ENTRA_CLIENT_SECRET`,
  `AD_BIND_PASS`) are Fernet-encrypted with a key derived from `SECRET_KEY` (if `SECRET_KEY` changes they become unreadable; the page
  says so and asks to re-enter). Secrets are never rendered back, never audited; the audit entry lists changed key names only.
* Multi-worker: a `_version` marker row is compared in a `before_request` hook (one tiny query), so all gunicorn workers pick up a save
  on their next request. CLI `entra-test` / `ad-test` also load the saved values.
* Validation: GUIDs for tenant/client/group ids, redirect URI must end `/auth/entra/callback`, real DC address (not the `dc01` placeholder).
* **Delete IP** (`POST /addresses/<id>/delete`, read/write+): removes the record (Release still just frees it). **Delete server** now
  available to read/write users, from the list and the detail page, with a choice for its IPs (keep / release / delete); audited.
  Shared helper `services/ipam.release_ip`.

## v5.6.0 - DNS zone import

`app/services/dns_import.py` parses a Windows DNS Manager "Export List" (Name/Type/Data/Timestamp; sub-folder rows skipped; "(same as
parent folder)" = zone apex; timestamps like `?10/?14/?2026 1:00:00 AM`; zone name worked out from the NS records) and updates IPAM.
Decisions taken with the user: **add every missing IP** (static and dynamic), **keep the IPAM hostname and store the DNS name in
`dns_name`** on conflicts (listed in the report), fill blank hostnames. Also: Free IPs with a DNS record become Assigned (reported),
several names on one IP -> first static/alphabetical is primary and the rest go on a replaceable "DNS also:" description line, CNAMEs are
resolved to their target's IPs and listed the same way, records for decommissioned servers are added with a warning, records matching an
active server name are linked to it, dynamic-only records 30+ days older than the newest stamp are flagged "stale-dynamic" (never deleted).
New IPs are tagged `dns-import`; auto-created /24 subnets reuse the `derived-from-runbook` tag so Data Quality can name them.
Entry points: `import-dns` CLI (`--dry-run`, `--zone`, `--report`) and **Administration > DNS Import** (Preview / Apply / CSV report).
Verified against the real prod.local export: 745 A + 55 CNAME -> 673 distinct IPs; on the simulated runbook DB 230 IPs and 8 /24
subnets are added, 443 existing IPs get a DNS name (329 already matched, 105 conflicts, 9 blanks filled); second run changes nothing.

## v5.7.0 - multi-domain DNS, names from the server inventory

* New table `dns_records` (zone, name, fqdn, A|CNAME, data, static/dynamic stamp, ip_id, server_id) and `servers.dns_name` (created by `upgrade-db`).
  A zone is replaced as a whole on re-import; zones are independent (prod.local, flvs.net, qa.local ...). Zone name is auto-detected from
  SOA hostmaster + NS targets (can be typed in). Deleting an IP/server nulls the links on its DNS records.
* The v5.6 "DNS also:" description line is gone (replaced by the records table); the importer removes leftover lines.
* Phase 2 `align_server_names` (user's choice: "fix DNS names from server names, flag missing ones"): every ACTIVE server -> `<name>.<domain>` on the
  server and its IPs. Domain precedence: domain inside the name -> zone(s) holding one of its IPs -> Environment mapping (`DNS_ENV_DOMAINS`,
  editable in the GUI, default `Prod Colo=prod.local / Azure=prod.local / QA=qa.local`, only for zones already imported). Report actions:
  `missing-in-dns` (with what DNS does have at that IP and whether it is the server's old name), `ip-mismatch`, `no-domain`, `bad-name`.
  A new DNS-only IP is not auto-linked to a same-named server that already has other addresses (reported as `ip-differs-from-server`).
  Idempotent: second run changes nothing. For server IPs phase 1 only fills an *empty* DNS Name; phase 2 owns it.
* Verified on the real prod.local export against the simulated runbook DB: 1032 active servers checked -> 344 found in DNS with the right IP,
  419 missing in DNS, 6 at a different IP, 199 with no known domain (167 are QA servers waiting for the qa.local zone), 36 unusable names.
* flvs.net and qa.local exports were not available when this was built: the importer is tested with synthetic zones for them.

## v5.8.0
* `scripts/load-dns-zones.sh` (`ipam-load-dns`): backup -> optional reset -> preview per zone -> confirm -> import each zone with `--no-align` -> one align across all zones -> reports in `/var/backups/ipam/dns-load-<stamp>/`.
* Public IPs not inside any IPAM subnet are no longer added (no bogus /24 subnets); they stay in `dns_records`. `--include-public` opts in.
* `dns_import.reset_dns` / `ipam-admin dns-reset`: removes DNS records, IPs whose description still says "Added from the <zone> DNS zone export", empty auto-created subnets; strips the `dns-import` tag from IPs that pre-existed.
* The flvs.net export's SOA/NS are the domain controllers (fvs.fvsonline.net), so the zone name must be given explicitly (`--zone flvs.net`); the script does.
* User Guide (version stays 5.8.0): `app/docs/IPAM-User-Guide-5.8.0.html` (self-contained, 20 embedded screenshots of synthetic demo data) and `.pdf`; served at `/user-guide`, `/user-guide/pdf`, `/user-guide/download` (login required); sidebar link "User Guide".

