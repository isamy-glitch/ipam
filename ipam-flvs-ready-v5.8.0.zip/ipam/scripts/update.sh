#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPAM — update an EXISTING install to this version (keeps your database, users and AD settings).
#
#   sudo bash scripts/update.sh [--skip-backup]
#
# Run it from the unzipped folder. It: backs up the database, copies the new code into /opt/ipam,
# installs new Python packages, upgrades the database (new tables/columns), refreshes the helper
# commands, fixes the nginx socket permission, and restarts IPAM.
# Do NOT re-run install.sh on a working server — it would regenerate passwords and the env file.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
IPAM_USER="ipam"; IPAM_HOME="/opt/ipam"; ENV_FILE="/etc/ipam/ipam.env"
SKIP_BACKUP=false
[ "${1:-}" = "--skip-backup" ] && SKIP_BACKUP=true
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; APP_SRC="$(dirname "$SCRIPT_DIR")"

log()  { echo -e "\e[32m[IPAM]\e[0m  $*"; }
warn() { echo -e "\e[33m[WARN]\e[0m  $*"; }
step() { echo -e "\n\e[34m▶ $*\e[0m"; }
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
[ -d "$IPAM_HOME/venv" ] && [ -f "$ENV_FILE" ] || { echo "No existing IPAM install found at $IPAM_HOME — use install.sh for a first install." >&2; exit 1; }
[ -f "$APP_SRC/wsgi.py" ] || { echo "Run this from the unzipped IPAM folder (wsgi.py not found in $APP_SRC)." >&2; exit 1; }

# prints the version, or nothing if the file is missing (older installs have no version.py). Must never fail:
# with `set -e` + pipefail a missing file used to make the whole script exit silently.
ver_of() { { grep -m1 '^__version__' "$1" 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/'; } || true; }
OLD_VER=$(ver_of "$IPAM_HOME/app/version.py"); OLD_VER=${OLD_VER:-"older than 5.3 (no version file)"}
NEW_VER=$(ver_of "$APP_SRC/app/version.py")
log "Installed version: $OLD_VER   ->   this package: ${NEW_VER:-unknown}"

# ── 1. Database backup ───────────────────────────────────────────────────────
if [ "$SKIP_BACKUP" = false ]; then
  step "Backing up the database..."
  BACKUP_DIR=/var/backups/ipam; mkdir -p "$BACKUP_DIR"; chmod 700 "$BACKUP_DIR"
  CNF=$(mktemp); chmod 600 "$CNF"; trap 'rm -f "$CNF"' EXIT
  DBNAME=$(ENV_FILE="$ENV_FILE" CNF="$CNF" python3 - <<'PY'
import os, re
from urllib.parse import urlparse, unquote
url = ""
for ln in open(os.environ["ENV_FILE"]):
    m = re.match(r"DATABASE_URL=(.*)", ln.strip())
    if m: url = m.group(1).strip().strip("'\"")
u = urlparse(url.replace("mysql+pymysql://", "mysql://", 1))
open(os.environ["CNF"], "w").write("[client]\nuser=%s\npassword=\"%s\"\nhost=%s\nport=%s\n" % (
    unquote(u.username or ""), unquote(u.password or "").replace("\\", "\\\\").replace('"', '\\"'), u.hostname or "127.0.0.1", u.port or 3306))
print((u.path or "/").lstrip("/"))
PY
)
  OUT="$BACKUP_DIR/ipam-$(date +%Y%m%d-%H%M%S).sql.gz"
  if command -v mysqldump >/dev/null && mysqldump --defaults-extra-file="$CNF" --single-transaction --no-tablespaces "$DBNAME" | gzip > "$OUT" && [ -s "$OUT" ]; then
    chmod 600 "$OUT"; log "Database backed up to $OUT"
  else
    rm -f "$OUT"
    echo "Could not back up the database. Fix that, or re-run with --skip-backup if you accept the risk." >&2; exit 1
  fi
fi

# ── 2. Code ──────────────────────────────────────────────────────────────────
step "Copying new code to $IPAM_HOME..."
if command -v rsync >/dev/null; then
  rsync -a --exclude='.git' --exclude='venv' --exclude='__pycache__' "${APP_SRC}/" "${IPAM_HOME}/"
else
  (cd "$APP_SRC" && tar cf - --exclude=.git --exclude=venv --exclude=__pycache__ .) | (cd "$IPAM_HOME" && tar xf -)
fi
chown -R "${IPAM_USER}:${IPAM_USER}" "$IPAM_HOME"; chmod 750 "$IPAM_HOME"

step "Installing Python packages..."
"${IPAM_HOME}/venv/bin/pip" install --quiet -r "${IPAM_HOME}/requirements.txt"

# ── 3. Helpers + service unit ────────────────────────────────────────────────
install -m 755 "${IPAM_HOME}/scripts/enable-ad.sh" /usr/local/bin/ipam-enable-ad
install -m 755 "${IPAM_HOME}/scripts/enable-entra.sh" /usr/local/bin/ipam-enable-entra
install -m 755 "${IPAM_HOME}/scripts/enable-https.sh" /usr/local/bin/ipam-enable-https
install -m 755 "${IPAM_HOME}/scripts/load-dns-zones.sh" /usr/local/bin/ipam-load-dns
if grep -q '^RuntimeDirectoryMode=0750' /etc/systemd/system/ipam.service 2>/dev/null; then
  sed -i 's/^RuntimeDirectoryMode=.*/RuntimeDirectoryMode=0755/' /etc/systemd/system/ipam.service
  systemctl daemon-reload; log "Fixed the nginx socket permission (RuntimeDirectoryMode=0755)."
fi
if ! grep -q '^SESSION_COOKIE_SECURE=' "$ENV_FILE" && ! grep -q 'ssl_certificate' /etc/nginx/conf.d/ipam.conf 2>/dev/null; then
  echo 'SESSION_COOKIE_SECURE=false' >> "$ENV_FILE"; log "Added SESSION_COOKIE_SECURE=false (plain-http install)."
fi

# ── 4. Database upgrade ──────────────────────────────────────────────────────
step "Upgrading the database..."
sudo -u "$IPAM_USER" bash -c "cd ${IPAM_HOME} && set -a && source ${ENV_FILE} && set +a && ./venv/bin/flask --app wsgi upgrade-db"

step "Restarting IPAM..."
systemctl restart ipam; sleep 2
systemctl is-active ipam >/dev/null && log "✓ ipam is running" || warn "✗ ipam is NOT running — check: journalctl -u ipam -n 50"
log "Update complete: now running IPAM $(ver_of "$IPAM_HOME/app/version.py")  (check any time with: sudo ipam-admin version)"
if ! grep -q "^ENTRA_ENABLED='\?true" "$ENV_FILE" 2>/dev/null; then
  log "New: sign in with Microsoft (Entra ID app registration). Steps: ${IPAM_HOME}/docs/ENTRA_ID.md"
  echo "    sudo ipam-enable-https     # Microsoft needs an https address"
  echo "    sudo ipam-enable-entra"
fi
log "Next, to load the runbook:"
echo "    cp /path/to/Consolidated_RunBook.xlsx /tmp/runbook.xlsx && chmod 644 /tmp/runbook.xlsx"
echo "    sudo ipam-admin import-runbook /tmp/runbook.xlsx --dry-run     # preview"
echo "    sudo ipam-admin import-runbook /tmp/runbook.xlsx               # import for real"
