#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPAM — load the DNS zone exports (prod.local, qa.local, flvs.net) in one go.
#
#   sudo ipam-load-dns                              # looks for the three default file names in the current folder
#   sudo ipam-load-dns --prod "dns prod local.txt" --qa qa-dns.txt --flvs dns-fvs.txt
#   sudo ipam-load-dns --zone prod.local=/tmp/prod.txt --zone qa.local=/tmp/qa.txt     # any zones, any names
#
# Options
#   --reset            first remove what earlier DNS imports added (DNS records, IPs they created, empty
#                      auto-created subnets) and load everything again from scratch. IPs that already existed
#                      before any DNS import are never deleted.
#   --preview-only     show what would happen for every zone and stop (nothing is changed, no backup is taken)
#   --yes              do not ask for confirmation
#   --skip-backup      do not dump the database first (not recommended)
#   --include-public   also add internet (public) IPs that are not in any IPAM subnet (default: they stay only in the
#                      zone's DNS records)
#
# Steps: database backup -> (optional reset) -> preview of every zone -> your OK -> import each zone ->
#        server-name alignment across all zones -> reports saved under /var/backups/ipam/dns-load-<date>/
# ─────────────────────────────────────────────────────────────────────────────
# started with "sh script.sh" (dash)? this script needs bash - hand over to it before any bash-only syntax is parsed
if [ -z "${BASH_VERSION:-}" ]; then exec bash "$0" "$@"; fi
set -uo pipefail
ENV_FILE=/etc/ipam/ipam.env
log()  { echo -e "\e[32m[IPAM]\e[0m  $*"; }
warn() { echo -e "\e[33m[WARN]\e[0m  $*"; }
step() { echo -e "\n\e[34m▶ $*\e[0m"; }
die()  { echo -e "\e[31m[ERROR]\e[0m $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run with sudo:  sudo ipam-load-dns"
command -v ipam-admin >/dev/null || die "ipam-admin not found - run scripts/update.sh from the unzipped IPAM folder first."
[ -f "$ENV_FILE" ] || die "$ENV_FILE not found - is IPAM installed on this server?"

ZONES=(); FILES=()
add_zone() { ZONES+=("$1"); FILES+=("$2"); }
RESET=false; PREVIEW_ONLY=false; YES=false; SKIP_BACKUP=false; PUBLIC=""
while [ $# -gt 0 ]; do
  case "$1" in
    --prod) add_zone prod.local "$2"; shift 2 ;;
    --qa)   add_zone qa.local   "$2"; shift 2 ;;
    --flvs) add_zone flvs.net   "$2"; shift 2 ;;
    --zone) [[ "$2" == *=* ]] || die "--zone needs the form name=file, e.g. --zone prod.local=/tmp/prod.txt"
            add_zone "${2%%=*}" "${2#*=}"; shift 2 ;;
    --reset) RESET=true; shift ;;
    --preview-only) PREVIEW_ONLY=true; shift ;;
    --yes) YES=true; shift ;;
    --skip-backup) SKIP_BACKUP=true; shift ;;
    --include-public) PUBLIC="--include-public"; shift ;;
    -h|--help) sed -n 2,22p "$0"; exit 0 ;;
    *) die "Unknown option: $1   (try --help)" ;;
  esac
done

# no files named: use the default names from the current folder
if [ ${#ZONES[@]} -eq 0 ]; then
  for pair in "prod.local|dns prod local.txt|dns_prod_local.txt|dns-prod-local.txt" \
              "qa.local|qa-dns.txt|dns-qa.txt|qa_dns.txt" \
              "flvs.net|dns-fvs.txt|dns-flvs.txt|dns_flvs_net.txt"; do
    IFS='|' read -r z rest <<<"$pair"
    IFS='|' read -ra names <<<"$rest"
    for n in "${names[@]}"; do [ -f "$n" ] && { add_zone "$z" "$n"; break; }; done
  done
fi
[ ${#ZONES[@]} -gt 0 ] || die "No zone files found. Give them with --prod/--qa/--flvs or --zone name=file (see --help)."
for i in "${!ZONES[@]}"; do
  [ -r "${FILES[$i]}" ] || die "Cannot read ${FILES[$i]}"
  ZONES[$i]=$(echo "${ZONES[$i]}" | tr 'A-Z' 'a-z' | sed 's/^\.*//; s/\.*$//')
done

# ── staging area the 'ipam' service user can read ────────────────────────────
STAMP=$(date +%Y%m%d-%H%M%S)
WORK=$(mktemp -d /tmp/ipam-dns-load.XXXXXX); chmod 1777 "$WORK"
OUTDIR=/var/backups/ipam/dns-load-$STAMP
trap 'rm -rf "$WORK"' EXIT
step "Zone files"
for i in "${!ZONES[@]}"; do
  cp "${FILES[$i]}" "$WORK/${ZONES[$i]}.txt"; chmod 644 "$WORK/${ZONES[$i]}.txt"
  printf "  %-14s %-40s %6s lines\n" "${ZONES[$i]}" "${FILES[$i]}" "$(wc -l < "$WORK/${ZONES[$i]}.txt")"
done
ipam-admin upgrade-db >/dev/null 2>&1 || true

confirm() {   # confirm "question"
  $YES && return 0
  read -r -p "$1 [y/N]: " ans; [[ "$ans" =~ ^[Yy] ]]
}

# ── 1. backup ────────────────────────────────────────────────────────────────
if ! $PREVIEW_ONLY && ! $SKIP_BACKUP; then
  step "Backing up the database..."
  BACKUP_DIR=/var/backups/ipam; mkdir -p "$BACKUP_DIR"; chmod 700 "$BACKUP_DIR"
  CNF=$(mktemp); chmod 600 "$CNF"; trap 'rm -rf "$WORK" "$CNF"' EXIT
  DBNAME=$(ENV_FILE="$ENV_FILE" CNF="$CNF" python3 - <<'PY'
import os, re
from urllib.parse import urlparse, unquote
url = ""
for ln in open(os.environ["ENV_FILE"]):
    m = re.match(r"DATABASE_URL=(.*)", ln.strip())
    if m: url = m.group(1).strip().strip("'\"")
u = urlparse(url.replace("mysql+pymysql://", "mysql://", 1))
open(os.environ["CNF"], "w").write("[client]\nuser=%s\npassword=\"%s\"\nhost=%s\nport=%s\n" % (
    unquote(u.username or ""), unquote(u.password or "").replace("\\", "\\\\").replace('"', '\\"'), u.hostname or "127.0.0.1", u.port or 3306))
print((u.path or "/").lstrip("/"))
PY
)
  OUT="$BACKUP_DIR/ipam-before-dns-$STAMP.sql.gz"
  if command -v mysqldump >/dev/null && mysqldump --defaults-extra-file="$CNF" --single-transaction --no-tablespaces "$DBNAME" | gzip > "$OUT" && [ -s "$OUT" ]; then
    chmod 600 "$OUT"; log "Database backed up to $OUT"
  else
    rm -f "$OUT"; die "Could not back up the database. Fix that, or re-run with --skip-backup if you accept the risk."
  fi
fi

# ── 2. optional reset ────────────────────────────────────────────────────────
if $RESET; then
  step "Reset - what earlier DNS imports added (preview)"
  ipam-admin dns-reset --dry-run --report "$WORK/reset-preview.csv"
  if $PREVIEW_ONLY; then :; else
    confirm "Remove all of the above and start from a clean DNS state?" || die "Stopped - nothing was changed."
    ipam-admin dns-reset --yes --report "$WORK/reset.csv" || die "Reset failed."
  fi
fi

# ── 3. preview every zone ────────────────────────────────────────────────────
step "Preview (nothing is saved)"
for i in "${!ZONES[@]}"; do
  z=${ZONES[$i]}
  echo -e "\n\e[1m── $z ──\e[0m"
  ipam-admin import-dns "$WORK/$z.txt" --zone "$z" --dry-run --no-align $PUBLIC --report "$WORK/preview-$z.csv" || die "Preview of $z failed."
done
echo
log "Each preview is worked out against the database as it is now, so a zone loaded later can add a few fewer IPs than"
log "shown here where zones overlap (for example the 10.40.x.x addresses that appear in both qa.local and flvs.net)."
$PREVIEW_ONLY && { log "Preview only - nothing was changed."; mkdir -p "$OUTDIR"; cp "$WORK"/*.csv "$OUTDIR"/ 2>/dev/null; chmod -R go-rwx "$OUTDIR"; log "Reports: $OUTDIR"; exit 0; }
echo
confirm "Import these ${#ZONES[@]} zone(s) into IPAM now?" || die "Stopped - nothing was changed."

# ── 4. import every zone, then align ─────────────────────────────────────────
step "Importing"
FAILED=0
for i in "${!ZONES[@]}"; do
  z=${ZONES[$i]}
  echo -e "\n\e[1m── $z ──\e[0m"
  ipam-admin import-dns "$WORK/$z.txt" --zone "$z" --no-align $PUBLIC --report "$WORK/import-$z.csv" || { warn "Import of $z failed."; FAILED=1; }
done
step "Setting DNS names from the server names (all zones together)"
ipam-admin align-dns-names --report "$WORK/align.csv" || { warn "Alignment failed."; FAILED=1; }

# ── 5. reports ───────────────────────────────────────────────────────────────
mkdir -p "$OUTDIR"; cp "$WORK"/*.csv "$OUTDIR"/ 2>/dev/null; chmod -R go-rwx "$OUTDIR"
step "Done"
log "Detailed reports (one CSV per zone + align.csv): $OUTDIR"
log "Open  Administration > DNS Import  in the web interface to see the zones that are loaded."
log "To see what needs fixing: align.csv - actions missing-in-dns, ip-mismatch, no-domain, bad-name."
[ $FAILED -eq 0 ] || { warn "Something failed above - the database backup (if taken) is in /var/backups/ipam/."; exit 1; }
