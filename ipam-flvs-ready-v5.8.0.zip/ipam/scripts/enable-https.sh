#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPAM — serve the site over HTTPS (needed for Microsoft sign-in: Entra rejects http redirect URIs).
#
#   sudo ipam-enable-https                          # self-signed certificate (10 years) for this server's name
#   sudo ipam-enable-https --host netipam1010.prod.local
#   sudo ipam-enable-https --cert /path/chain.pem --key /path/key.pem    # your own / internal-CA certificate
#
# Rewrites the nginx site (backup kept), turns on secure cookies, switches an http redirect URI in
# ipam.env to https, restarts nginx + IPAM. Browsers show a warning for a self-signed certificate until
# it is trusted (import server.crt, or use --cert with a certificate from your internal CA).
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
ENV_FILE=/etc/ipam/ipam.env
CONF=/etc/nginx/conf.d/ipam.conf
SSL_DIR=/etc/nginx/ssl/ipam
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
[ -f "$ENV_FILE" ] || { echo "$ENV_FILE not found — run install.sh first." >&2; exit 1; }
command -v nginx >/dev/null || { echo "nginx is not installed." >&2; exit 1; }

HOST=""; CERT=""; KEY=""
while [ $# -gt 0 ]; do
  case "$1" in
    --host) HOST="$2"; shift 2 ;;
    --cert) CERT="$2"; shift 2 ;;
    --key)  KEY="$2";  shift 2 ;;
    *) echo "Usage: sudo ipam-enable-https [--host FQDN] [--cert FILE --key FILE]" >&2; exit 1 ;;
  esac
done
[ -z "$HOST" ] && { DEF=$(hostname -f 2>/dev/null || hostname); read -r -p "Server name users will browse to [$DEF]: " HOST; HOST=${HOST:-$DEF}; }
if { [ -n "$CERT" ] || [ -n "$KEY" ]; } && { [ ! -r "$CERT" ] || [ ! -r "$KEY" ]; }; then
  echo "--cert and --key must both be given and readable." >&2; exit 1
fi
IPAM_HOME=$(grep -oE 'alias +[^;]+/app/static' "$CONF" 2>/dev/null | head -1 | awk '{print $2}' | sed 's|/app/static||' || true)
IPAM_HOME=${IPAM_HOME:-/opt/ipam}

mkdir -p "$SSL_DIR"; chmod 700 "$SSL_DIR"
SELF=false
if [ -n "$CERT" ]; then
  install -m 644 "$CERT" "$SSL_DIR/server.crt"; install -m 600 "$KEY" "$SSL_DIR/server.key"
else
  SELF=true
  SAN="DNS:${HOST},DNS:localhost"
  for ip in $(hostname -I 2>/dev/null); do SAN="$SAN,IP:$ip"; done
  echo "Creating a self-signed certificate for ${HOST} ..."
  openssl req -x509 -nodes -days 3650 -newkey rsa:3072 -keyout "$SSL_DIR/server.key" -out "$SSL_DIR/server.crt" \
    -subj "/CN=${HOST}/O=IPAM/C=US" -addext "subjectAltName=${SAN}" 2>/dev/null
  chmod 600 "$SSL_DIR/server.key"; chmod 644 "$SSL_DIR/server.crt"
fi

[ -f "$CONF" ] && cp -p "$CONF" "${CONF}.bak.$(date +%Y%m%d-%H%M%S)"
HSTS=""; [ "$SELF" = false ] && HSTS='add_header Strict-Transport-Security "max-age=31536000" always;'
cat > "$CONF" << NGINX
server {
    listen 80;
    server_name ${HOST} _;
    return 301 https://${HOST}\$request_uri;
}
server {
    listen 443 ssl;
    server_name ${HOST} _;
    ssl_certificate     ${SSL_DIR}/server.crt;
    ssl_certificate_key ${SSL_DIR}/server.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_session_cache   shared:SSL:10m;
    ${HSTS}
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    client_max_body_size 16M;
    location / {
        proxy_pass         http://unix:/run/ipam/ipam.sock;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
    }
    location /static/ {
        alias   ${IPAM_HOME}/app/static/;
        expires 30d;
    }
}
NGINX
nginx -t

# env: secure cookies on, http redirect URI -> https
cp -p "$ENV_FILE" "${ENV_FILE}.bak.$(date +%Y%m%d-%H%M%S)"
export ENV_FILE HOST
python3 - <<'PY'
import os, re
path, host = os.environ["ENV_FILE"], os.environ["HOST"]
lines = open(path).read().splitlines()
def setv(k, v):
    for i, ln in enumerate(lines):
        if ln.startswith(k + "="):
            lines[i] = f"{k}='{v}'"; return
    lines.append(f"{k}='{v}'")
setv("SESSION_COOKIE_SECURE", "true")
for i, ln in enumerate(lines):
    if ln.startswith("ENTRA_REDIRECT_URI=") and "http://" in ln:
        lines[i] = f"ENTRA_REDIRECT_URI='https://{host}/auth/entra/callback'"
open(path, "w").write("\n".join(lines) + "\n")
PY
chmod 640 "$ENV_FILE"

if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw allow 443/tcp >/dev/null && echo "ufw: opened 443."; fi
if command -v firewall-cmd >/dev/null && systemctl is-active --quiet firewalld; then firewall-cmd --permanent --add-service=https >/dev/null && firewall-cmd --reload >/dev/null && echo "firewalld: opened https."; fi

systemctl restart ipam; sleep 1
systemctl reload nginx 2>/dev/null || systemctl restart nginx
echo
echo "HTTPS is on:  https://${HOST}/"
echo "Microsoft redirect URI to register on the app registration:  https://${HOST}/auth/entra/callback"
[ "$SELF" = true ] && echo "Self-signed certificate: browsers warn until you trust ${SSL_DIR}/server.crt (or re-run with --cert/--key from your internal CA)."
echo "Make sure DNS resolves ${HOST} to this server for the people who will sign in."
