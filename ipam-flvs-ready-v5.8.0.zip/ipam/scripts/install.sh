#!/bin/bash
# =============================================================================
# IPAM Installation Script — MySQL backend
# Supports: Ubuntu 20.04/22.04/24.04, Debian 11/12, RHEL/Rocky/Alma 8/9
# Must be run as root:  sudo bash install.sh [--domain ipam.example.com] [--no-ssl]
# =============================================================================

if [ -z "$BASH_VERSION" ]; then
  echo "ERROR: run with bash, not sh.  Usage: sudo bash install.sh"
  exit 1
fi

set -euo pipefail

# ── Root check ────────────────────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: run as root.  Usage: sudo bash install.sh"
  exit 1
fi

# ── Defaults ──────────────────────────────────────────────────────────────────
IPAM_USER="ipam"
IPAM_HOME="/opt/ipam"
IPAM_LOG_DIR="/var/log/ipam"
DB_NAME="ipam"
DB_USER="ipam"
DB_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
SECRET_KEY=$(openssl rand -hex 32)
DOMAIN="ipam.local"
ENABLE_SSL=true
COOKIE_SECURE=true
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_SRC="$(dirname "$SCRIPT_DIR")"

# ── Args ──────────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN="$2"; shift 2 ;;
    --no-ssl) ENABLE_SSL=false; COOKIE_SECURE=false; shift ;;
    --help)
      echo "Usage: sudo bash install.sh [--domain FQDN] [--no-ssl]"
      exit 0 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

log()  { echo -e "\e[32m[IPAM]\e[0m  $*"; }
warn() { echo -e "\e[33m[WARN]\e[0m  $*"; }
step() { echo -e "\n\e[34m▶ $*\e[0m"; }

# ── OS Detection ──────────────────────────────────────────────────────────────
step "Detecting OS..."
OS_FAMILY="debian"
if [ -f /etc/os-release ]; then
  . /etc/os-release
  if echo "${ID_LIKE:-} ${ID:-}" | grep -qiE 'rhel|centos|fedora|rocky|alma'; then
    OS_FAMILY="rhel"
  fi
  log "Detected: ${PRETTY_NAME:-unknown} (family: $OS_FAMILY)"
fi

# ── 1. System packages ────────────────────────────────────────────────────────
step "Installing system packages..."

if [ "$OS_FAMILY" = "rhel" ]; then
  dnf install -y epel-release 2>/dev/null || true
  # MySQL 8 from the official repo
  if ! rpm -q mysql-server &>/dev/null; then
    dnf install -y https://dev.mysql.com/get/mysql84-community-release-el9-1.noarch.rpm 2>/dev/null || \
    dnf install -y https://dev.mysql.com/get/mysql80-community-release-el8-9.noarch.rpm 2>/dev/null || true
    dnf install -y mysql-community-server 2>/dev/null || dnf install -y mysql-server
  fi
  dnf install -y python3 python3-pip python3-devel python3-virtualenv \
    nginx openssl gcc openldap-devel
  systemctl enable --now mysqld
else
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y \
    python3 python3-pip python3-venv python3-dev \
    mysql-server \
    nginx openssl \
    build-essential \
    libldap2-dev libsasl2-dev
  systemctl enable --now mysql
fi

# ── 2. Service user ───────────────────────────────────────────────────────────
step "Creating service user '$IPAM_USER'..."
id "$IPAM_USER" &>/dev/null || \
  useradd --system --no-create-home --shell /sbin/nologin \
          --home-dir "$IPAM_HOME" "$IPAM_USER"
log "User ready."

# ── 3. MySQL setup ────────────────────────────────────────────────────────────
step "Configuring MySQL..."

# On RHEL, MySQL sets a temp root password in the error log
if [ "$OS_FAMILY" = "rhel" ]; then
  MYSQL_TEMP_PW=$(grep 'temporary password' /var/log/mysqld.log 2>/dev/null | awk '{print $NF}' || true)
  if [ -n "$MYSQL_TEMP_PW" ]; then
    warn "MySQL temporary root password found. You may need to reset it."
    warn "Run: mysql -u root -p'$MYSQL_TEMP_PW' --connect-expired-password -e \"ALTER USER 'root'@'localhost' IDENTIFIED BY 'NewRootPw!';\""
  fi
fi

# Create DB and user — using root socket auth (works on fresh Ubuntu/Debian installs)
mysql -u root << MYSQL_SETUP
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost'  IDENTIFIED BY '${DB_PASS}';

-- Update password in case this is a reinstall
ALTER USER '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'localhost'  IDENTIFIED BY '${DB_PASS}';

GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'127.0.0.1';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SETUP

log "MySQL database '${DB_NAME}' and user '${DB_USER}' ready."

# ── 4. Application files ──────────────────────────────────────────────────────
step "Deploying application to $IPAM_HOME..."
mkdir -p "$IPAM_HOME" "$IPAM_LOG_DIR" /etc/ipam
rsync -a --exclude='.git' "${APP_SRC}/" "${IPAM_HOME}/" 2>/dev/null || \
  cp -r "${APP_SRC}/." "${IPAM_HOME}/"
chown -R "${IPAM_USER}:${IPAM_USER}" "$IPAM_HOME" "$IPAM_LOG_DIR"
chmod 750 "$IPAM_HOME"

# ── 5. Python virtual environment ────────────────────────────────────────────
step "Building Python virtual environment..."
[ ! -d "${IPAM_HOME}/venv" ] && python3 -m venv "${IPAM_HOME}/venv"
"${IPAM_HOME}/venv/bin/pip" install --quiet --upgrade pip setuptools wheel
"${IPAM_HOME}/venv/bin/pip" install --quiet -r "${IPAM_HOME}/requirements.txt"
log "Python dependencies installed (PyMySQL — no C compilation needed)."

# ── 6. Environment configuration ─────────────────────────────────────────────
step "Writing /etc/ipam/ipam.env..."
cat > /etc/ipam/ipam.env << EOF
# ─── IPAM Environment Configuration ────────────────────────────────────────
# Generated by install.sh on $(date)
# Edit this file to change settings, then: systemctl restart ipam

FLASK_ENV=production
SECRET_KEY=${SECRET_KEY}

# MySQL connection string — dialect must be mysql+pymysql://
DATABASE_URL=mysql+pymysql://${DB_USER}:${DB_PASS}@127.0.0.1/${DB_NAME}?charset=utf8mb4

IPAM_LOG_DIR=${IPAM_LOG_DIR}

# Browsers refuse "Secure" cookies on plain http, so this must be false when installed with --no-ssl.
SESSION_COOKIE_SECURE=${COOKIE_SECURE}

# ─── AD/LDAP Integration ────────────────────────────────────────────────────
# Easiest way to turn this on:   sudo ipam-enable-ad
# (asks for the DC and the svc_netipam password, fills in the lines below, restarts, tests)
AD_ENABLED=false
AD_SERVER=ldaps://dc01.prod.local
AD_DOMAIN=prod.local
AD_BASE_DN=DC=prod,DC=local
AD_BIND_USER=svc_netipam@prod.local
AD_BIND_PASS=CHANGEME
AD_USER_SEARCH_BASE=DC=prod,DC=local
AD_GROUP_SEARCH_BASE=DC=prod,DC=local
AD_ADMIN_USERS=
AD_CA_FILE=
AD_FALLBACK_LOCAL=true
AD_GROUP_ADMIN=IPAM-Admins
AD_GROUP_READWRITE=IPAM-ReadWrite
AD_GROUP_READONLY=IPAM-ReadOnly
AD_USE_SSL=true
AD_TLS_VERIFY=true

# ─── Microsoft Entra ID sign-in (app registration, no LDAP) ─────────────────
# Easiest way to turn this on:   sudo ipam-enable-https   (Microsoft needs an https address)
#                                sudo ipam-enable-entra   (asks for tenant / client id / secret, tests it)
ENTRA_ENABLED=false

# ─── API ────────────────────────────────────────────────────────────────────
API_TOKEN_EXPIRY_DAYS=30
EOF

chmod 640 /etc/ipam/ipam.env
chown root:"${IPAM_USER}" /etc/ipam/ipam.env
log "Environment file written."

# ── 7. Database schema ────────────────────────────────────────────────────────
step "Initializing database schema..."
cd "${IPAM_HOME}"
sudo -u "${IPAM_USER}" bash -c "
  set -a
  source /etc/ipam/ipam.env
  set +a
  ${IPAM_HOME}/venv/bin/flask --app wsgi init-db
  ${IPAM_HOME}/venv/bin/flask --app wsgi create-default-groups
"
log "Database schema and default groups created."

# ── 8. systemd unit ───────────────────────────────────────────────────────────
step "Installing systemd service..."
cat > /etc/systemd/system/ipam.service << EOF
[Unit]
Description=IPAM — Network IP Address Manager
After=network.target mysql.service mysqld.service
Wants=mysql.service mysqld.service

[Service]
Type=notify
User=${IPAM_USER}
Group=${IPAM_USER}
WorkingDirectory=${IPAM_HOME}
EnvironmentFile=/etc/ipam/ipam.env

ExecStart=${IPAM_HOME}/venv/bin/gunicorn \
    --workers 4 \
    --worker-class sync \
    --bind unix:/run/ipam/ipam.sock \
    --timeout 120 \
    --access-logfile ${IPAM_LOG_DIR}/access.log \
    --error-logfile  ${IPAM_LOG_DIR}/error.log \
    wsgi:app

RuntimeDirectory=ipam
# 0755: nginx runs as www-data (not in the ipam group) and must be able to reach the socket inside this directory
RuntimeDirectoryMode=0755
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ipam
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ipam
systemctl restart ipam
log "IPAM service started."

# ── 8a. ipam-enable-ad helper ────────────────────────────────────────────────
install -m 755 "${APP_SRC}/scripts/enable-ad.sh" /usr/local/bin/ipam-enable-ad
install -m 755 "${APP_SRC}/scripts/enable-entra.sh" /usr/local/bin/ipam-enable-entra
install -m 755 "${APP_SRC}/scripts/enable-https.sh" /usr/local/bin/ipam-enable-https
install -m 755 "${APP_SRC}/scripts/load-dns-zones.sh" /usr/local/bin/ipam-load-dns
log "Installed /usr/local/bin/ipam-enable-ad, ipam-enable-entra, ipam-enable-https, ipam-load-dns"

# ── 8b. ipam-admin helper ─────────────────────────────────────────────────────
# /opt/ipam is owned by the service user and closed to everyone else (chmod 750), so admins
# can't `cd` into it. This wrapper runs IPAM management commands as the service user with
# the production environment loaded:   sudo ipam-admin create-admin admin svc_netipam@prod.local
step "Installing ipam-admin helper..."
cat > /usr/local/bin/ipam-admin << WRAP
#!/bin/bash
# Run IPAM management commands as the '${IPAM_USER}' service user with /etc/ipam/ipam.env loaded.
#   sudo ipam-admin create-admin admin svc_netipam@prod.local
#   sudo ipam-admin generate-token admin
#   sudo ipam-admin ad-test
if [ "\$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo ipam-admin <command>" >&2; exit 1; fi
exec sudo -u ${IPAM_USER} bash -c 'cd ${IPAM_HOME} && set -a && source /etc/ipam/ipam.env && set +a && exec ./venv/bin/flask --app wsgi "\$@"' _ "\$@"
WRAP
chmod 755 /usr/local/bin/ipam-admin
log "Installed /usr/local/bin/ipam-admin"

# ── 9. Nginx ──────────────────────────────────────────────────────────────────
step "Configuring Nginx..."
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

if [ "$ENABLE_SSL" = true ]; then
  SSL_DIR=/etc/nginx/ssl/ipam
  mkdir -p "$SSL_DIR" && chmod 700 "$SSL_DIR"
  if [ ! -f "${SSL_DIR}/server.crt" ]; then
    openssl req -x509 -nodes -days 3650 -newkey rsa:4096 \
      -keyout "${SSL_DIR}/server.key" \
      -out    "${SSL_DIR}/server.crt" \
      -subj "/CN=${DOMAIN}/O=IPAM/C=US" \
      -addext "subjectAltName=DNS:${DOMAIN},DNS:localhost" 2>/dev/null
    chmod 600 "${SSL_DIR}/server.key"
  fi
  cat > /etc/nginx/conf.d/ipam.conf << NGINX
server {
    listen 80;
    server_name ${DOMAIN};
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl http2;
    server_name ${DOMAIN};
    ssl_certificate     ${SSL_DIR}/server.crt;
    ssl_certificate_key ${SSL_DIR}/server.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_session_cache   shared:SSL:10m;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-Content-Type-Options nosniff always;
    client_max_body_size 16M;
    location / {
        proxy_pass         http://unix:/run/ipam/ipam.sock;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
    }
    location /static/ {
        alias   ${IPAM_HOME}/app/static/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
NGINX
else
  cat > /etc/nginx/conf.d/ipam.conf << NGINX
server {
    listen 80;
    server_name ${DOMAIN} _;
    client_max_body_size 16M;
    location / {
        proxy_pass         http://unix:/run/ipam/ipam.sock;
        proxy_set_header   Host              \$host;
        proxy_set_header   X-Real-IP         \$remote_addr;
        proxy_set_header   X-Forwarded-For   \$proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto \$scheme;
        proxy_read_timeout 120s;
    }
    location /static/ {
        alias   ${IPAM_HOME}/app/static/;
        expires 30d;
    }
}
NGINX
fi

nginx -t && systemctl enable --now nginx
log "Nginx configured and running."

# ── 10. Firewall ──────────────────────────────────────────────────────────────
step "Configuring firewall..."
if command -v firewall-cmd &>/dev/null && systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-service=http --add-service=https && firewall-cmd --reload
  log "firewalld: opened ports 80/443."
elif command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow 80/tcp && ufw allow 443/tcp
  log "ufw: opened ports 80/443."
else
  warn "No active firewall detected — open ports 80/443 manually if needed."
fi

# ── 11. Summary ───────────────────────────────────────────────────────────────
sleep 2
systemctl is-active ipam  && log "✓ ipam service running" || warn "✗ ipam NOT running — check: journalctl -u ipam"
systemctl is-active nginx && log "✓ nginx running"        || warn "✗ nginx NOT running"

PROTO="https"; [ "$ENABLE_SSL" = false ] && PROTO="http"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅  IPAM Installation Complete  (MySQL backend)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  URL     : ${PROTO}://${DOMAIN}"
echo "  App dir : ${IPAM_HOME}"
echo "  Config  : /etc/ipam/ipam.env"
echo "  Logs    : ${IPAM_LOG_DIR}/"
echo ""
echo "  ── Create first admin user ───────────────────────────────────"
echo "  sudo ipam-admin create-admin admin svc_netipam@prod.local"
echo ""
echo "  ── Sign in with Microsoft (Entra ID app registration, recommended) ──"
echo "  sudo ipam-enable-https     # Microsoft only accepts an https address"
echo "  sudo ipam-enable-entra     # tenant ID, client ID, client secret; tests it"
echo "  See: ${IPAM_HOME}/docs/ENTRA_ID.md"
echo ""
echo "  ── Enable AD/LDAP (legacy alternative) ───────────────────────"
echo "  Create the svc_netipam account in AD first (see docs/AD_INTEGRATION.md), then:"
echo "  sudo ipam-enable-ad        # asks for the DC + password, restarts IPAM, tests the bind"
echo "  See: ${IPAM_HOME}/docs/AD_INTEGRATION.md"
echo ""
echo "  ── MySQL connection ──────────────────────────────────────────"
echo "  mysql -u ${DB_USER} -p'${DB_PASS}' ${DB_NAME}"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
