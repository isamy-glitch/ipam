#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPAM — turn on Active Directory login (prod.local) using the svc_netipam account.
#
#   sudo ipam-enable-ad            (installed by install.sh)
#   sudo bash scripts/enable-ad.sh (from the unzipped folder, on an older install)
#
# Asks a few questions, writes the AD_* settings into /etc/ipam/ipam.env (a backup is kept),
# restarts IPAM and runs the connection test. The password is typed hidden and never put on a
# command line. Re-run it any time to change a setting; Enter keeps the value shown in [brackets].
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
ENV_FILE=/etc/ipam/ipam.env
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
[ -f "$ENV_FILE" ] || { echo "$ENV_FILE not found — run install.sh first." >&2; exit 1; }

cur() { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2- | sed -e "s/^'//" -e "s/'$//" || true; }
ask() { # ask VAR "prompt" default
  local v; read -r -p "$2 [$3]: " v; printf -v "$1" '%s' "${v:-$3}"
}

DOMAIN_CUR=$(cur AD_DOMAIN);       DOMAIN_CUR=${DOMAIN_CUR:-prod.local}
SERVER_CUR=$(cur AD_SERVER);       SERVER_CUR=${SERVER_CUR:-ldaps://dc01.prod.local}
BIND_CUR=$(cur AD_BIND_USER);      BIND_CUR=${BIND_CUR:-svc_netipam@${DOMAIN_CUR}}
[ "$BIND_CUR" = "svc-ipam@prod.local" ] && BIND_CUR="svc_netipam@prod.local"
ADMINS_CUR=$(cur AD_ADMIN_USERS)
CA_CUR=$(cur AD_CA_FILE)

echo "── Active Directory settings ─────────────────────────────────────"
ask AD_DOMAIN  "AD domain" "$DOMAIN_CUR"
BASE_DN="DC=${AD_DOMAIN//./,DC=}"
echo "Domain controller URI: ldaps://host (port 636, recommended) or ldap://host (port 389, clear text — lab testing only)"
# dc01.prod.local is only a placeholder: never offer it as a default, make the admin type a real DC.
if [ "$SERVER_CUR" = "ldaps://dc01.prod.local" ]; then
  while :; do
    read -r -p "Domain controller URI (e.g. ldaps://<your-dc-name>.${AD_DOMAIN}): " AD_SERVER
    [ -n "$AD_SERVER" ] && [ "$AD_SERVER" != "ldaps://dc01.prod.local" ] && break
    echo "  Enter the real name of one of your domain controllers."
  done
else
  ask AD_SERVER  "Domain controller URI" "$SERVER_CUR"
fi
ask AD_BIND_USER "Service account (UPN)" "$BIND_CUR"
read -r -s -p "Password for ${AD_BIND_USER} (hidden, Enter keeps the current one): " AD_BIND_PASS; echo
if [ -z "$AD_BIND_PASS" ]; then
  AD_BIND_PASS=$(cur AD_BIND_PASS)
  [ -n "$AD_BIND_PASS" ] && [ "$AD_BIND_PASS" != "CHANGEME" ] || { echo "A password is required." >&2; exit 1; }
fi
case "$AD_BIND_PASS" in *"'"*) echo "Passwords containing a single quote (') aren't supported here — please use a different one." >&2; exit 1 ;; esac
# Default to the whole domain so users/groups are found in any OU (narrow it later if you like).
USB_CUR=$(cur AD_USER_SEARCH_BASE);  case "$USB_CUR" in ""|CN=Users,*) USB_CUR="$BASE_DN" ;; esac
GSB_CUR=$(cur AD_GROUP_SEARCH_BASE); case "$GSB_CUR" in ""|CN=Users,*) GSB_CUR="$BASE_DN" ;; esac
# A service-account DN here is a common mistake (it would only ever find that one account) - reset it.
SAM=${AD_BIND_USER%%@*}
case "$USB_CUR" in "CN=$SAM,"*) USB_CUR="$BASE_DN" ;; esac
echo "(Users are searched under this point; keep the domain root unless you want to limit it to one OU.)"
ask AD_USER_SEARCH_BASE  "Where to look for users"  "$USB_CUR"
ask AD_GROUP_SEARCH_BASE "Where to look for groups" "$GSB_CUR"
ask AD_ADMIN_USERS "AD usernames who are always IPAM admins (comma-separated, blank = use AD groups only)" "$ADMINS_CUR"
if [[ "$AD_SERVER" == ldaps://* ]]; then
  AD_USE_SSL=true
  ask AD_CA_FILE "PEM file of the CA that signed the DC certificate (blank = system CAs)" "$CA_CUR"
  if [ -n "$AD_CA_FILE" ] && [ ! -r "$AD_CA_FILE" ]; then echo "Can't read $AD_CA_FILE" >&2; exit 1; fi
else
  AD_USE_SSL=false; AD_CA_FILE=""
  echo "NOTE: ldap:// sends the service-account password and user passwords unencrypted. Fine for a lab test, not for production."
fi

cp -p "$ENV_FILE" "${ENV_FILE}.bak.$(date +%Y%m%d-%H%M%S)"
export ENV_FILE AD_DOMAIN AD_SERVER AD_BIND_USER AD_BIND_PASS AD_USER_SEARCH_BASE AD_GROUP_SEARCH_BASE \
       AD_ADMIN_USERS AD_USE_SSL AD_CA_FILE BASE_DN
python3 - <<'PY'
import os, re
path = os.environ["ENV_FILE"]
vals = {
    "AD_ENABLED": "true",
    "AD_SERVER": os.environ["AD_SERVER"],
    "AD_DOMAIN": os.environ["AD_DOMAIN"],
    "AD_BASE_DN": os.environ["BASE_DN"],
    "AD_BIND_USER": os.environ["AD_BIND_USER"],
    "AD_BIND_PASS": os.environ["AD_BIND_PASS"],
    "AD_USER_SEARCH_BASE": os.environ["AD_USER_SEARCH_BASE"],
    "AD_GROUP_SEARCH_BASE": os.environ["AD_GROUP_SEARCH_BASE"],
    "AD_ADMIN_USERS": os.environ["AD_ADMIN_USERS"],
    "AD_USE_SSL": os.environ["AD_USE_SSL"],
    "AD_CA_FILE": os.environ["AD_CA_FILE"],
}
# Quote values: systemd's EnvironmentFile and `bash source` both accept single quotes, which keeps
# characters like $ # & ; and spaces in the password from being interpreted.
lines = open(path).read().splitlines()
seen = set()
for i, ln in enumerate(lines):
    m = re.match(r"([A-Z_]+)=", ln)
    if m and m.group(1) in vals:
        lines[i] = f"{m.group(1)}='{vals[m.group(1)]}'"; seen.add(m.group(1))
for k, v in vals.items():
    if k not in seen:
        lines.append(f"{k}='{v}'")
open(path, "w").write("\n".join(lines) + "\n")
PY
chmod 640 "$ENV_FILE"

echo "Restarting IPAM..."
systemctl restart ipam
sleep 2
echo "── Connection test ───────────────────────────────────────────────"
if command -v ipam-admin >/dev/null; then
  ipam-admin ad-test
else
  IPAM_USER=$(stat -c %U /opt/ipam)
  sudo -u "$IPAM_USER" bash -c 'cd /opt/ipam && set -a && source /etc/ipam/ipam.env && set +a && ./venv/bin/flask --app wsgi ad-test'
fi
