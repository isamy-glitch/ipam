#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# IPAM — turn on "Sign in with Microsoft" (Entra ID app registration, no LDAP).
#
#   sudo ipam-enable-entra            (installed by install.sh / update.sh)
#   sudo bash scripts/enable-entra.sh (from the unzipped folder)
#
# Needs the values from the app registration (see docs/ENTRA_ID.md): Directory (tenant) ID,
# Application (client) ID and a client secret VALUE. Writes them to /etc/ipam/ipam.env (a backup
# is kept), restarts IPAM and tests them with Microsoft. Re-run any time; Enter keeps the [value].
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
ENV_FILE=/etc/ipam/ipam.env
[ "$(id -u)" -eq 0 ] || { echo "Run with sudo." >&2; exit 1; }
[ -f "$ENV_FILE" ] || { echo "$ENV_FILE not found — run install.sh first." >&2; exit 1; }

cur() { { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2- | sed -e "s/^'//" -e "s/'$//"; } || true; }
ask() { local v; read -r -p "$2 [$3]: " v; printf -v "$1" '%s' "${v:-$3}"; }
GUID_RE='^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$'
ask_guid() { # ask_guid VAR "prompt" default
  while :; do
    ask "$1" "$2" "$3"
    [[ "${!1}" =~ $GUID_RE ]] && break
    echo "  That is not a GUID (looks like 11111111-2222-3333-4444-555555555555). Copy it from the Overview page of the app registration."
    set -- "$1" "$2" ""
  done
}
yn() { # yn "question" default(true|false) -> prints true/false
  local d="$2" v; local hint="y/N"; [ "$d" = true ] && hint="Y/n"
  read -r -p "$1 [$hint]: " v
  case "${v:-}" in [yY]*) echo true ;; [nN]*) echo false ;; *) echo "$d" ;; esac
}

HOST_DEFAULT=$(hostname -f 2>/dev/null || hostname)
REDIR_CUR=$(cur ENTRA_REDIRECT_URI); REDIR_CUR=${REDIR_CUR:-https://${HOST_DEFAULT}/auth/entra/callback}

echo "── Microsoft Entra ID (app registration) ─────────────────────────"
echo "Open portal.azure.com > Microsoft Entra ID > App registrations > your IPAM app > Overview."
ask_guid ENTRA_TENANT_ID "Directory (tenant) ID" "$(cur ENTRA_TENANT_ID)"
ask_guid ENTRA_CLIENT_ID "Application (client) ID" "$(cur ENTRA_CLIENT_ID)"
read -r -s -p "Client secret VALUE (hidden; Enter keeps the current one): " ENTRA_CLIENT_SECRET; echo
if [ -z "$ENTRA_CLIENT_SECRET" ]; then
  ENTRA_CLIENT_SECRET=$(cur ENTRA_CLIENT_SECRET)
  [ -n "$ENTRA_CLIENT_SECRET" ] || { echo "A client secret is required (Certificates & secrets > New client secret; copy the Value, not the Secret ID)." >&2; exit 1; }
fi
case "$ENTRA_CLIENT_SECRET" in *"'"*) echo "Secrets containing a single quote (') aren't supported here — create a new one." >&2; exit 1 ;; esac

echo
echo "Redirect URI — must be https, and must be added to the app registration under Authentication > Web:"
ask ENTRA_REDIRECT_URI "Redirect URI" "$REDIR_CUR"
case "$ENTRA_REDIRECT_URI" in
  https://*|http://localhost*|http://127.0.0.1*) ;;
  *) echo "  WARNING: Microsoft rejects plain-http redirect URIs. Run  sudo ipam-enable-https  first (or in a moment),"
     echo "           then re-run this script with an https:// address." ;;
esac

echo
echo "Who gets which IPAM role? Best: App Roles on the app registration (IPAM.Admin / IPAM.ReadWrite / IPAM.ReadOnly)."
echo "Alternative: put the Object IDs of Entra groups below (comma-separated). Leave blank to use App Roles only."
ask_groups() { # accept blank or comma-separated GUIDs
  local v
  while :; do
    read -r -p "$2 [$3]: " v; v=${v:-$3}; v=${v// /}
    ok=true; IFS=, read -ra parts <<< "$v"
    for p in "${parts[@]:-}"; do [ -z "$p" ] || [[ "$p" =~ $GUID_RE ]] || ok=false; done
    $ok && { printf -v "$1" '%s' "$v"; return; }
    echo "  Group IDs must be GUIDs separated by commas."; set -- "$1" "$2" ""
  done
}
ask_groups ENTRA_GROUP_ADMIN     "Group ID(s) for IPAM Admins"       "$(cur ENTRA_GROUP_ADMIN)"
ask_groups ENTRA_GROUP_READWRITE "Group ID(s) for IPAM Read/Write"   "$(cur ENTRA_GROUP_READWRITE)"
ask_groups ENTRA_GROUP_READONLY  "Group ID(s) for IPAM Read-only"    "$(cur ENTRA_GROUP_READONLY)"
ask ENTRA_ADMIN_USERS "Sign-in names (e.g. you@prod.local) that are ALWAYS IPAM admins (comma-separated, blank = none)" "$(cur ENTRA_ADMIN_USERS)"
CUR_REQ=$(cur ENTRA_REQUIRE_ROLE); CUR_LOC=$(cur ENTRA_LOCAL_LOGIN)
ENTRA_REQUIRE_ROLE=$(yn "Refuse people who match no role/group (otherwise they get read-only)?" "${CUR_REQ:-false}")
ENTRA_LOCAL_LOGIN=$(yn "Keep the local username/password form on the login page (break-glass admin)?" "${CUR_LOC:-true}")

cp -p "$ENV_FILE" "${ENV_FILE}.bak.$(date +%Y%m%d-%H%M%S)"
export ENV_FILE ENTRA_TENANT_ID ENTRA_CLIENT_ID ENTRA_CLIENT_SECRET ENTRA_REDIRECT_URI ENTRA_GROUP_ADMIN \
       ENTRA_GROUP_READWRITE ENTRA_GROUP_READONLY ENTRA_ADMIN_USERS ENTRA_REQUIRE_ROLE ENTRA_LOCAL_LOGIN
python3 - <<'PY'
import os, re
path = os.environ["ENV_FILE"]
keys = ["ENTRA_TENANT_ID", "ENTRA_CLIENT_ID", "ENTRA_CLIENT_SECRET", "ENTRA_REDIRECT_URI", "ENTRA_GROUP_ADMIN",
        "ENTRA_GROUP_READWRITE", "ENTRA_GROUP_READONLY", "ENTRA_ADMIN_USERS", "ENTRA_REQUIRE_ROLE", "ENTRA_LOCAL_LOGIN"]
vals = {k: os.environ[k] for k in keys}
vals["ENTRA_ENABLED"] = "true"
lines = open(path).read().splitlines()
seen = set()
for i, ln in enumerate(lines):
    m = re.match(r"([A-Z_]+)=", ln)
    if m and m.group(1) in vals:
        lines[i] = f"{m.group(1)}='{vals[m.group(1)]}'"; seen.add(m.group(1))
if not seen:
    lines += ["", "# ─── Microsoft Entra ID sign-in (sudo ipam-enable-entra) ───"]
for k, v in vals.items():
    if k not in seen:
        lines.append(f"{k}='{v}'")
open(path, "w").write("\n".join(lines) + "\n")
PY
chmod 640 "$ENV_FILE"

echo "Restarting IPAM..."
systemctl restart ipam
sleep 2
echo "── Connection test (asks Microsoft to accept the app registration) ──"
if command -v ipam-admin >/dev/null; then
  ipam-admin entra-test || { echo "Fix the value named above and run  sudo ipam-enable-entra  again."; exit 1; }
else
  IPAM_USER=$(stat -c %U /opt/ipam)
  sudo -u "$IPAM_USER" bash -c 'cd /opt/ipam && set -a && source /etc/ipam/ipam.env && set +a && ./venv/bin/flask --app wsgi entra-test'
fi
echo
echo "Done. Open ${ENTRA_REDIRECT_URI%/auth/entra/callback}/login and click 'Sign in with Microsoft'."
