"""
Import the consolidated runbook workbook (Consolidated_RunBook.xlsx) into IPAM.

Sheets understood
  Prod_VLANs         -> VLANs + their subnets
  Main_Servers_Data  -> active servers (+ their IPs)
  Decomissioned      -> decommissioned servers (kept as history; their IPs are NOT held - see below)
  Azure_Web_Apps     -> web_apps
  Wiki_References / System_Catalog -> resource_links

Rules (agreed with the infrastructure team)
  * IPs outside the listed Prod_VLANs subnets get an auto-created /24 (tagged "derived-from-runbook").
  * Decommissioned servers are imported with status "decommissioned"; their IPs are listed on the
    server record (former_ips) but not assigned, so those addresses read as free. If the same IP is
    also on an active server, the active server wins.
  * Public IPs are stored on the server record as text (there is no subnet to put them in).
  * Re-running is safe: servers/apps/links that came from the runbook are refreshed in place;
    anything added by hand is left alone.

Everything odd the importer notices (bad IP cells, duplicate IPs, guessed fixes...) goes into the report.
"""
import ipaddress
import re
from collections import OrderedDict, defaultdict
from datetime import date, datetime, timedelta

from sqlalchemy import func

from app import db
from app.models import (VLAN, Subnet, IPAddress, IPStatus, Server, ServerStatus, WebApp, ResourceLink)

IP_RE = re.compile(r"\d{1,3}(?:\.\d{1,3}){3}")
HOSTNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
EXCEL_ERRORS = {"#VALUE!", "#N/A", "#REF!", "#NAME?", "#DIV/0!", "#NULL!", "#NUM!"}
NA_VALUES = {"n/a", "n\\a", "na", "none", "-", "?", "tbd"}
DERIVED_TAG = "derived-from-runbook"

SERVER_SOURCE = "runbook:Main_Servers_Data"
DECOM_SOURCE = "runbook:Decomissioned"
APP_SOURCE = "runbook:Azure_Web_Apps"


# ─────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────
def clean(v, na_is_none=False):
    """Trim a cell to a string; blank / Excel errors -> None (and 'N/A'-style values too if asked)."""
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = re.sub(r"\s+", " ", str(v)).strip()
    if not s or s in EXCEL_ERRORS:
        return None
    if na_is_none and s.lower() in NA_VALUES:
        return None
    return s


def excel_serial_to_date(n):
    try:
        return (datetime(1899, 12, 30) + timedelta(days=int(n))).date()
    except Exception:
        return None


class Report:
    def __init__(self):
        self.issues = []          # (level, sheet, row, message)
        self.counts = defaultdict(int)

    def add(self, level, sheet, row, msg):
        self.issues.append((level, sheet, row, msg))

    def warn(self, sheet, row, msg):
        self.add("warning", sheet, row, msg)

    def info(self, sheet, row, msg):
        self.add("info", sheet, row, msg)

    def summary(self):
        order = ["vlans", "subnets_listed", "subnets_derived", "servers_active", "servers_decommissioned",
                 "ips_assigned", "ips_reserved", "ip_shared", "ip_skipped", "web_apps", "links"]
        labels = {
            "vlans": "VLANs", "subnets_listed": "Subnets (from Prod_VLANs)",
            "subnets_derived": "Subnets auto-created (/24)", "servers_active": "Servers (active)",
            "servers_decommissioned": "Servers (decommissioned)", "ips_assigned": "IP addresses assigned",
            "ips_reserved": "IP addresses reserved", "ip_shared": "Extra servers claiming an in-use IP",
            "ip_skipped": "IPs skipped", "web_apps": "Azure web apps", "links": "Reference links",
        }
        lines = [f"  {labels[k]:<40} {self.counts.get(k, 0)}" for k in order if k in self.counts or k in labels]
        w = sum(1 for i in self.issues if i[0] == "warning")
        lines.append(f"  {'Items needing a look (see report)':<40} {w}")
        return "\n".join(lines)

    def to_csv_rows(self):
        return [("level", "sheet", "row", "message")] + [tuple(i) for i in self.issues]


def read_sheet(wb, name, report):
    """Rows as dicts keyed by header (trimmed), plus the Excel row number."""
    if name not in wb.sheetnames:
        report.warn(name, "", "sheet not found - skipped")
        return []
    ws = wb[name]
    it = ws.iter_rows(values_only=True)
    try:
        header = [clean(h) for h in next(it)]
    except StopIteration:
        return []
    out = []
    for n, row in enumerate(it, start=2):
        if not any(c is not None and str(c).strip() for c in row):
            continue
        d = {h: row[i] if i < len(row) else None for i, h in enumerate(header) if h}
        d["_row"] = n
        out.append(d)
    return out


def parse_ips(cell, report, sheet, row, label):
    """All valid IPv4 addresses in a cell, with obvious typos repaired (and reported)."""
    raw = clean(cell)
    if raw is None:
        return [], None
    if raw.lower() in NA_VALUES:
        return [], None
    fixed = raw
    if ".." in fixed:
        fixed = re.sub(r"\.{2,}", ".", fixed)
        report.warn(sheet, row, f"{label}: '{raw}' looks like a typo; read as '{fixed}'")
    found = []
    for m in IP_RE.findall(fixed):
        try:
            found.append(str(ipaddress.IPv4Address(m)))
        except ValueError:
            report.warn(sheet, row, f"{label}: '{m}' is not a valid IP address - skipped")
    if not found:
        return [], raw           # text that isn't an IP (e.g. 'Squad 1') -> caller keeps it as a note
    return found, None


# ─────────────────────────────────────────────────────────────
# VLANs + subnets
# ─────────────────────────────────────────────────────────────
class SubnetIndex:
    def __init__(self):
        self.items = []         # (network, Subnet)

    def load(self):
        self.items = []
        for s in Subnet.query.all():
            try:
                self.items.append((ipaddress.ip_network(s.network, strict=False), s))
            except ValueError:
                pass

    def add(self, subnet):
        self.items.append((ipaddress.ip_network(subnet.network, strict=False), subnet))

    def find(self, ip):
        addr = ipaddress.ip_address(ip)
        best = None
        for net, s in self.items:
            if addr.version == net.version and addr in net and (best is None or net.prefixlen > best[0].prefixlen):
                best = (net, s)
        return best[1] if best else None


def import_vlans(wb, report, subnets):
    sheet = "Prod_VLANs"
    for r in read_sheet(wb, sheet, report):
        m = re.search(r"\d+", clean(r.get("VLAN")) or "")
        if not m:
            report.warn(sheet, r["_row"], f"no VLAN number in '{r.get('VLAN')}' - skipped")
            continue
        vid = int(m.group())
        desc = clean(r.get("Description"))
        notes = clean(r.get("Notes"))
        cidr = clean(r.get("IP Address"))

        vlan = VLAN.query.filter_by(vlan_id=vid).first()
        if not vlan:
            vlan = VLAN(vlan_id=vid, name=desc or f"VLAN {vid}")
            db.session.add(vlan)
            report.counts["vlans"] += 1
        else:
            vlan.name = desc or vlan.name
        vlan.description = notes or vlan.description

        net = None
        if cidr:
            try:
                net = ipaddress.ip_network(cidr, strict=False)
                if cidr.split("/")[0] != str(net.network_address):
                    report.warn(sheet, r["_row"], f"VLAN {vid}: '{cidr}' has host bits set; using the network {net}")
            except ValueError:
                if "routable" not in cidr.lower():
                    report.warn(sheet, r["_row"], f"VLAN {vid}: '{cidr}' is not a network - VLAN kept without a subnet")
        db.session.flush()
        if net is not None:
            sub = Subnet.query.filter_by(network=str(net)).first()
            if not sub:
                sub = Subnet(network=str(net), name=desc or f"VLAN {vid}", description=notes, vlan_id=vlan.id)
                db.session.add(sub)
                db.session.flush()
                report.counts["subnets_listed"] += 1
                subnets.add(sub)
            else:
                sub.name = sub.name or desc
                sub.vlan_id = sub.vlan_id or vlan.id
    db.session.flush()


def ensure_vlan(number, report, why):
    vlan = VLAN.query.filter_by(vlan_id=number).first()
    if not vlan and 1 <= number <= 4094:
        vlan = VLAN(vlan_id=number, name=f"VLAN {number}",
                    description="Referenced in the runbook but not on the Prod_VLANs sheet")
        db.session.add(vlan)
        db.session.flush()
        report.counts["vlans"] += 1
        report.info("Servers", "", f"VLAN {number} is used by servers ({why}) but is not on Prod_VLANs - created as a placeholder")
    return vlan


def subnet_for_ip(ip, subnets, report, sheet, row):
    s = subnets.find(ip)
    if s:
        return s
    net = ipaddress.ip_network(f"{ip}/24", strict=False)
    s = Subnet.query.filter_by(network=str(net)).first()
    if not s:
        s = Subnet(network=str(net), name=f"Imported {net}", tags=DERIVED_TAG,
                   description="Created automatically from the runbook. The /24 mask is an assumption - "
                               "edit the subnet if the real range is different.")
        db.session.add(s)
        db.session.flush()
        report.counts["subnets_derived"] += 1
    subnets.add(s)
    return s


# ─────────────────────────────────────────────────────────────
# Server rows -> normalized records
# ─────────────────────────────────────────────────────────────
def _decom_text(v):
    s = clean(v)
    if s is None:
        return None
    if re.fullmatch(r"\d{5}", s):
        d = excel_serial_to_date(s)
        return d.isoformat() if d else s
    return s


def normalize_row(r, sheet, report):
    """One spreadsheet row -> dict of server fields + its IPs. Handles the shifted rows on the Decomissioned sheet."""
    row = r["_row"]
    is_decom_sheet = sheet == "Decomissioned"
    g = lambda k, na=True: clean(r.get(k), na_is_none=na)

    rec = dict(sheet=sheet, row=row,
               name=clean(r.get("Server Name")), owner=g("Owner"), old_name=g("Old Name"),
               function=g("Function"), suite=g("Suite"), product=g("Product"), technology=g("Technology"),
               resource_group=g("ResourceGroup"), site_name=g("Site Name"), host_platform=g("Host"), os=None,
               notes=g("Notes", na=False), environment=g("Environment"), decom_col=_decom_text(r.get("Decom")))

    vlan_raw = r.get("VLAN")
    rec["vlan_raw"] = None
    vtxt = clean(vlan_raw)
    if vtxt is not None:
        if re.fullmatch(r"\d+", vtxt):
            rec["vlan_raw"] = int(vtxt)
        elif is_decom_sheet and not vtxt.startswith("#"):
            # Rows from the old Educator (Proxmox) estate: the VLAN column holds the environment and the
            # columns from "Old Name" onward are shifted one place to the left of the headers.
            ln = rec["old_name"]
            rec.update(
                environment=vtxt,
                function=ln if ln and ln.upper() != "DECOM" else None,
                old_name="DECOM" if (ln and ln.upper() == "DECOM") else None,
                suite=g("Function"), product=g("Suite"), technology=g("Product"),
                site_name=g("ResourceGroup"), host_platform=g("Site Name"), os=g("Host"),
                resource_group=None)
            if rec["product"] and rec["product"] == rec["suite"]:
                rec["product"] = None
    # Decom sheet, unshifted rows: the Host column holds an OS name (CentOS 7, Ubuntu...) rather than a platform
    if is_decom_sheet and rec["os"] is None and rec["host_platform"] and re.search(
            r"centos|ubuntu|bsd|windows|debian|rhel|red hat", rec["host_platform"], re.I):
        rec["os"], rec["host_platform"] = rec["host_platform"], None

    # IPs
    ips, notes_extra = [], []
    for i in range(1, 6):
        label = f"IP {i}"
        found, text = parse_ips(r.get(label), report, sheet, row, label)
        for ip in found:
            ips.append((ip, label))
        if text:
            notes_extra.append(f"{label}: {text}")
            report.warn(sheet, row, f"{rec['name'] or '(no name)'}: {label} holds '{text}', not an IP - kept as a note")
    rec["ips"] = ips
    pub = clean(r.get("Public IP"))
    rec["public_ip"] = None
    if pub:
        found = IP_RE.findall(pub)
        rec["public_ip"] = ", ".join(dict.fromkeys(found)) if found else pub
    if notes_extra:
        rec["notes"] = "; ".join(x for x in [rec["notes"], *notes_extra] if x)

    # Name
    if rec["name"] is None:
        first = ips[0][0] if ips else None
        rec["name"] = f"(unnamed {first})" if first else f"(unnamed row {row})"
        report.warn(sheet, row, f"no Server Name - recorded as '{rec['name']}'")
    elif isinstance(r.get("Server Name"), (int, float)):
        report.warn(sheet, row, f"Server Name is the number {rec['name']} (probably a typo) - kept as-is; function: {rec['function']}")

    # Status
    status, decom_info = ServerStatus.ACTIVE, None
    notes_l = (rec["notes"] or "").lower()
    if is_decom_sheet:
        status = ServerStatus.DECOMMISSIONED
    else:
        dc = (rec["decom_col"] or "").lower()
        if dc in ("yes", "y") or notes_l.startswith("decommissioned") or (rec["old_name"] or "").upper() == "DECOM":
            status = ServerStatus.DECOMMISSIONED
        elif dc:
            report.warn(sheet, row, f"{rec['name']}: Decom column says '{rec['decom_col']}' - not understood, left active")
    if status == ServerStatus.DECOMMISSIONED:
        parts = []
        if rec["decom_col"] and rec["decom_col"].lower() not in ("yes", "y"):
            parts.append(f"Decom: {rec['decom_col']}")
        if "decommission" in notes_l or "inc" in notes_l:
            parts.append(rec["notes"])
        decom_info = "; ".join(parts) or None
    rec["status"], rec["decom_info"] = status, decom_info
    if (rec["old_name"] or "").upper() == "DECOM":
        rec["old_name"] = None
    return rec


def merge_records(records, report):
    """Rows with the same server name + status (e.g. a Nutanix host listed once per network) become one server."""
    merged = OrderedDict()
    for rec in records:
        key = (rec["name"].lower(), rec["status"])
        if key not in merged:
            merged[key] = dict(rec, rows=[(rec["sheet"], rec["row"])])
            continue
        base = merged[key]
        base["rows"].append((rec["sheet"], rec["row"]))
        for f in ("owner", "old_name", "function", "suite", "product", "technology", "resource_group", "site_name",
                  "host_platform", "os", "environment", "public_ip", "decom_info", "vlan_raw"):
            if base.get(f) in (None, "") and rec.get(f) not in (None, ""):
                base[f] = rec[f]
        seen = {ip for ip, _ in base["ips"]}
        base["ips"] += [(ip, lb) for ip, lb in rec["ips"] if ip not in seen]
        if rec["notes"] and rec["notes"] not in (base["notes"] or ""):
            base["notes"] = "; ".join(x for x in [base["notes"], rec["notes"]] if x)
    for rec in merged.values():
        if len(rec["rows"]) > 1:
            report.info(rec["sheet"], rec["rows"][0][1],
                        f"{rec['name']}: {len(rec['rows'])} rows merged into one server "
                        f"(rows {', '.join(str(r) for _, r in rec['rows'])})")
    return list(merged.values())


# ─────────────────────────────────────────────────────────────
# Servers + IPs
# ─────────────────────────────────────────────────────────────
SERVER_FIELDS = ("old_name", "function", "suite", "product", "technology", "os", "resource_group", "site_name",
                 "host_platform", "environment", "owner", "public_ip", "notes")


def upsert_server(rec, source):
    existing = (Server.query.filter(func.lower(Server.name) == rec["name"].lower(), Server.status == rec["status"],
                                    Server.source.like("runbook:%")).first())
    if existing:
        srv = existing
    else:
        srv = Server(name=rec["name"], status=rec["status"])
        db.session.add(srv)
    srv.name = rec["name"]
    srv.status = rec["status"]
    for f in SERVER_FIELDS:
        setattr(srv, f, rec.get(f))
    srv.decom_info = rec.get("decom_info")
    srv.source = source
    return srv, existing is None


def import_servers(wb, report, subnets):
    records = []
    for sheet in ("Main_Servers_Data", "Decomissioned"):
        for r in read_sheet(wb, sheet, report):
            records.append(normalize_row(r, sheet, report))
    records = merge_records(records, report)

    active = [r for r in records if r["status"] == ServerStatus.ACTIVE]
    decom = [r for r in records if r["status"] == ServerStatus.DECOMMISSIONED]

    owner_of_ip = {}          # ip -> Server (active) claimed during this run
    keep_ids = defaultdict(set)

    for rec in active:
        source = SERVER_SOURCE
        srv, _ = upsert_server(rec, source)
        db.session.flush()
        report.counts["servers_active"] += 1
        keep_ids[srv.id]            # make sure a re-import also cleans up IPs this server no longer has
        primary_subnet = None

        for ip, label in rec["ips"]:
            sub = subnet_for_ip(ip, subnets, report, rec["sheet"], rec["row"])
            primary_subnet = primary_subnet or sub
            if ip in owner_of_ip and owner_of_ip[ip].id != srv.id:
                first = owner_of_ip[ip]
                row = IPAddress.query.filter_by(address=ip, subnet_id=sub.id).first()
                if row is not None:
                    extra = f"Also listed for: {srv.name}"
                    if extra not in (row.description or ""):
                        row.description = "; ".join(x for x in [row.description, extra] if x)
                report.counts["ip_shared"] += 1
                report.warn(rec["sheet"], rec["row"], f"{ip} is listed for both {first.name} and {srv.name} - "
                            f"assigned to {first.name}, the other noted in its description (VIP / cluster address?)")
                continue
            row = IPAddress.query.filter_by(address=ip, subnet_id=sub.id).first()
            if row is not None and row.server_id not in (None, srv.id):
                other = db.session.get(Server, row.server_id)
                if other is not None and not (other.source or "").startswith("runbook:"):
                    report.counts["ip_skipped"] += 1
                    report.warn(rec["sheet"], rec["row"], f"{ip} already belongs to '{other.name}' (added by hand) - left alone")
                    continue
            reserved = bool(re.search(r"reserved", rec["notes"] or "", re.I))
            if row is None:
                row = IPAddress(address=ip, subnet_id=sub.id)
                db.session.add(row)
            row.status = IPStatus.RESERVED if reserved else IPStatus.ASSIGNED
            row.server = srv
            row.interface = label
            row.hostname = srv.name if HOSTNAME_RE.match(srv.name) else None
            row.description = rec["function"] if HOSTNAME_RE.match(srv.name) else (
                f"{srv.name} - {rec['function']}" if rec["function"] else srv.name)
            row.device_type = rec["technology"] or rec["product"]
            row.location = rec["environment"]
            row.tags = rec["suite"]
            row.owner = rec["owner"]
            owner_of_ip[ip] = srv
            keep_ids[srv.id].add(ip)
            report.counts["ips_reserved" if reserved else "ips_assigned"] += 1
        db.session.flush()

        # VLAN number: the sheet's value, else from the subnet the first IP sits in
        vn = rec["vlan_raw"]
        if vn is None and primary_subnet is not None and primary_subnet.vlan_id:
            v = db.session.get(VLAN, primary_subnet.vlan_id)
            vn = v.vlan_id if v else None
        srv.vlan_number = vn
        if vn:
            ensure_vlan(vn, report, srv.name)

        if not rec["ips"] and not rec["public_ip"]:
            report.info(rec["sheet"], rec["row"], f"{srv.name}: no IP address on record")

    # a re-import: release IPs that used to belong to these servers but are no longer in the sheet
    for srv_id, keep in keep_ids.items():
        for stale in IPAddress.query.filter(IPAddress.server_id == srv_id).all():
            if stale.address not in keep:
                stale.status, stale.server_id, stale.interface = IPStatus.FREE, None, None
                stale.hostname = stale.description = stale.device_type = stale.location = stale.tags = stale.owner = None

    for rec in decom:
        srv, _ = upsert_server(rec, DECOM_SOURCE)
        report.counts["servers_decommissioned"] += 1
        former = []
        for ip, label in rec["ips"]:
            former.append(ip)
            if ip in owner_of_ip:
                report.info(rec["sheet"], rec["row"],
                            f"{srv.name} (decommissioned) used {ip}, now on {owner_of_ip[ip].name} - active server keeps it")
        srv.former_ips = ", ".join(dict.fromkeys(former)) or None
        if rec["vlan_raw"]:
            srv.vlan_number = rec["vlan_raw"]
            ensure_vlan(rec["vlan_raw"], report, srv.name)
    db.session.flush()


# ─────────────────────────────────────────────────────────────
# Azure web apps and links
# ─────────────────────────────────────────────────────────────
def import_web_apps(wb, report):
    sheet = "Azure_Web_Apps"
    for r in read_sheet(wb, sheet, report):
        g = lambda k: clean(r.get(k), na_is_none=True)
        name = clean(r.get("Name"))
        if not name:
            report.warn(sheet, r["_row"], "row without a Name - skipped")
            continue
        app = WebApp.query.filter(func.lower(WebApp.name) == name.lower(), WebApp.source == APP_SOURCE).first()
        if not app:
            app = WebApp(name=name)
            db.session.add(app)
        app.name = name
        app.application = g("Application")
        app.default_hostname = g("DefaultHostName")
        enabled = g("EnabledHostNames")
        app.enabled_hostnames = ", ".join(h.strip() for h in enabled.split(",") if h.strip()) if enabled else None
        app.state = g("State")
        app.pricing_tier = g("Pricing Tier")
        app.app_type = g("App Type")
        app.priority = g("Priority")
        app.owner = g("Owner")
        app.note = g("Note")
        app.acl_contributors = g("Listed Contributor/Owner In ACL")
        app.location = g("Location")
        app.resource_group = g("ResourceGroup")
        app.repo_url = g("Repo URL")
        app.ftps_endpoint = g("Deployment Center FTPS endpoint")
        app.source = APP_SOURCE
        report.counts["web_apps"] += 1
    db.session.flush()


def import_links(wb, report):
    seen = set()

    def add(desc, url, sheet, row):
        url = (url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            return
        if url in seen:
            return
        seen.add(url)
        link = ResourceLink.query.filter_by(url=url).first()
        if not link:
            link = ResourceLink(url=url, description=desc)
            db.session.add(link)
        link.description = desc
        report.counts["links"] += 1

    for r in read_sheet(wb, "Wiki_References", report):
        d, u = clean(r.get("Description")), clean(r.get("Link"))
        if d and u:
            add(d, u, "Wiki_References", r["_row"])
    # System_Catalog: a header-less little table; keep rows whose 2nd cell is a URL
    if "System_Catalog" in wb.sheetnames:
        for n, row in enumerate(wb["System_Catalog"].iter_rows(min_row=2, values_only=True), start=2):
            d = clean(row[0]) if row else None
            u = clean(row[1]) if row and len(row) > 1 else None
            if d and u:
                add(d, u, "System_Catalog", n)
    db.session.flush()


# ─────────────────────────────────────────────────────────────
# entry point
# ─────────────────────────────────────────────────────────────
def run_import(path, dry_run=False):
    """Import the workbook. With dry_run=True everything is rolled back. Returns a Report."""
    from openpyxl import load_workbook
    report = Report()
    wb = load_workbook(path, data_only=True, read_only=False)
    subnets = SubnetIndex()
    try:
        subnets.load()
        import_vlans(wb, report, subnets)
        import_servers(wb, report, subnets)
        import_web_apps(wb, report)
        import_links(wb, report)
        if dry_run:
            db.session.rollback()
        else:
            db.session.commit()
    except Exception:
        db.session.rollback()
        raise
    return report
