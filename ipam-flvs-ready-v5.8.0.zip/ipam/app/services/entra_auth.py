"""
Microsoft Entra ID (Azure AD) sign-in through an App Registration - OpenID Connect authorization-code flow.

No LDAP, no service-account password and no line of sight to a domain controller: the browser is sent to
Microsoft, the user signs in there (MFA / Conditional Access apply), and Microsoft sends the browser back to
IPAM with a one-time code that IPAM swaps for the user's identity using the app registration's client secret.

Roles come from the token:
  1. App Roles ("roles" claim)  - define IPAM.Admin / IPAM.ReadWrite / IPAM.ReadOnly on the app registration and
     assign groups to them under Enterprise applications > Users and groups.  Recommended (never "overflows").
  2. Group object IDs ("groups" claim) - set ENTRA_GROUP_* to the group GUIDs.  If the user is in too many groups
     Microsoft omits the list ("overage"); IPAM then asks Microsoft Graph for it.
"""
import logging
import re
from flask import current_app

log = logging.getLogger(__name__)

try:
    import msal
    MSAL_AVAILABLE = True
except ImportError:                      # pragma: no cover
    msal = None
    MSAL_AVAILABLE = False

SCOPES = ["User.Read"]                   # sign-in + (only for group overage) Graph lookups; granted by default
GUID_RE = re.compile(r"^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$")


class EntraError(Exception):
    """A sign-in problem whose message is safe to show the user."""


def _cfg(key, default=""):
    return current_app.config.get(key, default)


def is_enabled() -> bool:
    return bool(_cfg("ENTRA_ENABLED", False))


def missing_settings() -> list:
    return [k for k in ("ENTRA_TENANT_ID", "ENTRA_CLIENT_ID", "ENTRA_CLIENT_SECRET") if not _cfg(k)]


def authority() -> str:
    return f"https://{_cfg('ENTRA_AUTHORITY_HOST', 'login.microsoftonline.com')}/{_cfg('ENTRA_TENANT_ID')}"


def _build_app():
    """The msal client. Separate function so tests can swap it out."""
    if not MSAL_AVAILABLE:
        raise EntraError("The 'msal' package is not installed on the server (pip install msal).")
    try:
        # msal downloads the tenant's OpenID configuration here, so this is the first thing to fail
        # when the server has no outbound HTTPS to Microsoft.
        return msal.ConfidentialClientApplication(
            _cfg("ENTRA_CLIENT_ID"), authority=authority(), client_credential=_cfg("ENTRA_CLIENT_SECRET"),
        )
    except Exception as exc:
        log.warning("Could not initialise the Entra client: %s", exc)
        host = _cfg("ENTRA_AUTHORITY_HOST", "login.microsoftonline.com")
        raise EntraError(f"The IPAM server cannot reach {host} on port 443 (or the tenant ID is wrong). "
                         "Allow outbound HTTPS to Microsoft and check ENTRA_TENANT_ID.")


def redirect_uri(default_external_url: str) -> str:
    return _cfg("ENTRA_REDIRECT_URI") or default_external_url


def redirect_uri_warning(uri: str) -> str:
    """Entra only accepts https redirect URIs (http is allowed for localhost only)."""
    if not uri:
        return "No redirect URI is set."
    if uri.startswith("http://") and not re.match(r"http://(localhost|127\.0\.0\.1)([:/]|$)", uri):
        return ("The redirect URI is plain http. Microsoft only accepts https redirect URIs (http is allowed for "
                "localhost only), so sign-in cannot work until IPAM is served over HTTPS: run  sudo ipam-enable-https")
    return ""


# ── sign-in flow ─────────────────────────────────────────────────────────────

def begin_login(callback_url: str) -> dict:
    """Start the auth-code flow. Returns the flow dict (keep it in the session); flow['auth_uri'] is where to send the browser."""
    if missing_settings():
        raise EntraError("Entra ID sign-in is not fully configured (missing: %s)." % ", ".join(missing_settings()))
    flow = _build_app().initiate_auth_code_flow(SCOPES, redirect_uri=redirect_uri(callback_url))
    if "auth_uri" not in flow:
        raise EntraError(flow.get("error_description") or "Could not start the Microsoft sign-in.")
    return flow


def finish_login(flow: dict, query_args: dict) -> dict:
    """Exchange the code for the user's identity. Returns a user-info dict (see user_info_from_claims)."""
    if not flow:
        raise EntraError("The sign-in session expired. Please try again.")
    result = _build_app().acquire_token_by_auth_code_flow(flow, query_args)
    if "error" in result:
        log.warning("Entra sign-in failed: %s - %s", result.get("error"), result.get("error_description"))
        # AADSTS codes are useful to the admin and not sensitive, but keep the first line only.
        desc = (result.get("error_description") or result["error"]).splitlines()[0]
        raise EntraError(desc)
    claims = result.get("id_token_claims") or {}
    groups = claims.get("groups")
    if groups is None and ("groups" in (claims.get("_claim_names") or {})) and result.get("access_token"):
        groups = _groups_from_graph(result["access_token"])      # group "overage"
    return user_info_from_claims(claims, groups or [])


def _groups_from_graph(access_token: str) -> list:
    try:
        import requests
        r = requests.post("https://graph.microsoft.com/v1.0/me/getMemberObjects",
                          json={"securityEnabledOnly": True},
                          headers={"Authorization": f"Bearer {access_token}"}, timeout=10)
        if r.ok:
            return list(r.json().get("value", []))
        log.warning("Graph getMemberObjects returned %s", r.status_code)
    except Exception as exc:                                     # pragma: no cover - network
        log.warning("Graph group lookup failed: %s", exc)
    return []


# ── claims -> IPAM user ──────────────────────────────────────────────────────

def _csv(value) -> set:
    return {x.strip().lower() for x in (value or "").split(",") if x.strip()}


def resolve_role(roles, groups, upn=""):
    """Map token roles / group ids to an IPAM role. Admin > ReadWrite > ReadOnly. None = no match."""
    from app.models import Role
    roles = {str(r).lower() for r in (roles or [])}
    groups = {str(g).lower() for g in (groups or [])}
    if upn and upn.lower() in set(_cfg("ENTRA_ADMIN_USERS", []) or []):
        return Role.ADMIN
    for role, role_key, grp_key in ((Role.ADMIN, "ENTRA_ROLE_ADMIN", "ENTRA_GROUP_ADMIN"),
                                    (Role.READWRITE, "ENTRA_ROLE_READWRITE", "ENTRA_GROUP_READWRITE"),
                                    (Role.READONLY, "ENTRA_ROLE_READONLY", "ENTRA_GROUP_READONLY")):
        if (_cfg(role_key) and _cfg(role_key).lower() in roles) or (groups & _csv(_cfg(grp_key))):
            return role
    return None


def user_info_from_claims(claims: dict, groups=None) -> dict:
    from app.models import Role
    oid = claims.get("oid") or claims.get("sub") or ""
    upn = (claims.get("preferred_username") or claims.get("upn") or claims.get("email") or "").strip()
    if not oid or not upn:
        raise EntraError("Microsoft did not return a user id / sign-in name.")
    role = resolve_role(claims.get("roles"), groups if groups is not None else claims.get("groups"), upn)
    if role is None:
        if _cfg("ENTRA_REQUIRE_ROLE", False):
            raise EntraError("You are signed in to Microsoft, but you have not been given an IPAM role. "
                             "Ask an IPAM admin to add you to an IPAM group.")
        role = Role.READONLY
    return {
        "oid": oid,
        "username": upn,
        "email": (claims.get("email") or upn).strip(),
        "display_name": claims.get("name") or upn,
        "role": role,
    }


def provision_user(info: dict):
    """Find or create the IPAM user for an Entra sign-in and refresh its role. Caller commits."""
    from app import db
    from app.models import User
    lower = lambda col, val: db.func.lower(col) == val.lower()

    user = User.query.filter_by(entra_oid=info["oid"]).first()
    if not user:
        # People who used to sign in through LDAP: link them by sign-in name / e-mail (never link local accounts).
        user = (User.query.filter(User.is_ad_user.is_(True), User.entra_oid.is_(None),
                                  db.or_(lower(User.username, info["username"]), lower(User.email, info["email"])))
                .first())
    if user:
        user.entra_oid = info["oid"]
        user.display_name = info["display_name"] or user.display_name
        user.role = info["role"]
        user.is_ad_user = True
        return user

    username = info["username"]
    if User.query.filter(lower(User.username, username)).first():       # clashes with a local account
        username = f"{info['username']} (entra)"
    email = info["email"]
    if User.query.filter(lower(User.email, email)).first():
        email = info["username"] if not User.query.filter(lower(User.email, info["username"])).first() \
            else f"{info['oid']}@entra.invalid"
    user = User(username=username, email=email, display_name=info["display_name"], role=info["role"],
                is_ad_user=True, is_active=True, entra_oid=info["oid"])
    db.session.add(user)
    db.session.flush()                      # assigns user.id so login_user() can use it
    return user


# ── admin "test connection" ─────────────────────────────────────────────────

def test_connection(force: bool = False) -> dict:
    """Prove tenant id, client id and client secret are right by asking Microsoft for an app-only token."""
    if not force and not is_enabled():
        return {"ok": False, "message": "Entra ID sign-in is disabled (ENTRA_ENABLED is not true)."}
    if missing_settings():
        return {"ok": False, "message": "Missing settings: " + ", ".join(missing_settings())}
    if not MSAL_AVAILABLE:
        return {"ok": False, "message": "The 'msal' package is not installed (pip install msal)."}
    try:
        result = _build_app().acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
    except EntraError as exc:
        return {"ok": False, "message": str(exc)}
    except Exception as exc:
        return {"ok": False, "message": f"Could not reach Microsoft: {exc}"}
    if "access_token" in result:
        return {"ok": True, "message": f"App registration accepted by tenant {_cfg('ENTRA_TENANT_ID')} "
                                       f"(client {_cfg('ENTRA_CLIENT_ID')})."}
    desc = (result.get("error_description") or result.get("error") or "unknown error").splitlines()[0]
    return {"ok": False, "message": desc}
