"""
AD/LDAP Authentication and Group Sync Service
Active Directory authentication (domain-agnostic; e.g. prod.local).
"""
import logging
from flask import current_app

log = logging.getLogger(__name__)

try:
    import ldap3
    from ldap3 import Server, Connection, ALL, NTLM, SUBTREE, Tls
    from ldap3.core.exceptions import LDAPException, LDAPBindError
    LDAP3_AVAILABLE = True
except ImportError:
    LDAP3_AVAILABLE = False
    log.warning("ldap3 not installed — AD authentication disabled")


class ADAuthService:
    """Handles AD bind, user lookup, and group membership queries."""

    def __init__(self):
        self.enabled = current_app.config.get("AD_ENABLED", False)
        self.server_uri = current_app.config.get("AD_SERVER", "")
        self.domain = current_app.config.get("AD_DOMAIN", "")
        self.base_dn = current_app.config.get("AD_BASE_DN", "")
        self.bind_user = current_app.config.get("AD_BIND_USER", "")
        self.bind_pass = current_app.config.get("AD_BIND_PASS", "")
        self.user_search_base = current_app.config.get("AD_USER_SEARCH_BASE", self.base_dn)
        self.group_search_base = current_app.config.get("AD_GROUP_SEARCH_BASE", self.base_dn)
        self.use_ssl = current_app.config.get("AD_USE_SSL", True)
        self.tls_verify = current_app.config.get("AD_TLS_VERIFY", True)
        self.group_admin = current_app.config.get("AD_GROUP_ADMIN", "IPAM-Admins")
        self.group_rw = current_app.config.get("AD_GROUP_READWRITE", "IPAM-ReadWrite")
        self.group_ro = current_app.config.get("AD_GROUP_READONLY", "IPAM-ReadOnly")
        self.ca_file = current_app.config.get("AD_CA_FILE", "")
        self.admin_users = current_app.config.get("AD_ADMIN_USERS", [])

    def _get_server(self):
        if not LDAP3_AVAILABLE:
            raise RuntimeError("ldap3 library not installed")
        tls = None
        if self.use_ssl:
            import ssl
            tls = Tls(
                validate=ssl.CERT_REQUIRED if self.tls_verify else ssl.CERT_NONE,
                ca_certs_file=self.ca_file or None,
            )
        return Server(self.server_uri, use_ssl=self.use_ssl, tls=tls, get_info=ALL)

    def _bind_service_account(self):
        """Bind with the service account for directory searches."""
        server = self._get_server()
        conn = Connection(
            server,
            user=self.bind_user,
            password=self.bind_pass,
            authentication=ldap3.SIMPLE,
            auto_bind=True,
        )
        return conn

    def authenticate_user(self, username, password):
        """
        Authenticate a user against AD.
        Returns (success: bool, user_info: dict | None, error: str | None)
        """
        if not self.enabled or not LDAP3_AVAILABLE:
            return False, None, "AD authentication not configured"

        try:
            # First, find the user's DN via service account
            svc_conn = self._bind_service_account()
            svc_conn.search(
                search_base=self.user_search_base,
                search_filter=f"(&(objectClass=user)(sAMAccountName={ldap3.utils.conv.escape_filter_chars(username)}))",
                search_scope=SUBTREE,
                attributes=[
                    "distinguishedName", "sAMAccountName", "mail",
                    "displayName", "memberOf", "userAccountControl",
                ],
            )
            if not svc_conn.entries:
                return False, None, "User not found in directory"

            entry = svc_conn.entries[0]
            user_dn = str(entry.distinguishedName)

            # Check account is not disabled (UAC flag 2 = disabled)
            uac = int(entry.userAccountControl.value) if entry.userAccountControl else 0
            if uac & 2:
                return False, None, "Account is disabled"

            # Now bind as the user to verify password
            server = self._get_server()
            user_conn = Connection(
                server,
                user=user_dn,
                password=password,
                authentication=ldap3.SIMPLE,
            )
            if not user_conn.bind():
                return False, None, "Invalid credentials"

            groups = [str(g) for g in entry.memberOf] if entry.memberOf else []
            user_info = {
                "dn": user_dn,
                "username": str(entry.sAMAccountName),
                "email": str(entry.mail) if entry.mail else f"{username}@{self.domain}",
                "display_name": str(entry.displayName) if entry.displayName else username,
                "groups_dn": groups,
                "role": self._resolve_role(groups),
            }
            if str(entry.sAMAccountName).lower() in self.admin_users:
                from app.models import Role
                user_info["role"] = Role.ADMIN
            return True, user_info, None

        except LDAPBindError:
            return False, None, "Invalid credentials"
        except LDAPException as e:
            log.error("LDAP error during authentication: %s", e)
            return False, None, f"Directory error: {e}"
        except Exception as e:
            log.error("Unexpected error during AD auth: %s", e)
            return False, None, "Authentication service error"

    def _resolve_role(self, groups_dn: list) -> str:
        """Map AD group membership to IPAM role. Admin > ReadWrite > ReadOnly."""
        from app.models import Role
        group_names = [dn.split(",")[0].replace("CN=", "").strip() for dn in groups_dn]
        if self.group_admin in group_names:
            return Role.ADMIN
        if self.group_rw in group_names:
            return Role.READWRITE
        if self.group_ro in group_names:
            return Role.READONLY
        return Role.READONLY

    def sync_user_groups(self, user_dn: str) -> list:
        """Return list of IPAM-relevant AD group names for a user DN."""
        if not self.enabled or not LDAP3_AVAILABLE:
            return []
        try:
            conn = self._bind_service_account()
            conn.search(
                search_base=self.group_search_base,
                search_filter=f"(&(objectClass=group)(member={ldap3.utils.conv.escape_filter_chars(user_dn)}))",
                search_scope=SUBTREE,
                attributes=["cn", "distinguishedName"],
            )
            return [
                {"cn": str(e.cn), "dn": str(e.distinguishedName)}
                for e in conn.entries
            ]
        except Exception as e:
            log.error("Group sync error for %s: %s", user_dn, e)
            return []

    def test_connection(self, force: bool = False) -> dict:
        """Test AD connectivity and return status dict (force=True tests even while AD login is switched off)."""
        if not self.enabled and not force:
            return {"ok": False, "message": "AD integration disabled"}
        if not LDAP3_AVAILABLE:
            return {"ok": False, "message": "ldap3 package not installed"}
        try:
            conn = self._bind_service_account()
            return {"ok": True, "message": f"Connected to {self.server_uri} as {self.bind_user}"}
        except Exception as e:
            return {"ok": False, "message": str(e)}
