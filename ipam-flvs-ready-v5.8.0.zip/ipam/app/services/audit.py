"""
Audit logging service — records all create/update/delete/login actions.
"""
import json
import logging
from datetime import datetime, timezone
from flask import request, has_request_context
from flask_login import current_user
from app import db
from app.models import AuditLog

log = logging.getLogger(__name__)


def _get_client_ip():
    if not has_request_context():
        return None
    return request.headers.get("X-Forwarded-For", request.remote_addr)


def _get_username():
    if has_request_context() and current_user and current_user.is_authenticated:
        return current_user.username
    return "system"


def _get_user_id():
    if has_request_context() and current_user and current_user.is_authenticated:
        return current_user.id
    return None


def log_action(action: str, resource_type: str, resource_id=None,
               resource_repr: str = "", details=None, username: str = None,
               user_id: int = None):
    """
    Record an audit event.

    action       : CREATE | UPDATE | DELETE | LOGIN | LOGOUT | API_ACCESS | etc.
    resource_type: subnet | ip_address | user | group | vlan | auth
    resource_id  : primary key or identifier of the affected record
    resource_repr: human-readable label (e.g. "10.0.0.5 (web-server-01)")
    details      : dict or string with before/after or description
    """
    try:
        entry = AuditLog(
            user_id=user_id or _get_user_id(),
            username=username or _get_username(),
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            resource_repr=resource_repr,
            details=json.dumps(details) if isinstance(details, dict) else details,
            ip_address=_get_client_ip(),
            timestamp=datetime.now(timezone.utc),
        )
        db.session.add(entry)
        db.session.commit()
    except Exception as e:
        log.error("Failed to write audit log: %s", e)


def diff_objects(before: dict, after: dict) -> dict:
    """Return a dict of changed fields: {field: {before: x, after: y}}"""
    changes = {}
    all_keys = set(before) | set(after)
    for k in all_keys:
        b, a = before.get(k), after.get(k)
        if b != a:
            changes[k] = {"before": b, "after": a}
    return changes
