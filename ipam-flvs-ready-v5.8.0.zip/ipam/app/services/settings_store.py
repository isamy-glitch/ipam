"""
Sign-in settings that can be edited in the web GUI (Administration > Sign-in Settings).

Values saved here live in the `app_settings` table and OVERRIDE the same names in /etc/ipam/ipam.env, so the
command-line helpers (ipam-enable-entra / ipam-enable-ad) keep working as the starting point. Secrets (the Entra client
secret, the LDAP bind password) are encrypted with a key derived from SECRET_KEY before they are stored.

Every request compares a tiny version marker in the table with the one this worker last loaded, so a change saved
through one gunicorn worker is picked up by all of them on their next request - no restart needed.
"""
import base64
import hashlib
import logging
from datetime import datetime, timezone

from flask import current_app

log = logging.getLogger(__name__)

VERSION_KEY = "_version"

# key -> (type, is_secret).  Types: str, bool, list (comma separated, lower-cased)
ENTRA_KEYS = {
    "ENTRA_ENABLED": ("bool", False), "ENTRA_TENANT_ID": ("str", False), "ENTRA_CLIENT_ID": ("str", False),
    "ENTRA_CLIENT_SECRET": ("str", True), "ENTRA_REDIRECT_URI": ("str", False),
    "ENTRA_ROLE_ADMIN": ("str", False), "ENTRA_ROLE_READWRITE": ("str", False), "ENTRA_ROLE_READONLY": ("str", False),
    "ENTRA_GROUP_ADMIN": ("str", False), "ENTRA_GROUP_READWRITE": ("str", False), "ENTRA_GROUP_READONLY": ("str", False),
    "ENTRA_ADMIN_USERS": ("list", False), "ENTRA_REQUIRE_ROLE": ("bool", False), "ENTRA_LOCAL_LOGIN": ("bool", False),
}
LDAP_KEYS = {
    "AD_ENABLED": ("bool", False), "AD_SERVER": ("str", False), "AD_DOMAIN": ("str", False), "AD_BASE_DN": ("str", False),
    "AD_BIND_USER": ("str", False), "AD_BIND_PASS": ("str", True), "AD_USER_SEARCH_BASE": ("str", False),
    "AD_GROUP_SEARCH_BASE": ("str", False), "AD_GROUP_ADMIN": ("str", False), "AD_GROUP_READWRITE": ("str", False),
    "AD_GROUP_READONLY": ("str", False), "AD_USE_SSL": ("bool", False), "AD_TLS_VERIFY": ("bool", False),
    "AD_CA_FILE": ("str", False), "AD_FALLBACK_LOCAL": ("bool", False), "AD_ADMIN_USERS": ("list", False),
}
DNS_KEYS = {"DNS_ENV_DOMAINS": ("str", False)}
SPEC = {**ENTRA_KEYS, **LDAP_KEYS, **DNS_KEYS}


# ── encryption ──────────────────────────────────────────────────────────────
def _fernet():
    from cryptography.fernet import Fernet
    key = base64.urlsafe_b64encode(hashlib.sha256(current_app.config["SECRET_KEY"].encode()).digest())
    return Fernet(key)


def encrypt(plain: str) -> str:
    return _fernet().encrypt(plain.encode()).decode()


def decrypt(token: str):
    """Plain text, or None if the token can't be read (SECRET_KEY changed)."""
    from cryptography.fernet import InvalidToken
    try:
        return _fernet().decrypt(token.encode()).decode()
    except (InvalidToken, ValueError):
        return None


# ── conversion ──────────────────────────────────────────────────────────────
def _to_config(kind, raw):
    if kind == "bool":
        return str(raw).strip().lower() == "true"
    if kind == "list":
        return [x.strip().lower() for x in str(raw or "").split(",") if x.strip()]
    return raw if raw is not None else ""


def _to_text(kind, value):
    if kind == "bool":
        return "true" if value else "false"
    if kind == "list":
        return ",".join(value) if isinstance(value, (list, tuple, set)) else str(value or "")
    return "" if value is None else str(value)


# ── load / refresh ──────────────────────────────────────────────────────────
def _db_version():
    from app.models import AppSetting
    row = AppSetting.query.get(VERSION_KEY)
    return row.value if row else "0"


def apply(app=None):
    """Copy every saved setting into app.config (overriding the env-file value). Returns the keys applied."""
    from app import db
    from app.models import AppSetting
    app = app or current_app._get_current_object()
    applied = []
    unreadable = []
    for row in AppSetting.query.all():
        if row.key not in SPEC:
            continue
        kind, secret = SPEC[row.key]
        raw = row.value
        if secret and raw:
            raw = decrypt(raw)
            if raw is None:
                unreadable.append(row.key)
                continue
        app.config[row.key] = _to_config(kind, raw)
        applied.append(row.key)
    app.config["_SETTINGS_UNREADABLE"] = unreadable
    app.config["_SETTINGS_VER"] = _db_version()
    return applied


def refresh_if_changed(app):
    """Cheap per-request check (one tiny query). Never raises: a missing table just means 'nothing saved yet'."""
    from app import db
    try:
        ver = _db_version()
        if ver != app.config.get("_SETTINGS_VER"):
            apply(app)
    except Exception as exc:
        db.session.rollback()
        if not app.config.get("_SETTINGS_WARNED"):
            app.config["_SETTINGS_WARNED"] = True
            log.warning("Could not read GUI settings (run: sudo ipam-admin upgrade-db): %s", exc)


def save(values: dict, username: str = ""):
    """
    values: {KEY: python value}. A secret given as None/"" is left unchanged. Returns the list of changed keys
    (names only - never values). Caller has already validated.
    """
    import uuid
    from app import db
    from app.models import AppSetting
    changed = []
    now = datetime.now(timezone.utc)
    for key, value in values.items():
        kind, secret = SPEC[key]
        if secret and not value:
            continue
        text = _to_text(kind, value)
        row = AppSetting.query.get(key)
        stored = encrypt(text) if secret else text
        if row is None:
            db.session.add(AppSetting(key=key, value=stored, is_secret=secret, updated_at=now, updated_by=username))
            changed.append(key)
        else:
            old = decrypt(row.value) if secret and row.value else row.value
            if old != text:
                changed.append(key)
            row.value, row.is_secret, row.updated_at, row.updated_by = stored, secret, now, username
    ver = AppSetting.query.get(VERSION_KEY)
    marker = uuid.uuid4().hex
    if ver is None:
        db.session.add(AppSetting(key=VERSION_KEY, value=marker, updated_at=now, updated_by=username))
    else:
        ver.value, ver.updated_at, ver.updated_by = marker, now, username
    db.session.commit()
    apply()
    return changed


def saved_keys() -> set:
    from app.models import AppSetting
    return {r.key for r in AppSetting.query.all() if r.key in SPEC}
