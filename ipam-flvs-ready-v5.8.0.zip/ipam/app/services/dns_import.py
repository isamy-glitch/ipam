"""
Import DNS zone exports (Windows DNS Manager "Export List": tab separated Name / Type / Data / Timestamp) into IPAM -
one file per zone (prod.local, flvs.net, qa.local, ...) - and line the DNS names up with the server inventory.

Phase 1 - per zone (run_import)
  * every A / CNAME record is stored in `dns_records` under its zone. Importing a zone again replaces only that zone,
    so zones can arrive one at a time and in any order.
  * IP already in IPAM: hostname empty -> filled from DNS; hostname different -> kept and listed as a conflict;
    status Free -> Assigned (listed); the DNS Name field is set when it is empty or already belongs to this zone.
  * IP not in IPAM: added (inside the most specific subnet, else a new /24 is created). Public/internet addresses that
    are not inside an IPAM subnet are NOT added (only kept in the zone's DNS records) unless include_public=True.
  * dynamic records not refreshed for 30+ days (relative to the newest stamp in the file) are flagged, never deleted.

Phase 2 - from the server inventory (align_server_names; runs after every import)
  * every ACTIVE server gets the DNS name  <server name>.<domain>  on the server record and on each of its IPs.
  * the domain comes from, in this order: a domain already in the server's name (host.prod.local); the zone(s) that
    hold a record for one of the server's IPs; the server's Environment through the mapping
    ("Prod Colo=prod.local", ...) - only zones that have been imported are used.
  * the expected name is checked against the zone: "missing-in-dns" (no such record) or "ip-mismatch"
    (the record exists but points at a different IP than IPAM holds for the server) are listed in the report.

Nothing here touches the DNS server; it only reads the exported files.
"""
import ipaddress
import re
from collections import Counter, defaultdict
from datetime import datetime

from flask import current_app

from app import db
from app.models import Subnet, IPAddress, IPStatus, Server, ServerStatus, DnsRecord
from app.services.runbook_import import SubnetIndex, DERIVED_TAG

APEX = "(same as parent folder)"
IMPORT_TAG = "dns-import"
ALSO_PREFIX = "DNS also:"          # written by v5.6; removed now that records live in their own table
STALE_DAYS = 30
LABEL_RE = re.compile(r"^[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?$")


# ── parsing ──────────────────────────────────────────────────────────────────

def _parse_stamp(text):
    """'static' -> (True, None); '?10/?14/?2026 1:00:00 AM' -> (False, datetime); blank -> (False, None)."""
    t = (text or "").strip()
    if t.lower() == "static":
        return True, None
    t = t.replace("?", "")
    for fmt in ("%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y"):
        try:
            return False, datetime.strptime(t, fmt)
        except ValueError:
            pass
    return False, None


def detect_zone(soa_data, ns_targets):
    """Zone name from the SOA hostmaster and the name servers: dc01.prod.local -> prod.local."""
    ns = Counter(".".join(t.split(".")[1:]) for t in ns_targets if t.count(".") >= 2)
    soa = ""
    m = re.match(r"\[\d+\]\s*,\s*([^,\s]+)\s*,\s*([^,\s]+)", soa_data or "")
    if m:
        rp = m.group(2).rstrip(".").lower()
        soa = ".".join(rp.split(".")[1:]) if rp.count(".") >= 2 else ""
    if soa and soa in ns:
        return soa
    if ns:
        return ns.most_common(1)[0][0]
    return soa


def parse_zone(text, zone=None):
    """Return (zone_name, records). records: dicts with name(lower; '@' = apex), type, data, static, stamp."""
    records, ns_targets, soa = [], [], ""
    for ln in text.lstrip("﻿").splitlines():
        cols = ln.rstrip("\r\n").split("\t")
        if len(cols) < 3 or (cols[0].strip().lower() == "name" and cols[1].strip().lower() == "type"):
            continue
        name, rtype, data = cols[0].strip(), cols[1].strip(), cols[2].strip()
        stamp = cols[3] if len(cols) > 3 else ""
        if not rtype:                      # a sub-folder row (_msdcs, _sites, ...)
            continue
        static, when = _parse_stamp(stamp)
        name = "@" if name == APEX else name.lower()
        kind = rtype[rtype.index("(") + 1:rtype.rindex(")")].upper() if "(" in rtype else rtype.upper()
        records.append({"name": name, "type": kind, "data": data, "static": static, "stamp": when})
        if kind == "NS":
            ns_targets.append(data.rstrip(".").lower())
        elif kind == "SOA":
            soa = data
    if not zone:
        zone = detect_zone(soa, ns_targets)
    return zone.lower().strip("."), records


# ── report ───────────────────────────────────────────────────────────────────

class Report:
    def __init__(self, zone=""):
        self.zone = zone
        self.rows = []                      # (action, ip, dns_name, ipam_hostname, detail)
        self.counts = Counter()
        self.compact = False                # True: summary() lists only the lines that are not zero

    def add(self, action, ip="", dns="", host="", detail=""):
        self.rows.append((action, ip, dns, host, detail))

    LABELS = [
        ("records_a", "A records read"), ("records_cname", "CNAME aliases read"), ("unique_ips", "Distinct IP addresses"),
        ("added", "IPs added to IPAM"), ("added_static", "   ...from static records"), ("added_dynamic", "   ...from dynamic records"),
        ("public_skipped", "Public (internet) IPs kept in DNS records only, not added to IPAM"),
        ("subnets_created", "Subnets auto-created (/24)"), ("server_linked", "New IPs linked to a server record"), ("existing", "IPs already in IPAM"),
        ("name_matched", "   ...hostname already matched DNS"), ("name_filled", "   ...hostname was empty, filled from DNS"),
        ("name_conflict", "   ...hostname DIFFERS from DNS (kept, see report)"),
        ("reactivated", "Free IPs set to Assigned (DNS says in use)"),
        ("stale", "Dynamic records not refreshed for 30+ days"),
        ("servers_checked", "Servers checked (active)"), ("server_dns_set", "Server DNS names set / changed"),
        ("ip_dns_set", "IP DNS Name fields set from server names"), ("dns_ok", "Server names found in DNS (IP agrees)"),
        ("dns_missing", "Server names MISSING in DNS"), ("dns_ip_mismatch", "Server names in DNS with a DIFFERENT IP"),
        ("no_domain", "Servers with no known domain (see report)"), ("bad_name", "Server names unusable as DNS names"),
        ("warnings", "Warnings"),
        ("dns_records_removed", "DNS records removed"), ("ips_removed", "IPs removed (added by a DNS import)"),
        ("tags_cleared", "Existing IPs: dns-import tag removed"), ("subnets_removed", "Auto-created subnets removed"),
    ]

    def summary(self):
        return "\n".join(f"  {label:<52} {self.counts.get(k, 0)}" for k, label in self.LABELS
                         if self.counts.get(k, 0) or (not self.compact and not label.startswith("   ")))

    def summary_rows(self):
        return [(label.strip(), self.counts.get(k, 0)) for k, label in self.LABELS if self.counts.get(k, 0)]

    def to_csv_rows(self):
        return [("action", "ip", "dns_name", "ipam_hostname", "detail")] + list(self.rows)


# ── helpers ──────────────────────────────────────────────────────────────────

def _fqdn(name, zone):
    return zone if name == "@" else (name if (not zone or name.endswith("." + zone)) else f"{name}.{zone}")


def _short(name):
    return name.split(".")[0].lower()


def _strip_also(description):
    kept = [ln for ln in (description or "").splitlines() if not ln.startswith(ALSO_PREFIX)]
    return "\n".join(kept).strip() or None


def _add_tag(tags, tag):
    parts = [t.strip() for t in (tags or "").split(",") if t.strip()]
    if tag not in parts:
        parts.append(tag)
    return ",".join(parts)


def _subnet_for(ip, subnets, zone, report):
    s = subnets.find(ip)
    if s:
        return s
    net = ipaddress.ip_network(f"{ip}/24", strict=False)
    s = Subnet.query.filter_by(network=str(net)).first()
    if not s:
        s = Subnet(network=str(net), name=f"Imported {net}", tags=DERIVED_TAG,
                   description=f"Created automatically from the {zone} DNS zone export. The /24 mask is an assumption - "
                               "edit the subnet if the real range is different.")
        db.session.add(s)
        db.session.flush()
        report.counts["subnets_created"] += 1
    subnets.add(s)
    return s


def env_domains(text=None):
    """{'prod colo': 'prod.local', ...} from the 'environment=domain' lines of DNS_ENV_DOMAINS."""
    if text is None:
        text = current_app.config.get("DNS_ENV_DOMAINS", "")
    out = {}
    for ln in (text or "").splitlines():
        if "=" in ln:
            k, v = ln.split("=", 1)
            if k.strip() and v.strip():
                out[k.strip().lower()] = v.strip().lower().strip(".")
    return out


def imported_zones():
    """[(zone, record count, last imported)] for the zones already loaded."""
    rows = db.session.query(DnsRecord.zone, db.func.count(DnsRecord.id), db.func.max(DnsRecord.imported_at)) \
        .group_by(DnsRecord.zone).order_by(DnsRecord.zone).all()
    return [(z, n, t) for z, n, t in rows]


# ── phase 1: one zone ────────────────────────────────────────────────────────

def _import_zone(text, zone, report, include_public=False):
    zone, records = parse_zone(text, zone)
    report.zone = zone
    if not records or not zone:
        report.add("warning", detail="No DNS records or zone name found - is this a DNS Manager export "
                                     "(Name / Type / Data / Timestamp)? You can type the zone name in the Zone box.")
        report.counts["warnings"] += 1
        return False

    a_by_ip = defaultdict(list)
    ips_of_name = defaultdict(set)
    cnames = []
    for r in records:
        if r["type"] == "A":
            try:
                addr = ipaddress.ip_address(r["data"])
            except ValueError:
                report.add("warning", detail=f"'{r['data']}' ({r['name']}) is not an IPv4 address - skipped")
                report.counts["warnings"] += 1
                continue
            if addr.version != 4 or addr.is_loopback or addr.is_link_local or addr.is_multicast or addr.is_unspecified:
                report.add("warning", str(addr), r["name"], detail="not a usable host address - skipped")
                report.counts["warnings"] += 1
                continue
            report.counts["records_a"] += 1
            a_by_ip[str(addr)].append(r)
            ips_of_name[r["name"]].add(str(addr))
        elif r["type"] == "CNAME":
            report.counts["records_cname"] += 1
            cnames.append(r)
    report.counts["unique_ips"] = len(a_by_ip)

    # CNAME -> the IPs of its target
    cname_ips = {}
    for c in cnames:
        target = c["data"].rstrip(".").lower()
        tname = "@" if target == zone else (target[: -len(zone) - 1] if target.endswith("." + zone) else None)
        hit = sorted(ips_of_name.get(tname, ())) if tname is not None else []
        if not hit:
            where = "outside this zone" if tname is None else "no A record in this zone"
            report.add("alias-unresolved", "", _fqdn(c["name"], zone), "", f"CNAME -> {target} ({where})")
        cname_ips[id(c)] = hit

    newest = max((r["stamp"] for r in records if r["stamp"]), default=None)

    subnets = SubnetIndex()
    subnets.load()
    existing = defaultdict(list)
    addrs = list(a_by_ip)
    for i in range(0, len(addrs), 500):
        for row in IPAddress.query.filter(IPAddress.address.in_(addrs[i:i + 500])).all():
            existing[row.address].append(row)
    servers = {}
    for s in Server.query.all():
        servers.setdefault(s.name.lower(), s)
        if "." in s.name:
            servers.setdefault(s.name.split(".")[0].lower(), s)

    servers_with_ips = {sid for (sid,) in db.session.query(IPAddress.server_id).filter(IPAddress.server_id.isnot(None)).distinct()}
    row_of_ip = {}
    for ip in sorted(a_by_ip, key=lambda x: tuple(int(p) for p in x.split("."))):
        entries = a_by_ip[ip]
        named = [e for e in entries if e["name"] != "@"] or entries
        named.sort(key=lambda e: (not e["static"], e["name"]))
        primary = named[0]
        names = [e["name"] for e in named]
        fq_primary = _fqdn(primary["name"], zone)

        stamps = [e["stamp"] for e in entries if not e["static"] and e["stamp"]]
        if not any(e["static"] for e in entries) and stamps and newest and all((newest - t).days >= STALE_DAYS for t in stamps):
            report.counts["stale"] += 1
            report.add("stale-dynamic", ip, fq_primary, "",
                       f"dynamic record last refreshed {max(stamps):%Y-%m-%d} (file newest: {newest:%Y-%m-%d})")

        rows = existing.get(ip)
        if rows:
            row = sorted(rows, key=lambda r_: -ipaddress.ip_network(r_.subnet.network, strict=False).prefixlen)[0]
            report.counts["existing"] += 1
            host = (row.hostname or "").strip()
            matched = next((n for n in names if host and (host.lower() == n or host.lower() == _fqdn(n, zone).lower()
                                                           or _short(host) == _short(n))), None)
            fqdn = _fqdn(matched or primary["name"], zone)
            if row.status == IPStatus.FREE:
                row.status = IPStatus.ASSIGNED
                row.hostname = host or primary["name"]
                report.counts["reactivated"] += 1
                report.add("reactivated", ip, fqdn, host, "was Free in IPAM but has a DNS record - set to Assigned")
            elif not host:
                row.hostname = primary["name"]
                report.counts["name_filled"] += 1
                report.add("hostname-filled", ip, fqdn, "", "IPAM had no hostname; taken from DNS")
            elif matched:
                report.counts["name_matched"] += 1
            else:
                report.counts["name_conflict"] += 1
                report.add("name-conflict", ip, fqdn, host, "IPAM hostname kept (the DNS record is stored with the IP)")
            cur = (row.dns_name or "").lower()
            if row.server_id:
                if not cur:                       # the server-name step (phase 2) decides for server IPs; this is only the fallback
                    row.dns_name = fqdn
            elif not cur or cur.endswith("." + zone) or cur == zone:     # never overwrite a name from another zone
                row.dns_name = fqdn
            row.description = _strip_also(row.description) if (row.description or "").find(ALSO_PREFIX) >= 0 else row.description
            row.tags = _add_tag(row.tags, IMPORT_TAG)
            row_of_ip[ip] = row
            continue

        if not include_public and not ipaddress.ip_address(ip).is_private and subnets.find(ip) is None:
            # an internet address (web/mail/ADFS records of a public zone): it stays in the zone's DNS records but is not
            # an address we manage, so it must not create a /24 subnet or an IP row in IPAM
            report.counts["public_skipped"] += 1
            report.add("public-skipped", ip, fq_primary, "", "public IP address, not inside any IPAM subnet - not added to IPAM")
            continue
        sub = _subnet_for(ip, subnets, zone, report)
        kind = "static" if primary["static"] else "dynamic"
        stamp = f", last registered {primary['stamp']:%Y-%m-%d %H:%M}" if primary["stamp"] else ""
        srv = servers.get(primary["name"]) if primary["name"] != "@" else None
        if srv is not None and srv.status == ServerStatus.DECOMMISSIONED:
            report.add("warning", ip, fq_primary, "", f"DNS still has a record for decommissioned server {srv.name} - added anyway, review/remove in DNS")
            report.counts["warnings"] += 1
            srv = None
        elif srv is not None and srv.id in servers_with_ips:
            # the server already has addresses in IPAM and this one is not among them: don't silently add it to the
            # server - the name check in phase 2 reports it as an IP mismatch instead
            report.add("ip-differs-from-server", ip, fq_primary, "", f"server {srv.name} already has other addresses in IPAM; this IP was added unlinked")
            srv = None
        new = IPAddress(address=ip, subnet_id=sub.id, status=IPStatus.ASSIGNED,
                        hostname=primary["name"] if primary["name"] != "@" else zone, dns_name=fq_primary,
                        description=f"Added from the {zone} DNS zone export ({kind} record{stamp}).",
                        tags=IMPORT_TAG, server_id=srv.id if srv else None)
        if srv is not None:
            new.interface = "DNS"
            report.counts["server_linked"] += 1
        db.session.add(new)
        row_of_ip[ip] = new
        report.counts["added"] += 1
        report.counts["added_static" if primary["static"] else "added_dynamic"] += 1
        report.add("added", ip, fq_primary, "", f"{kind}; subnet {sub.network}" + ("; linked to server " + srv.name if srv else ""))

    db.session.flush()

    # replace this zone's stored records
    DnsRecord.query.filter_by(zone=zone).delete(synchronize_session=False)
    now = datetime.utcnow()
    for r in records:
        if r["type"] == "A":
            if r["data"] not in a_by_ip:             # skipped above (loopback / not an IPv4 address)
                continue
            row = row_of_ip.get(r["data"])
            srv = servers.get(r["name"]) if r["name"] != "@" else None
            db.session.add(DnsRecord(zone=zone, name=r["name"], fqdn=_fqdn(r["name"], zone), rtype="A", data=r["data"],
                                     is_static=r["static"], stamp=r["stamp"], imported_at=now,
                                     ip_id=row.id if row else None,
                                     server_id=(srv.id if srv else (row.server_id if row else None))))
        elif r["type"] == "CNAME":
            hit = cname_ips.get(id(r), [])
            row = row_of_ip.get(hit[0]) if hit else None
            db.session.add(DnsRecord(zone=zone, name=r["name"], fqdn=_fqdn(r["name"], zone), rtype="CNAME",
                                     data=r["data"].rstrip(".").lower(), is_static=r["static"], stamp=r["stamp"],
                                     imported_at=now, ip_id=row.id if row else None,
                                     server_id=row.server_id if row else None))
    db.session.flush()
    return True


# ── phase 2: names from the server inventory ─────────────────────────────────

def _split_name(name, zones):
    """'c1host01.prod.local' -> ('c1host01', 'prod.local'); 'app2004' -> ('app2004', None); unknown suffix -> (name, '?')."""
    n = (name or "").strip().lower()
    if "." not in n:
        return n, None
    label, rest = n.split(".", 1)
    return (label, rest) if rest in zones else (n, "?")


def align_server_names(report):
    zones = {z for (z,) in db.session.query(DnsRecord.zone).distinct()}
    if not zones:
        report.add("info", detail="No DNS zone has been imported yet - server names were not checked.")
        return
    envmap = env_domains()

    a_recs = defaultdict(list)                      # (zone, label) -> [DnsRecord]
    zones_of_ip = defaultdict(set)                  # ip_id -> zones with an A record for it
    names_at_ip = defaultdict(list)                 # ip_id -> fqdns DNS has for it
    for r in DnsRecord.query.filter_by(rtype="A").all():
        a_recs[(r.zone, r.name)].append(r)
        if r.ip_id:
            zones_of_ip[r.ip_id].add(r.zone)
            names_at_ip[r.ip_id].append(r.fqdn)

    ips_of_server = defaultdict(list)
    for ip in IPAddress.query.filter(IPAddress.server_id.isnot(None)).all():
        ips_of_server[ip.server_id].append(ip)

    for srv in Server.query.filter_by(status=ServerStatus.ACTIVE).order_by(Server.name).all():
        label, forced = _split_name(srv.name, zones)
        report.counts["servers_checked"] += 1
        if forced == "?":
            # a full name in some domain we have no zone for: take it as it is
            if srv.dns_name != label:
                srv.dns_name = label
                report.counts["server_dns_set"] += 1
            for ip in ips_of_server.get(srv.id, []):
                if ip.dns_name != label:
                    ip.dns_name = label
                    report.counts["ip_dns_set"] += 1
            report.add("info", "", label, srv.name, "name already contains a domain without an imported zone - kept as the DNS name")
            continue
        if not LABEL_RE.match(label) or label.isdigit():
            report.counts["bad_name"] += 1
            report.add("bad-name", "", "", srv.name, "server name can't be used as a DNS host name (spaces/odd characters or only digits)")
            continue

        mine = ips_of_server.get(srv.id, [])
        zset = set()
        how = ""
        if forced and forced in zones:
            zset, how = {forced}, "domain in the server name"
        else:
            for ip in mine:
                zset |= zones_of_ip.get(ip.id, set())
            how = "zone that holds one of its IPs"
            if not zset:
                dom = envmap.get((srv.environment or "").strip().lower())
                if dom and dom in zones:
                    zset, how = {dom}, f"environment '{srv.environment}'"
        if not zset:
            report.counts["no_domain"] += 1
            dom = envmap.get((srv.environment or "").strip().lower())
            why = (f"environment '{srv.environment}' maps to {dom}, whose zone has not been imported" if dom
                   else f"no DNS record for its IPs and no domain mapped for environment '{srv.environment or '(blank)'}'")
            report.add("no-domain", ", ".join(i.address for i in mine), "", srv.name, why)
            continue

        env_zone = envmap.get((srv.environment or "").strip().lower())
        primary_zone = env_zone if env_zone in zset else sorted(zset)[0]
        primary = f"{label}.{primary_zone}"
        if srv.dns_name != primary:
            srv.dns_name = primary
            report.counts["server_dns_set"] += 1
        for ip in mine:
            if ip.dns_name != primary:
                ip.dns_name = primary
                report.counts["ip_dns_set"] += 1

        my_addrs = {i.address for i in mine}
        for z in sorted(zset):
            recs = a_recs.get((z, label), [])
            fq = f"{label}.{z}"
            for r in recs:
                r.server_id = srv.id
            if not recs:
                report.counts["dns_missing"] += 1
                there = sorted({n for i in mine for n in names_at_ip.get(i.id, [])})
                hint = f"; DNS has {', '.join(there)} at its IP" if there else "; DNS has nothing at its IP"
                if srv.old_name and any(n.split(".")[0] == srv.old_name.strip().lower() for n in there):
                    hint += " (that is the server's old name)"
                report.add("missing-in-dns", ", ".join(sorted(my_addrs)), fq, srv.name, f"no A record for {fq} in the {z} zone ({how}){hint}")
            elif my_addrs and not ({r.data for r in recs} & my_addrs):
                report.counts["dns_ip_mismatch"] += 1
                report.add("ip-mismatch", ", ".join(sorted(my_addrs)), fq, srv.name,
                           f"DNS has {fq} at {', '.join(sorted({r.data for r in recs}))} but IPAM has the server at {', '.join(sorted(my_addrs))}")
            else:
                report.counts["dns_ok"] += 1


# ── entry points ─────────────────────────────────────────────────────────────

def _finish(dry_run):
    try:
        if dry_run:
            db.session.rollback()
        else:
            db.session.commit()
    except Exception:
        db.session.rollback()
        raise


def run_import(text, dry_run=False, zone=None, align=True, include_public=False):
    """Import one zone export, then (align=True) line server DNS names up. dry_run=True rolls everything back."""
    report = Report(zone or "")
    try:
        ok = _import_zone(text, zone, report, include_public=include_public)
        if ok and align:
            align_server_names(report)
    except Exception:
        db.session.rollback()
        raise
    _finish(dry_run)
    return report


def run_align(dry_run=False):
    """Re-run only phase 2 (after changing the environment->domain mapping or importing a zone)."""
    report = Report("")
    report.compact = True
    try:
        align_server_names(report)
    except Exception:
        db.session.rollback()
        raise
    _finish(dry_run)
    return report


# ── undo: remove what the DNS imports loaded ─────────────────────────────────

def reset_dns(dry_run=False, keep_zones=()):
    """Remove everything the DNS imports put into IPAM, so the zones can be loaded again from a clean state.

    * all stored DNS records (the per-zone table) - except zones listed in keep_zones;
    * IP addresses that were ADDED by an import (description still starts "Added from the <zone> DNS zone export", tag
      dns-import) - never an IP that existed before the import, never one whose description was edited;
    * "Imported x.x.x.0/24" subnets that an import created, but only when they are empty again;
    * the dns-import tag on the IPs that already existed.
    DNS Name fields are left alone (the next import / align sets them again).
    """
    rep = Report("")
    rep.compact = True
    keep = {z.lower().strip(".") for z in keep_zones}
    q = DnsRecord.query
    if keep:
        q = q.filter(~DnsRecord.zone.in_(keep))
    rep.counts["dns_records_removed"] = q.count()
    for ip in IPAddress.query.filter(IPAddress.tags.like("%" + IMPORT_TAG + "%")).all():
        tags = [t.strip() for t in (ip.tags or "").split(",") if t.strip()]
        auto = (ip.description or "").startswith("Added from the ") and "DNS zone export" in (ip.description or "")
        if auto and not any(z for z in keep if (ip.description or "").startswith(f"Added from the {z} ")):
            rep.add("ip-removed", ip.address, ip.dns_name or "", ip.hostname or "", "added by a DNS import")
            rep.counts["ips_removed"] += 1
            if not dry_run:
                DnsRecord.query.filter_by(ip_id=ip.id).update({"ip_id": None}, synchronize_session=False)
                db.session.delete(ip)
        else:
            rep.counts["tags_cleared"] += 1
            if not dry_run:
                ip.tags = ",".join(t for t in tags if t != IMPORT_TAG) or None
    if not dry_run:
        q.delete(synchronize_session=False)
        db.session.flush()
        for sub in Subnet.query.filter(Subnet.description.like("Created automatically from the % DNS zone export%")).all():
            if IPAddress.query.filter_by(subnet_id=sub.id).count() == 0:
                rep.add("subnet-removed", "", "", sub.network, "created by a DNS import and now empty")
                rep.counts["subnets_removed"] += 1
                db.session.delete(sub)
    else:
        for sub in Subnet.query.filter(Subnet.description.like("Created automatically from the % DNS zone export%")).all():
            n = IPAddress.query.filter_by(subnet_id=sub.id).count()
            left = IPAddress.query.filter(IPAddress.subnet_id == sub.id, ~IPAddress.description.like("Added from the % DNS zone export%")).count()
            if n and left == 0 or n == 0:
                rep.add("subnet-removed", "", "", sub.network, "created by a DNS import and would be empty")
                rep.counts["subnets_removed"] += 1
    _finish(dry_run)
    return rep
