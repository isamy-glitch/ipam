"""
DNS validation service.

Checks IPAM records against live DNS:
  * forward - does the record's name resolve (A/AAAA) to the IP we have on file?
  * reverse - does the IP's PTR record point back at that name?

Lookups go through the server's own resolver (getaddrinfo / gethostbyaddr), so on a
host whose /etc/resolv.conf points at your AD-integrated DNS servers this validates
against AD DNS. Note the OS resolver also honours /etc/hosts.

Nothing in here touches Flask or the database: callers pass plain dicts in and get
plain dicts out, which keeps the worker threads safe and the logic easy to test.
"""
import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeout

MAX_RECORDS = 500       # per run - keeps the page responsive
MAX_WORKERS = 16        # parallel lookups
OVERALL_TIMEOUT = 60    # seconds allowed for a whole run

# Per-direction (forward / reverse) statuses
OK = "ok"
MISSING = "missing"     # no record exists
MISMATCH = "mismatch"   # a record exists but points somewhere else
ERROR = "error"         # resolver failure (SERVFAIL, unreachable DNS server, ...)
TIMEOUT = "timeout"     # run budget ran out before this lookup finished

# getaddrinfo "name does not exist" error codes (EAI_NODATA is missing on some platforms)
_NOT_FOUND = {socket.EAI_NONAME, getattr(socket, "EAI_NODATA", socket.EAI_NONAME)}


def build_fqdn(name, domain=None):
    """Normalise a record name; append the subnet's DNS domain to short names."""
    name = (name or "").strip().rstrip(".").lower()
    if not name:
        return None
    if "." not in name and domain:
        name = f"{name}.{domain.strip().strip('.').lower()}"
    return name


def resolve_forward(name):
    """Return the set of IP strings `name` resolves to (empty set if it doesn't exist)."""
    try:
        infos = socket.getaddrinfo(name, None, proto=socket.IPPROTO_TCP)
    except socket.gaierror as e:
        if e.errno in _NOT_FOUND:
            return set()
        raise
    return {info[4][0].split("%")[0] for info in infos}


def resolve_reverse(ip):
    """Return the PTR name for `ip` (lower-case, no trailing dot) or None if there isn't one."""
    try:
        return socket.gethostbyaddr(ip)[0].rstrip(".").lower()
    except socket.herror as e:
        if e.args and e.args[0] in (1, 4):      # HOST_NOT_FOUND / NO_DATA
            return None
        raise
    except socket.gaierror as e:
        if e.errno in _NOT_FOUND:
            return None
        raise


def _same_ip(a, b):
    try:
        return ipaddress.ip_address(a) == ipaddress.ip_address(b)
    except ValueError:
        return a == b


def _names_match(ptr, fqdn):
    if ptr == fqdn:
        return True
    if "." not in fqdn:                         # short name, no domain known: compare host part
        return ptr.split(".")[0] == fqdn
    return False


def check_one(address, name, domain=None):
    """Run the forward and reverse checks for one record. Never raises."""
    fqdn = build_fqdn(name, domain)
    out = {"fqdn": fqdn, "forward": ERROR, "forward_detail": "", "reverse": ERROR, "reverse_detail": ""}
    if not fqdn:
        out["forward_detail"] = out["reverse_detail"] = "No hostname on record"
        out["ok"] = False
        return out

    try:
        found = resolve_forward(fqdn)
        if not found:
            out["forward"], out["forward_detail"] = MISSING, "No A/AAAA record"
        elif any(_same_ip(a, address) for a in found):
            out["forward"], out["forward_detail"] = OK, ", ".join(sorted(found))
        else:
            out["forward"], out["forward_detail"] = MISMATCH, "Resolves to " + ", ".join(sorted(found))
    except Exception as e:                      # resolver trouble is a result, not a crash
        out["forward"], out["forward_detail"] = ERROR, str(e)

    try:
        ptr = resolve_reverse(address)
        if ptr is None:
            out["reverse"], out["reverse_detail"] = MISSING, "No PTR record"
        elif _names_match(ptr, fqdn):
            out["reverse"], out["reverse_detail"] = OK, ptr
        else:
            out["reverse"], out["reverse_detail"] = MISMATCH, f"PTR is {ptr}"
    except Exception as e:
        out["reverse"], out["reverse_detail"] = ERROR, str(e)

    out["ok"] = out["forward"] == OK and out["reverse"] == OK
    return out


def run_checks(records, timeout=OVERALL_TIMEOUT, max_workers=MAX_WORKERS):
    """
    records: iterable of dicts with 'address' and 'name' (optional 'domain'; any other keys
    are passed through untouched). Returns a list of result dicts in the same order.
    Lookups that don't finish inside `timeout` seconds are reported as TIMEOUT.
    """
    records = list(records)
    if not records:
        return []
    done = {}
    executor = ThreadPoolExecutor(max_workers=max(1, min(max_workers, len(records))))
    futures = {
        executor.submit(check_one, r["address"], r["name"], r.get("domain")): i
        for i, r in enumerate(records)
    }
    try:
        for fut in as_completed(futures, timeout=timeout):
            done[futures[fut]] = fut.result()
    except FuturesTimeout:
        pass
    finally:
        executor.shutdown(wait=False, cancel_futures=True)

    results = []
    for i, rec in enumerate(records):
        res = done.get(i) or {
            "fqdn": build_fqdn(rec["name"], rec.get("domain")),
            "forward": TIMEOUT, "forward_detail": "Timed out",
            "reverse": TIMEOUT, "reverse_detail": "Timed out",
            "ok": False,
        }
        results.append({**rec, **res})
    return results


def summarize(results):
    ok = sum(1 for r in results if r["ok"])
    return {"total": len(results), "ok": ok, "issues": len(results) - ok}


def _read_nameservers(path):
    try:
        with open(path) as fh:
            return [ln.split()[1] for ln in fh if ln.startswith("nameserver") and len(ln.split()) > 1]
    except OSError:
        return []


def resolver_nameservers(path="/etc/resolv.conf", upstream_path="/run/systemd/resolve/resolv.conf"):
    """
    Nameservers the OS resolver will use - shown on the page so admins know what was queried.
    Ubuntu points /etc/resolv.conf at the local systemd-resolved stub (127.0.0.53); when that is
    all we see, show the real upstream servers (e.g. the domain DNS servers) instead.
    """
    servers = _read_nameservers(path)
    if servers and all(s.startswith("127.") for s in servers):
        upstream = _read_nameservers(upstream_path)
        if upstream:
            return upstream
    return servers
