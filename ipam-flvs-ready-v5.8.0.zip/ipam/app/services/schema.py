"""
Database schema upgrade.

There is no Alembic migration history in this project, so upgrades are done here, idempotently:
  * db.create_all() creates any table that doesn't exist yet (servers, web_apps, resource_links, ...)
  * columns added to *existing* tables are added with ALTER TABLE when missing

Safe to run any number of times, on MySQL and SQLite:  sudo ipam-admin upgrade-db
"""
import logging
from sqlalchemy import inspect, text
from app import db

log = logging.getLogger(__name__)

# (table, column, DDL type) — columns that older installs don't have yet.
NEW_COLUMNS = [
    ("ip_addresses", "server_id", "INTEGER"),
    ("ip_addresses", "interface", "VARCHAR(40)"),
    ("users", "entra_oid", "VARCHAR(64)"),
    ("servers", "dns_name", "VARCHAR(255)"),
]


def upgrade_schema():
    """Create missing tables and add missing columns. Returns a list of what it changed."""
    changes = []
    insp = inspect(db.engine)
    before = set(insp.get_table_names())

    db.create_all()
    insp = inspect(db.engine)
    for t in sorted(set(insp.get_table_names()) - before):
        changes.append(f"created table {t}")

    for table, column, ddl in NEW_COLUMNS:
        if table not in insp.get_table_names():
            continue
        have = {c["name"] for c in insp.get_columns(table)}
        if column not in have:
            with db.engine.begin() as conn:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}"))
            changes.append(f"added column {table}.{column}")

    # index on the new FK column (best effort - harmless if it already exists)
    try:
        idx = {i["name"] for i in inspect(db.engine).get_indexes("ip_addresses")}
        if "ix_ip_addresses_server_id" not in idx:
            with db.engine.begin() as conn:
                conn.execute(text("CREATE INDEX ix_ip_addresses_server_id ON ip_addresses (server_id)"))
            changes.append("added index ix_ip_addresses_server_id")
    except Exception as exc:   # pragma: no cover
        log.warning("could not create index on ip_addresses.server_id: %s", exc)

    return changes
