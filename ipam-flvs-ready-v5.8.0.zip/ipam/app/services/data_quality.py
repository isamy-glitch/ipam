"""
Data-quality checks and safe clean-ups for the imported inventory.

Everything here is split in two: a *find_* function that only reads (used for previews), and an
*apply_* function that changes data. Nothing is changed unless an admin asks for it.
"""
import re
from collections import Counter, defaultdict

from app import db
from app.models import Server, ServerStatus, IPAddress, IPStatus, Subnet

SPELLING_FIELDS = ("suite", "product", "technology", "os", "environment", "resource_group", "host_platform")
# keep the IP rows' copies of these in step with the server's value
IP_COPY = {"suite": "tags", "technology": "device_type", "product": "device_type", "environment": "location"}
HOSTNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
ALSO_RE = re.compile(r"Also listed for: ([^;]+)")


# ─────────────────────────────────────────────────────────────
# 1. spelling variants  (CentOS 7 / CentOs 7 / Centos 7 ...)
# ─────────────────────────────────────────────────────────────
def find_spelling_variants():
    """Values that differ only by case/punctuation. The most-used spelling wins."""
    out = []
    for field in SPELLING_FIELDS:
        col = getattr(Server, field)
        rows = db.session.query(col, db.func.count()).filter(col.isnot(None), col != "").group_by(col).all()
        groups = defaultdict(list)
        for value, n in rows:
            groups[re.sub(r"[^a-z0-9]", "", value.lower())].append((value, n))
        for variants in groups.values():
            if len(variants) > 1:
                variants.sort(key=lambda v: (-v[1], v[0]))
                out.append({"field": field, "canonical": variants[0][0],
                            "variants": [v for v in variants[1:]], "count": sum(n for _, n in variants[1:])})
    return out


def apply_spelling(items=None):
    items = find_spelling_variants() if items is None else items
    changed = 0
    for it in items:
        col = getattr(Server, it["field"])
        for value, _ in it["variants"]:
            changed += Server.query.filter(col == value).update({it["field"]: it["canonical"]}, synchronize_session=False)
            ipcol = IP_COPY.get(it["field"])
            if ipcol:
                IPAddress.query.filter(IPAddress.server_id.isnot(None), getattr(IPAddress, ipcol) == value) \
                    .update({ipcol: it["canonical"]}, synchronize_session=False)
    db.session.commit()
    return changed


# ─────────────────────────────────────────────────────────────
# 2. names for the auto-created /24 subnets
# ─────────────────────────────────────────────────────────────
def find_subnet_name_suggestions():
    out = []
    for s in Subnet.query.filter(Subnet.tags == "derived-from-runbook").order_by(Subnet.network).all():
        if not (s.name or "").startswith("Imported "):
            continue          # someone already renamed it
        envs = Counter(ip.location for ip in s.addresses if ip.location)
        env = envs.most_common(1)[0][0] if envs else None
        out.append({"subnet": s, "current": s.name, "suggested": f"{env} {s.network}" if env else s.name,
                    "ips": s.addresses.count()})
    return [o for o in out if o["suggested"] != o["current"]]


def apply_subnet_names(items=None):
    items = find_subnet_name_suggestions() if items is None else items
    for it in items:
        it["subnet"].name = it["suggested"]
    db.session.commit()
    return len(items)


# ─────────────────────────────────────────────────────────────
# 3. IPs listed for more than one server  (needs a human decision)
# ─────────────────────────────────────────────────────────────
def find_shared_ips():
    out = []
    rows = IPAddress.query.filter(IPAddress.description.like("%Also listed for:%")).all()
    for ip in rows:
        names = [n.strip() for n in ALSO_RE.findall(ip.description or "")]
        others = []
        for n in names:
            s = Server.query.filter(db.func.lower(Server.name) == n.lower(), Server.status == ServerStatus.ACTIVE).first()
            others.append({"name": n, "server": s})
        out.append({"ip": ip, "owner": ip.server, "others": others})
    out.sort(key=lambda r: tuple(int(p) for p in r["ip"].address.split(".")))
    return out


def _fill_ip_from_server(ip, srv, interface=None):
    ip.server = srv
    ip.interface = interface or ip.interface
    ip.hostname = srv.name if HOSTNAME_RE.match(srv.name) else None
    fn = srv.function
    ip.description = fn if HOSTNAME_RE.match(srv.name) else (f"{srv.name} - {fn}" if fn else srv.name)
    ip.device_type = srv.technology or srv.product
    ip.location = srv.environment
    ip.tags = srv.suite
    ip.owner = srv.owner


def resolve_shared_ip(ip_id, action, other_name=None, commit=True):
    """
    action:
      keep     - the current owner is right; the others were stale/alias entries (just drop the note)
      give     - give the IP to `other_name`, the current owner becomes the note
      free     - nobody is sure: release the IP
    Returns a short message for the admin.
    """
    ip = db.session.get(IPAddress, ip_id)
    if ip is None or "Also listed for:" not in (ip.description or ""):
        return "That IP is no longer flagged."
    note_names = [n.strip() for n in ALSO_RE.findall(ip.description)]
    owner = ip.server
    if action == "keep":
        if owner:
            _fill_ip_from_server(ip, owner)      # rewrites the description without the note
        msg = f"{ip.address}: kept with {owner.name if owner else 'current owner'}."
    elif action == "give":
        if owner is not None and owner.name.lower() == (other_name or "").strip().lower():
            return f"{ip.address}: already assigned to {owner.name}."     # re-applying a worksheet is harmless
        match = [n for n in note_names if n.lower() == (other_name or "").strip().lower()]
        target = Server.query.filter(db.func.lower(Server.name) == match[0].lower(),
                                     Server.status == ServerStatus.ACTIVE).first() if match else None
        if target is None:
            return f"{ip.address}: '{other_name}' is not one of the servers listed for this IP."
        other_name = match[0]
        _fill_ip_from_server(ip, target)
        remaining = [n for n in note_names if n != other_name]
        if owner is not None:
            remaining.insert(0, owner.name)
        ip.description = "; ".join(x for x in [ip.description] + [f"Also listed for: {n}" for n in remaining] if x)
        msg = f"{ip.address}: now assigned to {target.name} (was {owner.name if owner else 'unassigned'})."
    elif action == "free":
        ip.status, ip.server_id, ip.interface = IPStatus.FREE, None, None
        ip.hostname = ip.description = ip.device_type = ip.location = ip.tags = ip.owner = None
        msg = f"{ip.address}: released."
    else:
        return "Unknown action."
    if commit:
        db.session.commit()
    return msg


# ─────────────────────────────────────────────────────────────
# 4. things only a person can fix
# ─────────────────────────────────────────────────────────────
def find_unnamed_servers():
    out = []
    for s in Server.query.order_by(db.func.lower(Server.name)).all():
        if re.fullmatch(r"\d+", s.name or "") or (s.name or "").startswith("(unnamed"):
            out.append(s)
    return out


def find_servers_without_ip(limit=300):
    q = Server.query.filter(Server.status == ServerStatus.ACTIVE, ~Server.addresses.any(),
                            db.or_(Server.public_ip.is_(None), Server.public_ip == "")) \
        .order_by(db.func.lower(Server.name))
    return q.count(), q.limit(limit).all()


def summary():
    shared = find_shared_ips()
    return {
        "spelling": len(find_spelling_variants()),
        "subnet_names": len(find_subnet_name_suggestions()),
        "shared_ips": len(shared),
        "unnamed": len(find_unnamed_servers()),
        "no_ip": find_servers_without_ip(limit=1)[0],
    }


# ─────────────────────────────────────────────────────────────
# 5. apply a filled-in review worksheet (shared-ips-to-review.csv)
# ─────────────────────────────────────────────────────────────
def parse_decision(text):
    """'keep' | 'free' | 'give to NAME' (also 'give NAME', 'give: NAME') -> (action, name) ; blank -> (None, None)."""
    t = (text or "").strip()
    if not t:
        return None, None
    low = t.lower()
    if low in ("keep", "keep owner"):
        return "keep", None
    if low in ("free", "free it", "release"):
        return "free", None
    m = re.match(r"give(?:\s+to)?\s*[:\-]?\s*(.+)$", t, re.I)
    if m and m.group(1).strip():
        return "give", m.group(1).strip()
    return "?", t


def read_decisions(fileobj):
    """Read the worksheet CSV -> list of (row_number, ip, decision_text)."""
    import csv, io
    raw = fileobj.read()
    text = raw.decode("utf-8-sig", errors="replace") if isinstance(raw, bytes) else raw
    first = text.splitlines()[0] if text else ""
    delim = max([",", ";", "\t"], key=first.count)
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    cols = {(c or "").strip().lower(): c for c in (reader.fieldnames or [])}
    ip_col = cols.get("ip")
    dec_col = next((cols[c] for c in cols if c.startswith("decision")), None)
    if not ip_col or not dec_col:
        raise ValueError("The file needs an 'ip' column and a 'decision' column (use the worksheet exactly as exported).")
    return [(n, (r.get(ip_col) or "").strip(), (r.get(dec_col) or "").strip()) for n, r in enumerate(reader, start=2)]


def apply_decisions(rows, dry_run=False):
    """
    rows: [(row_number, ip, decision_text)]. Returns [(row_number, ip, ok, message)].
    A blank decision is skipped. With dry_run nothing is saved.
    """
    results = []
    for n, ip_str, text in rows:
        action, name = parse_decision(text)
        if action is None:
            continue
        if action == "?":
            results.append((n, ip_str, False, f"row {n}: can't read the decision '{name}' - use keep, free or give to <server name>"))
            continue
        ip = IPAddress.query.filter(IPAddress.address == ip_str, IPAddress.description.like("%Also listed for:%")).first()
        if ip is None:
            results.append((n, ip_str, False, f"{ip_str}: not flagged any more (already resolved, or not in this database) - skipped"))
            continue
        msg = resolve_shared_ip(ip.id, action, name, commit=not dry_run)
        bad = any(x in msg for x in ("not one of", "no longer", "Unknown"))
        results.append((n, ip_str, not bad, msg))
    if dry_run:
        db.session.rollback()
    return results
