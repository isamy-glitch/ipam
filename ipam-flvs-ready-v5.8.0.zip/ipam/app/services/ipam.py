"""
IP address management business logic.
"""
import ipaddress
import logging
from app import db
from app.models import Subnet, IPAddress, IPStatus

log = logging.getLogger(__name__)


def get_next_free_ip(subnet: Subnet) -> str | None:
    """Return the next unassigned IP in a subnet, or None if full."""
    network = subnet.network_obj
    assigned = {
        a.address
        for a in subnet.addresses.filter(IPAddress.status != IPStatus.FREE)
    }
    for host in network.hosts():
        ip_str = str(host)
        if ip_str == subnet.gateway:
            continue
        if ip_str not in assigned:
            return ip_str
    return None


def scan_and_populate_subnet(subnet: Subnet):
    """
    Ensure every host address in the subnet has an IPAddress record.
    New records are created with status=free.
    """
    network = subnet.network_obj
    existing = {a.address for a in subnet.addresses}
    new_records = []
    for host in network.hosts():
        ip_str = str(host)
        if ip_str not in existing:
            new_records.append(
                IPAddress(address=ip_str, subnet_id=subnet.id, status=IPStatus.FREE)
            )
    if new_records:
        db.session.bulk_save_objects(new_records)
        db.session.commit()
        log.info("Populated %d IP records for subnet %s", len(new_records), subnet.network)
    return len(new_records)


def validate_ip_in_subnet(ip_str: str, subnet: Subnet) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip in subnet.network_obj
    except ValueError:
        return False


def import_ips_from_csv(rows: list, subnet: Subnet) -> dict:
    """
    Import IP assignments from a list of dicts.
    Expected keys: address, hostname, mac_address, owner, description, status, device_type
    Returns {imported, skipped, errors}
    """
    imported, skipped, errors = 0, 0, []
    for row in rows:
        ip_str = row.get("address", "").strip()
        if not ip_str or not validate_ip_in_subnet(ip_str, subnet):
            errors.append(f"Invalid IP: {ip_str}")
            skipped += 1
            continue
        existing = IPAddress.query.filter_by(address=ip_str, subnet_id=subnet.id).first()
        if existing:
            # Update
            for field in ("hostname", "mac_address", "owner", "description", "status", "device_type"):
                val = row.get(field, "").strip()
                if val:
                    setattr(existing, field, val)
        else:
            status = row.get("status", IPStatus.ASSIGNED).strip() or IPStatus.ASSIGNED
            if status not in IPStatus.ALL:
                status = IPStatus.ASSIGNED
            existing = IPAddress(
                address=ip_str,
                subnet_id=subnet.id,
                status=status,
                hostname=row.get("hostname", "").strip() or None,
                mac_address=row.get("mac_address", "").strip() or None,
                owner=row.get("owner", "").strip() or None,
                description=row.get("description", "").strip() or None,
                device_type=row.get("device_type", "").strip() or None,
            )
            db.session.add(existing)
        imported += 1
    db.session.commit()
    return {"imported": imported, "skipped": skipped, "errors": errors}


def export_subnet_to_csv_rows(subnet: Subnet) -> list:
    """Return list of dicts suitable for CSV export."""
    rows = []
    # Sort numerically in Python (works for IPv4 and IPv6, and on any DB backend —
    # unlike MySQL's INET_ATON, which only handles IPv4 and errors on other engines)
    addresses = sorted(subnet.addresses.all(), key=lambda a: ipaddress.ip_address(a.address))
    for ip in addresses:
        rows.append({
            "address": ip.address,
            "subnet": subnet.network,
            "status": ip.status,
            "hostname": ip.hostname or "",
            "mac_address": ip.mac_address or "",
            "owner": ip.owner or "",
            "device_type": ip.device_type or "",
            "description": ip.description or "",
            "last_seen": ip.last_seen.isoformat() if ip.last_seen else "",
        })
    return rows


def release_ip(ip):
    """Return an address to the free pool: keep the row, clear everything that described its user."""
    from app.models import IPStatus
    ip.status = IPStatus.FREE
    for col in ("server_id", "interface", "hostname", "mac_address", "owner", "description", "device_type"):
        setattr(ip, col, None)
