from datetime import datetime, timezone
import ipaddress
import secrets
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


# ─────────────────────────────────────────────
# RBAC
# ─────────────────────────────────────────────
class Role:
    ADMIN = "admin"
    READWRITE = "readwrite"
    READONLY = "readonly"
    ALL = [ADMIN, READWRITE, READONLY]


user_groups = db.Table(
    "user_groups",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id"), primary_key=True),
    db.Column("group_id", db.Integer, db.ForeignKey("groups.id"), primary_key=True),
)


class Group(db.Model):
    __tablename__ = "groups"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.String(255))
    role = db.Column(db.String(20), nullable=False, default=Role.READONLY)
    ad_group_dn = db.Column(db.String(512))   # full DN of the AD group if mapped
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f"<Group {self.name} ({self.role})>"


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    display_name = db.Column(db.String(255))
    password_hash = db.Column(db.String(255))
    role = db.Column(db.String(20), nullable=False, default=Role.READONLY)
    is_active = db.Column(db.Boolean, default=True)
    is_ad_user = db.Column(db.Boolean, default=False)
    ad_dn = db.Column(db.String(512))
    entra_oid = db.Column(db.String(64), index=True)   # Microsoft Entra ID object id (stable, unlike the UPN)
    api_token = db.Column(db.String(64), unique=True, index=True)
    api_token_expires = db.Column(db.DateTime)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    groups = db.relationship("Group", secondary=user_groups, backref="users", lazy="dynamic")
    audit_logs = db.relationship("AuditLog", backref="user", lazy="dynamic")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)

    def generate_api_token(self):
        from datetime import timedelta
        from flask import current_app
        self.api_token = secrets.token_hex(32)
        # Stored naive (UTC) — the DATETIME column has no timezone awareness, and MySQL/SQLite
        # both hand back naive datetimes on read, so we store naive here to match and avoid
        # "can't compare offset-naive and offset-aware datetimes" when checking expiry later.
        self.api_token_expires = datetime.now(timezone.utc).replace(tzinfo=None) + current_app.config["API_TOKEN_EXPIRY"]
        return self.api_token

    @property
    def effective_role(self):
        """Highest role wins across user's own role and group memberships."""
        roles_priority = {Role.ADMIN: 3, Role.READWRITE: 2, Role.READONLY: 1}
        best = roles_priority.get(self.role, 1)
        for group in self.groups:
            best = max(best, roles_priority.get(group.role, 1))
        for role, priority in roles_priority.items():
            if priority == best:
                return role
        return Role.READONLY

    def can_write(self):
        return self.effective_role in (Role.ADMIN, Role.READWRITE)

    def is_admin(self):
        return self.effective_role == Role.ADMIN

    def __repr__(self):
        return f"<User {self.username}>"


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ─────────────────────────────────────────────
# VLAN
# ─────────────────────────────────────────────
class VLAN(db.Model):
    __tablename__ = "vlans"

    id = db.Column(db.Integer, primary_key=True)
    vlan_id = db.Column(db.Integer, unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    site = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    subnets = db.relationship("Subnet", backref="vlan", lazy="dynamic")

    def __repr__(self):
        return f"<VLAN {self.vlan_id} {self.name}>"


# ─────────────────────────────────────────────
# Subnet
# ─────────────────────────────────────────────
class Subnet(db.Model):
    __tablename__ = "subnets"

    id = db.Column(db.Integer, primary_key=True)
    network = db.Column(db.String(43), nullable=False, unique=True)   # e.g. 10.0.0.0/24
    name = db.Column(db.String(120))
    description = db.Column(db.Text)
    gateway = db.Column(db.String(45))
    dns_primary = db.Column(db.String(45))
    dns_secondary = db.Column(db.String(45))
    domain = db.Column(db.String(255))
    site = db.Column(db.String(120))
    vlan_id = db.Column(db.Integer, db.ForeignKey("vlans.id"))
    tags = db.Column(db.String(512))  # comma-separated
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    addresses = db.relationship("IPAddress", backref="subnet", lazy="dynamic", cascade="all, delete-orphan")

    @property
    def network_obj(self):
        return ipaddress.ip_network(self.network, strict=False)

    @property
    def total_hosts(self):
        return self.network_obj.num_addresses - 2 if self.network_obj.prefixlen < 31 else self.network_obj.num_addresses

    @property
    def used_count(self):
        return self.addresses.filter(IPAddress.status != IPStatus.FREE).count()

    @property
    def utilization_pct(self):
        if self.total_hosts == 0:
            return 0
        return round((self.used_count / self.total_hosts) * 100, 1)

    def __repr__(self):
        return f"<Subnet {self.network}>"


# ─────────────────────────────────────────────
# IP Address
# ─────────────────────────────────────────────
class IPStatus:
    FREE = "free"
    ASSIGNED = "assigned"
    RESERVED = "reserved"
    DHCP = "dhcp"
    ALL = [FREE, ASSIGNED, RESERVED, DHCP]


class IPAddress(db.Model):
    __tablename__ = "ip_addresses"

    id = db.Column(db.Integer, primary_key=True)
    address = db.Column(db.String(45), nullable=False, index=True)
    subnet_id = db.Column(db.Integer, db.ForeignKey("subnets.id"), nullable=False)
    status = db.Column(db.String(20), nullable=False, default=IPStatus.FREE)
    hostname = db.Column(db.String(255), index=True)
    mac_address = db.Column(db.String(17))
    owner = db.Column(db.String(255))          # person/team responsible
    description = db.Column(db.Text)
    dns_name = db.Column(db.String(255))
    device_type = db.Column(db.String(120))    # server, workstation, printer, network, etc.
    location = db.Column(db.String(255))
    custom_fields = db.Column(db.Text)         # JSON blob for extensibility
    last_seen = db.Column(db.DateTime)
    last_ping = db.Column(db.Boolean)
    tags = db.Column(db.String(512))
    server_id = db.Column(db.Integer, db.ForeignKey("servers.id"), index=True)   # inventory record this IP belongs to
    interface = db.Column(db.String(40))       # which of the server's addresses this is ("IP 1", "IP 2", ...)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        db.UniqueConstraint("address", "subnet_id", name="uq_address_subnet"),
    )

    def __repr__(self):
        return f"<IPAddress {self.address} ({self.status})>"


# ─────────────────────────────────────────────
# Server inventory (from the consolidated runbook)
# ─────────────────────────────────────────────
class ServerStatus:
    ACTIVE = "active"
    DECOMMISSIONED = "decommissioned"
    ALL = [ACTIVE, DECOMMISSIONED]


class Server(db.Model):
    """A server / appliance / device in the inventory. Its IPs are IPAddress rows (ip.server_id)."""
    __tablename__ = "servers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, index=True)
    old_name = db.Column(db.String(255))
    function = db.Column(db.Text)
    suite = db.Column(db.String(120), index=True)          # application suite (VSA, Educator, Nutanix, ...)
    product = db.Column(db.String(255))
    technology = db.Column(db.String(255))
    os = db.Column(db.String(120))                          # operating system, where the runbook records one
    resource_group = db.Column(db.String(255))              # Azure resource group
    site_name = db.Column(db.String(255))                   # website / service the server hosts
    host_platform = db.Column(db.String(255))               # Proxmox 4, Physical, ...
    environment = db.Column(db.String(120), index=True)     # Prod Colo, QA, Educator, Azure, ...
    owner = db.Column(db.String(255))
    public_ip = db.Column(db.String(255))                   # public address(es), free text
    vlan_number = db.Column(db.Integer)
    status = db.Column(db.String(20), nullable=False, default=ServerStatus.ACTIVE, index=True)
    decom_info = db.Column(db.String(255))                  # ticket / date text for decommissioned servers
    former_ips = db.Column(db.Text)                         # comma-separated: IPs this server used to hold (decommissioned)
    notes = db.Column(db.Text)
    dns_name = db.Column(db.String(255))                    # primary DNS name, <server name>.<domain> (set by the DNS import)
    source = db.Column(db.String(60))                       # e.g. "runbook:Main_Servers_Data"; blank when added by hand
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    addresses = db.relationship("IPAddress", backref="server", lazy="dynamic")

    @property
    def is_decommissioned(self):
        return self.status == ServerStatus.DECOMMISSIONED

    def __repr__(self):
        return f"<Server {self.name} ({self.status})>"


class DnsRecord(db.Model):
    """One record from an imported DNS zone (prod.local, flvs.net, qa.local, ...). A zone is replaced as a whole on re-import."""
    __tablename__ = "dns_records"

    id = db.Column(db.Integer, primary_key=True)
    zone = db.Column(db.String(255), nullable=False, index=True)
    name = db.Column(db.String(255), nullable=False)        # label inside the zone; "@" = the zone itself
    fqdn = db.Column(db.String(255), nullable=False, index=True)
    rtype = db.Column(db.String(10), nullable=False)        # A | CNAME
    data = db.Column(db.String(255))                        # IPv4 address (A) or target name (CNAME)
    is_static = db.Column(db.Boolean, default=False)
    stamp = db.Column(db.DateTime)                          # last registration of a dynamic record
    ip_id = db.Column(db.Integer, db.ForeignKey("ip_addresses.id", ondelete="SET NULL"), index=True)
    server_id = db.Column(db.Integer, db.ForeignKey("servers.id", ondelete="SET NULL"), index=True)
    imported_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    ip = db.relationship("IPAddress", backref=db.backref("dns_records", lazy="dynamic", passive_deletes=True))
    server = db.relationship("Server", backref=db.backref("dns_records", lazy="dynamic", passive_deletes=True))


class WebApp(db.Model):
    """Azure web / function / API app."""
    __tablename__ = "web_apps"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, index=True)
    application = db.Column(db.String(255))
    default_hostname = db.Column(db.String(255))
    enabled_hostnames = db.Column(db.Text)
    state = db.Column(db.String(40), index=True)            # Running / Stopped
    pricing_tier = db.Column(db.String(60))
    app_type = db.Column(db.String(60))                     # Web App / Function App / Api App
    priority = db.Column(db.String(20), index=True)         # Critical / High / Medium / Low
    owner = db.Column(db.String(255))
    note = db.Column(db.Text)
    acl_contributors = db.Column(db.Text)                   # "Listed Contributor/Owner In ACL"
    location = db.Column(db.String(60))
    resource_group = db.Column(db.String(120))
    repo_url = db.Column(db.String(512))
    ftps_endpoint = db.Column(db.String(512))
    source = db.Column(db.String(60))
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, onupdate=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f"<WebApp {self.name}>"


class ResourceLink(db.Model):
    """Reference link (runbooks, vendor contacts, wiki pages...)."""
    __tablename__ = "resource_links"

    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    url = db.Column(db.String(2000), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f"<ResourceLink {self.description}>"


# ─────────────────────────────────────────────
# Audit Log
# ─────────────────────────────────────────────
class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    username = db.Column(db.String(120))       # denormalized for log retention
    action = db.Column(db.String(50))          # CREATE, UPDATE, DELETE, LOGIN, etc.
    resource_type = db.Column(db.String(50))   # subnet, ip_address, user, vlan
    resource_id = db.Column(db.String(50))
    resource_repr = db.Column(db.String(255))
    details = db.Column(db.Text)               # JSON diff or description
    ip_address = db.Column(db.String(45))      # client IP
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    def __repr__(self):
        return f"<AuditLog {self.action} {self.resource_type} by {self.username}>"


# ─────────────────────────────────────────────
# Settings saved from the web GUI (override /etc/ipam/ipam.env)
# ─────────────────────────────────────────────
class AppSetting(db.Model):
    __tablename__ = "app_settings"

    key = db.Column(db.String(80), primary_key=True)
    value = db.Column(db.Text)                 # secrets are stored encrypted (see services/settings_store.py)
    is_secret = db.Column(db.Boolean, default=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_by = db.Column(db.String(120))
