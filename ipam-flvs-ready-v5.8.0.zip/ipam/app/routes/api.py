"""
REST API v1
Authentication: Bearer token in Authorization header
  Authorization: Bearer <api_token>
"""
from datetime import datetime, timezone
from functools import wraps
from flask import Blueprint, jsonify, request, abort
from app import db
from app.models import User, Subnet, IPAddress, VLAN, IPStatus, Server, ServerStatus, WebApp
from app.services.audit import log_action
from app.services.ipam import get_next_free_ip, validate_ip_in_subnet

api_bp = Blueprint("api", __name__)


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing or invalid Authorization header"}), 401
        token = auth.split(" ", 1)[1]
        user = User.query.filter_by(api_token=token).first()
        if not user:
            return jsonify({"error": "Invalid token"}), 401
        # api_token_expires is stored naive (see User.generate_api_token) — compare naive-to-naive.
        if user.api_token_expires and user.api_token_expires < datetime.now(timezone.utc).replace(tzinfo=None):
            return jsonify({"error": "Token expired"}), 401
        if not user.is_active:
            return jsonify({"error": "Account disabled"}), 403
        request.api_user = user
        return f(*args, **kwargs)
    return decorated


def write_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not request.api_user.can_write():
            return jsonify({"error": "Write access required"}), 403
        return f(*args, **kwargs)
    return decorated


# ─── Subnets ─────────────────────────────────

@api_bp.route("/subnets", methods=["GET"])
@token_required
def api_subnets():
    subnets = Subnet.query.filter_by(is_active=True).order_by(Subnet.network).all()
    return jsonify([{
        "id": s.id, "network": s.network, "name": s.name,
        "gateway": s.gateway, "site": s.site,
        "vlan": s.vlan.vlan_id if s.vlan else None,
        "utilization_pct": s.utilization_pct,
        "used": s.used_count, "total": s.total_hosts,
    } for s in subnets])


@api_bp.route("/subnets/<int:subnet_id>", methods=["GET"])
@token_required
def api_subnet_detail(subnet_id):
    s = Subnet.query.get_or_404(subnet_id)
    return jsonify({
        "id": s.id, "network": s.network, "name": s.name,
        "description": s.description, "gateway": s.gateway,
        "dns_primary": s.dns_primary, "dns_secondary": s.dns_secondary,
        "domain": s.domain, "site": s.site, "tags": s.tags,
        "vlan": s.vlan.vlan_id if s.vlan else None,
        "utilization_pct": s.utilization_pct,
        "used": s.used_count, "total": s.total_hosts,
    })


@api_bp.route("/subnets/<int:subnet_id>/next-free", methods=["GET"])
@token_required
def api_next_free(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    ip = get_next_free_ip(subnet)
    if not ip:
        return jsonify({"error": "No free IPs available"}), 404
    return jsonify({"subnet": subnet.network, "next_free": ip})


# ─── IP Addresses ─────────────────────────────

@api_bp.route("/subnets/<int:subnet_id>/ips", methods=["GET"])
@token_required
def api_subnet_ips(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    status = request.args.get("status")
    q = subnet.addresses
    if status:
        q = q.filter(IPAddress.status == status)
    return jsonify([{
        "id": ip.id, "address": ip.address, "status": ip.status,
        "hostname": ip.hostname, "mac_address": ip.mac_address,
        "owner": ip.owner, "device_type": ip.device_type,
        "description": ip.description, "last_seen": ip.last_seen.isoformat() if ip.last_seen else None,
    } for ip in q.all()])


@api_bp.route("/ips/search", methods=["GET"])
@token_required
def api_ip_search():
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify([])
    results = IPAddress.query.filter(
        db.or_(
            IPAddress.address.ilike(f"%{q}%"),
            IPAddress.hostname.ilike(f"%{q}%"),
            IPAddress.mac_address.ilike(f"%{q}%"),
            IPAddress.owner.ilike(f"%{q}%"),
        )
    ).limit(100).all()
    return jsonify([{
        "id": ip.id, "address": ip.address, "status": ip.status,
        "hostname": ip.hostname, "subnet": ip.subnet.network,
    } for ip in results])


@api_bp.route("/ips/<int:ip_id>", methods=["GET"])
@token_required
def api_ip_detail(ip_id):
    ip = IPAddress.query.get_or_404(ip_id)
    return jsonify({
        "id": ip.id, "address": ip.address, "status": ip.status,
        "hostname": ip.hostname, "mac_address": ip.mac_address,
        "owner": ip.owner, "device_type": ip.device_type,
        "description": ip.description, "dns_name": ip.dns_name,
        "location": ip.location, "tags": ip.tags,
        "subnet": ip.subnet.network, "subnet_id": ip.subnet_id,
        "last_seen": ip.last_seen.isoformat() if ip.last_seen else None,
    })


@api_bp.route("/ips/<int:ip_id>", methods=["PATCH"])
@token_required
@write_required
def api_ip_update(ip_id):
    ip = IPAddress.query.get_or_404(ip_id)
    data = request.get_json(silent=True) or {}
    updatable = ["status", "hostname", "mac_address", "owner", "description",
                 "device_type", "dns_name", "location", "tags"]
    for field in updatable:
        if field in data:
            val = data[field]
            if field == "status" and val not in IPStatus.ALL:
                return jsonify({"error": f"Invalid status: {val}"}), 400
            setattr(ip, field, val or None)
    db.session.commit()
    log_action("UPDATE", "ip_address", resource_id=ip.id,
               resource_repr=f"{ip.address}", details=data,
               username=request.api_user.username, user_id=request.api_user.id)
    return jsonify({"ok": True, "address": ip.address})


@api_bp.route("/subnets/<int:subnet_id>/ips", methods=["POST"])
@token_required
@write_required
def api_ip_assign(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    data = request.get_json(silent=True) or {}
    ip_str = data.get("address") or get_next_free_ip(subnet)
    if not ip_str:
        return jsonify({"error": "No free IPs"}), 409
    if not validate_ip_in_subnet(ip_str, subnet):
        return jsonify({"error": "IP not in subnet"}), 400
    ip = IPAddress.query.filter_by(address=ip_str, subnet_id=subnet_id).first()
    if ip and ip.status != IPStatus.FREE:
        return jsonify({"error": f"{ip_str} is already {ip.status}"}), 409
    if not ip:
        ip = IPAddress(address=ip_str, subnet_id=subnet_id)
        db.session.add(ip)
    ip.status = data.get("status", IPStatus.ASSIGNED)
    ip.hostname = data.get("hostname") or None
    ip.mac_address = data.get("mac_address") or None
    ip.owner = data.get("owner") or None
    ip.description = data.get("description") or None
    ip.device_type = data.get("device_type") or None
    db.session.commit()
    log_action("CREATE", "ip_address", resource_id=ip.id,
               resource_repr=ip.address, details=data,
               username=request.api_user.username, user_id=request.api_user.id)
    return jsonify({"ok": True, "id": ip.id, "address": ip.address}), 201


# ─── VLANs ────────────────────────────────────

@api_bp.route("/vlans", methods=["GET"])
@token_required
def api_vlans():
    vlans = VLAN.query.order_by(VLAN.vlan_id).all()
    return jsonify([{
        "id": v.id, "vlan_id": v.vlan_id, "name": v.name,
        "site": v.site, "subnet_count": v.subnets.count(),
    } for v in vlans])


# ─── Health ───────────────────────────────────

# ─── Server inventory (read-only) ────────────

def _server_json(s, with_ips=True):
    d = {"id": s.id, "name": s.name, "status": s.status, "old_name": s.old_name, "function": s.function,
         "suite": s.suite, "product": s.product, "technology": s.technology, "os": s.os,
         "environment": s.environment, "vlan": s.vlan_number, "site_name": s.site_name,
         "host_platform": s.host_platform, "resource_group": s.resource_group, "owner": s.owner,
         "public_ip": s.public_ip, "former_ips": s.former_ips, "decom_info": s.decom_info, "notes": s.notes}
    if with_ips:
        d["ips"] = [{"address": ip.address, "subnet": ip.subnet.network, "status": ip.status, "slot": ip.interface}
                    for ip in s.addresses.order_by(IPAddress.address).all()]
    return d


@api_bp.route("/servers", methods=["GET"])
@token_required
def api_servers():
    """?q=&status=active|decommissioned|all&suite=&environment=&page=&per_page="""
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "active")
    query = Server.query
    if status in ServerStatus.ALL:
        query = query.filter(Server.status == status)
    if request.args.get("suite"):
        query = query.filter(Server.suite == request.args["suite"])
    if request.args.get("environment"):
        query = query.filter(Server.environment == request.args["environment"])
    if q:
        like = f"%{q}%"
        ip_match = db.session.query(IPAddress.server_id).filter(IPAddress.server_id.isnot(None), IPAddress.address.ilike(like))
        query = query.filter(db.or_(Server.name.ilike(like), Server.old_name.ilike(like), Server.function.ilike(like),
                                    Server.public_ip.ilike(like), Server.id.in_(ip_match)))
    per_page = min(request.args.get("per_page", 100, type=int), 500)
    page = request.args.get("page", 1, type=int)
    rows = query.order_by(db.func.lower(Server.name)).paginate(page=page, per_page=per_page, error_out=False)
    return jsonify({"total": rows.total, "page": rows.page, "pages": rows.pages,
                    "servers": [_server_json(s) for s in rows.items]})


@api_bp.route("/servers/<int:server_id>", methods=["GET"])
@token_required
def api_server_detail(server_id):
    return jsonify(_server_json(Server.query.get_or_404(server_id)))


@api_bp.route("/apps", methods=["GET"])
@token_required
def api_apps():
    return jsonify([{"id": a.id, "name": a.name, "application": a.application, "default_hostname": a.default_hostname,
                     "state": a.state, "priority": a.priority, "app_type": a.app_type, "pricing_tier": a.pricing_tier,
                     "resource_group": a.resource_group, "owner": a.owner} for a in WebApp.query.order_by(WebApp.name).all()])


@api_bp.route("/health", methods=["GET"])
def api_health():
    from app.version import __version__
    return jsonify({"status": "ok", "service": "IPAM", "version": __version__})
