import ipaddress
import csv
import io
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, Response
from flask_login import login_required, current_user
from app import db
from app.models import Subnet, VLAN, IPAddress, IPStatus
from app.services.audit import log_action, diff_objects
from app.services.ipam import scan_and_populate_subnet, export_subnet_to_csv_rows

subnets_bp = Blueprint("subnets", __name__, url_prefix="/subnets")


def _require_write():
    if not current_user.can_write():
        abort(403)


@subnets_bp.route("/")
@login_required
def index():
    subnets = Subnet.query.order_by(Subnet.network).all()
    return render_template("subnets/index.html", subnets=subnets)


@subnets_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    _require_write()
    vlans = VLAN.query.order_by(VLAN.vlan_id).all()
    if request.method == "POST":
        network_str = request.form.get("network", "").strip()
        try:
            net = ipaddress.ip_network(network_str, strict=False)
        except ValueError:
            flash("Invalid network CIDR.", "danger")
            return render_template("subnets/form.html", vlans=vlans, subnet=None)

        if Subnet.query.filter_by(network=str(net)).first():
            flash("That subnet already exists.", "danger")
            return render_template("subnets/form.html", vlans=vlans, subnet=None)

        vlan_id = request.form.get("vlan_id") or None
        subnet = Subnet(
            network=str(net),
            name=request.form.get("name", "").strip() or None,
            description=request.form.get("description", "").strip() or None,
            gateway=request.form.get("gateway", "").strip() or None,
            dns_primary=request.form.get("dns_primary", "").strip() or None,
            dns_secondary=request.form.get("dns_secondary", "").strip() or None,
            domain=request.form.get("domain", "").strip() or None,
            site=request.form.get("site", "").strip() or None,
            vlan_id=int(vlan_id) if vlan_id else None,
            tags=request.form.get("tags", "").strip() or None,
        )
        db.session.add(subnet)
        db.session.commit()

        if request.form.get("auto_populate"):
            count = scan_and_populate_subnet(subnet)
            flash(f"Subnet created and {count} IP records populated.", "success")
        else:
            flash("Subnet created.", "success")

        log_action("CREATE", "subnet", resource_id=subnet.id, resource_repr=subnet.network,
                   details={"network": subnet.network, "name": subnet.name})
        return redirect(url_for("subnets.detail", subnet_id=subnet.id))

    return render_template("subnets/form.html", vlans=vlans, subnet=None)


@subnets_bp.route("/<int:subnet_id>")
@login_required
def detail(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    page = request.args.get("page", 1, type=int)
    status_filter = request.args.get("status", "")
    q = request.args.get("q", "").strip()

    ips_query = subnet.addresses
    if status_filter:
        ips_query = ips_query.filter(IPAddress.status == status_filter)
    if q:
        ips_query = ips_query.filter(
            db.or_(
                IPAddress.address.ilike(f"%{q}%"),
                IPAddress.hostname.ilike(f"%{q}%"),
                IPAddress.owner.ilike(f"%{q}%"),
            )
        )
    ips = ips_query.paginate(page=page, per_page=50, error_out=False)
    statuses = IPStatus.ALL
    return render_template("subnets/detail.html", subnet=subnet, ips=ips,
                           statuses=statuses, status_filter=status_filter, q=q)


@subnets_bp.route("/<int:subnet_id>/edit", methods=["GET", "POST"])
@login_required
def edit(subnet_id):
    _require_write()
    subnet = Subnet.query.get_or_404(subnet_id)
    vlans = VLAN.query.order_by(VLAN.vlan_id).all()

    if request.method == "POST":
        before = {"name": subnet.name, "gateway": subnet.gateway,
                  "description": subnet.description, "tags": subnet.tags}
        subnet.name = request.form.get("name", "").strip() or None
        subnet.description = request.form.get("description", "").strip() or None
        subnet.gateway = request.form.get("gateway", "").strip() or None
        subnet.dns_primary = request.form.get("dns_primary", "").strip() or None
        subnet.dns_secondary = request.form.get("dns_secondary", "").strip() or None
        subnet.domain = request.form.get("domain", "").strip() or None
        subnet.site = request.form.get("site", "").strip() or None
        vlan_id = request.form.get("vlan_id") or None
        subnet.vlan_id = int(vlan_id) if vlan_id else None
        subnet.tags = request.form.get("tags", "").strip() or None
        db.session.commit()
        after = {"name": subnet.name, "gateway": subnet.gateway,
                 "description": subnet.description, "tags": subnet.tags}
        log_action("UPDATE", "subnet", resource_id=subnet.id, resource_repr=subnet.network,
                   details=diff_objects(before, after))
        flash("Subnet updated.", "success")
        return redirect(url_for("subnets.detail", subnet_id=subnet.id))

    return render_template("subnets/form.html", vlans=vlans, subnet=subnet)


@subnets_bp.route("/<int:subnet_id>/delete", methods=["POST"])
@login_required
def delete(subnet_id):
    _require_write()
    subnet = Subnet.query.get_or_404(subnet_id)
    if not current_user.is_admin():
        abort(403)
    network = subnet.network
    db.session.delete(subnet)
    db.session.commit()
    log_action("DELETE", "subnet", resource_id=subnet_id, resource_repr=network)
    flash(f"Subnet {network} deleted.", "warning")
    return redirect(url_for("subnets.index"))


@subnets_bp.route("/<int:subnet_id>/export")
@login_required
def export_csv(subnet_id):
    subnet = Subnet.query.get_or_404(subnet_id)
    rows = export_subnet_to_csv_rows(subnet)
    if not rows:
        flash("No data to export.", "info")
        return redirect(url_for("subnets.detail", subnet_id=subnet_id))
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename=subnet_{subnet.network.replace('/', '_')}.csv"},
    )
