import ipaddress
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db
from app.models import User, Group, Role, AuditLog, Subnet, IPAddress, IPStatus, Server
from app.services.audit import log_action
from app.services import dns_check as dns
from app.services import data_quality as dq

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


def _require_admin():
    if not current_user.is_authenticated or not current_user.is_admin():
        abort(403)


@admin_bp.before_request
@login_required
def check_admin():
    _require_admin()


# ─── Users ───────────────────────────────────

@admin_bp.route("/users")
def users():
    users = User.query.order_by(User.username).all()
    return render_template("admin/users.html", users=users, roles=Role.ALL)


@admin_bp.route("/users/new", methods=["GET", "POST"])
def user_new():
    groups = Group.query.order_by(Group.name).all()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", Role.READONLY)
        if not username or not email or not password:
            flash("Username, email, and password are required.", "danger")
            return render_template("admin/user_form.html", user=None, groups=groups, roles=Role.ALL)
        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "danger")
            return render_template("admin/user_form.html", user=None, groups=groups, roles=Role.ALL)
        if len(password) < 10:
            flash("Password must be at least 10 characters.", "danger")
            return render_template("admin/user_form.html", user=None, groups=groups, roles=Role.ALL)
        user = User(
            username=username, email=email,
            display_name=request.form.get("display_name", "").strip() or username,
            role=role if role in Role.ALL else Role.READONLY,
        )
        user.set_password(password)
        selected_groups = request.form.getlist("groups")
        for gid in selected_groups:
            g = Group.query.get(int(gid))
            if g:
                user.groups.append(g)
        db.session.add(user)
        db.session.commit()
        log_action("CREATE", "user", resource_id=user.id, resource_repr=username)
        flash(f"User {username} created.", "success")
        return redirect(url_for("admin.users"))
    return render_template("admin/user_form.html", user=None, groups=groups, roles=Role.ALL)


@admin_bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
def user_edit(user_id):
    user = User.query.get_or_404(user_id)
    groups = Group.query.order_by(Group.name).all()
    if request.method == "POST":
        user.email = request.form.get("email", "").strip()
        user.display_name = request.form.get("display_name", "").strip() or user.username
        role = request.form.get("role", user.role)
        user.role = role if role in Role.ALL else user.role
        user.is_active = bool(request.form.get("is_active"))
        new_pw = request.form.get("password", "")
        if new_pw:
            if len(new_pw) < 10:
                flash("Password must be at least 10 characters.", "danger")
                return render_template("admin/user_form.html", user=user, groups=groups, roles=Role.ALL)
            user.set_password(new_pw)
        # Update group memberships
        user.groups = []
        for gid in request.form.getlist("groups"):
            g = Group.query.get(int(gid))
            if g:
                user.groups.append(g)
        db.session.commit()
        log_action("UPDATE", "user", resource_id=user.id, resource_repr=user.username)
        flash(f"User {user.username} updated.", "success")
        return redirect(url_for("admin.users"))
    return render_template("admin/user_form.html", user=user, groups=groups, roles=Role.ALL)


@admin_bp.route("/users/<int:user_id>/delete", methods=["POST"])
def user_delete(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "danger")
        return redirect(url_for("admin.users"))
    username = user.username
    db.session.delete(user)
    db.session.commit()
    log_action("DELETE", "user", resource_id=user_id, resource_repr=username)
    flash(f"User {username} deleted.", "warning")
    return redirect(url_for("admin.users"))


# ─── Groups ──────────────────────────────────

@admin_bp.route("/groups")
def groups():
    groups = Group.query.order_by(Group.name).all()
    return render_template("admin/groups.html", groups=groups, roles=Role.ALL)


@admin_bp.route("/groups/new", methods=["GET", "POST"])
def group_new():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        role = request.form.get("role", Role.READONLY)
        if not name:
            flash("Group name is required.", "danger")
            return render_template("admin/group_form.html", group=None, roles=Role.ALL)
        if Group.query.filter_by(name=name).first():
            flash("Group name already exists.", "danger")
            return render_template("admin/group_form.html", group=None, roles=Role.ALL)
        group = Group(
            name=name, role=role if role in Role.ALL else Role.READONLY,
            description=request.form.get("description", "").strip() or None,
            ad_group_dn=request.form.get("ad_group_dn", "").strip() or None,
        )
        db.session.add(group)
        db.session.commit()
        log_action("CREATE", "group", resource_id=group.id, resource_repr=name)
        flash(f"Group {name} created.", "success")
        return redirect(url_for("admin.groups"))
    return render_template("admin/group_form.html", group=None, roles=Role.ALL)


@admin_bp.route("/groups/<int:group_id>/edit", methods=["GET", "POST"])
def group_edit(group_id):
    group = Group.query.get_or_404(group_id)
    if request.method == "POST":
        group.description = request.form.get("description", "").strip() or None
        role = request.form.get("role", group.role)
        group.role = role if role in Role.ALL else group.role
        group.ad_group_dn = request.form.get("ad_group_dn", "").strip() or None
        db.session.commit()
        log_action("UPDATE", "group", resource_id=group.id, resource_repr=group.name)
        flash(f"Group {group.name} updated.", "success")
        return redirect(url_for("admin.groups"))
    return render_template("admin/group_form.html", group=group, roles=Role.ALL)


@admin_bp.route("/groups/<int:group_id>/delete", methods=["POST"])
def group_delete(group_id):
    group = Group.query.get_or_404(group_id)
    name = group.name
    db.session.delete(group)
    db.session.commit()
    log_action("DELETE", "group", resource_id=group_id, resource_repr=name)
    flash(f"Group {name} deleted.", "warning")
    return redirect(url_for("admin.groups"))


# ─── Audit Log ───────────────────────────────

@admin_bp.route("/audit")
def audit():
    page = request.args.get("page", 1, type=int)
    action_filter = request.args.get("action", "")
    user_filter = request.args.get("user", "")
    q = AuditLog.query
    if action_filter:
        q = q.filter(AuditLog.action == action_filter)
    if user_filter:
        q = q.filter(AuditLog.username.ilike(f"%{user_filter}%"))
    logs = q.order_by(AuditLog.timestamp.desc()).paginate(page=page, per_page=50, error_out=False)
    actions = db.session.query(AuditLog.action).distinct().order_by(AuditLog.action).all()
    return render_template("admin/audit.html", logs=logs, actions=[a[0] for a in actions],
                           action_filter=action_filter, user_filter=user_filter)


# ─── AD Test ─────────────────────────────────

@admin_bp.route("/ad-test")
def ad_test():
    """Sign-in status: Microsoft Entra ID (app registration) and, if still enabled, the legacy LDAP bind."""
    from flask import current_app
    from app.services import entra_auth
    ctx = {"entra": None, "ldap": None}
    if current_app.config.get("ENTRA_ENABLED"):
        ctx["entra"] = entra_auth.test_connection()
        ctx["entra_uri"] = entra_auth.redirect_uri(url_for("auth.entra_callback", _external=True))
        ctx["entra_warning"] = entra_auth.redirect_uri_warning(ctx["entra_uri"])
    if current_app.config.get("AD_ENABLED"):
        from app.services.ad_auth import ADAuthService
        ctx["ldap"] = ADAuthService().test_connection()
    return render_template("admin/ad_test.html", **ctx)


# ─── Sign-in settings (GUI for Entra ID + AD/LDAP) ───────────────────────────

import re as _re
from flask import current_app
from app.services import settings_store as store
from app.services import entra_auth

_GUID = _re.compile(r"^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$")


def _form_bool(name):
    return request.form.get(name) == "on"


def _guid_list(raw):
    parts = [p.strip() for p in (raw or "").replace(";", ",").split(",") if p.strip()]
    bad = [p for p in parts if not _GUID.match(p)]
    return ",".join(parts), bad


def _secret_is_set(key):
    return bool(current_app.config.get(key))


def _signin_context():
    cfg = current_app.config
    return {
        "default_redirect": url_for("auth.entra_callback", _external=True),
        "saved": store.saved_keys(),
        "unreadable": cfg.get("_SETTINGS_UNREADABLE", []),
        "entra_secret_set": _secret_is_set("ENTRA_CLIENT_SECRET"),
        "ldap_secret_set": _secret_is_set("AD_BIND_PASS") and cfg.get("AD_BIND_PASS") != "CHANGEME",
        "msal_ok": entra_auth.MSAL_AVAILABLE,
        "redirect_warning": entra_auth.redirect_uri_warning(cfg.get("ENTRA_REDIRECT_URI") or url_for("auth.entra_callback", _external=True)),
    }


@admin_bp.route("/signin-settings")
def signin_settings():
    return render_template("admin/signin_settings.html", **_signin_context())


@admin_bp.route("/signin-settings/entra", methods=["POST"])
def signin_settings_entra():
    f = request.form
    tenant, client = f.get("ENTRA_TENANT_ID", "").strip(), f.get("ENTRA_CLIENT_ID", "").strip()
    secret = f.get("ENTRA_CLIENT_SECRET", "").strip()
    redirect_uri = f.get("ENTRA_REDIRECT_URI", "").strip()
    enabled = _form_bool("ENTRA_ENABLED")
    errors = []
    if tenant and not _GUID.match(tenant):
        errors.append("Directory (tenant) ID must be a GUID like 11111111-2222-3333-4444-555555555555.")
    if client and not _GUID.match(client):
        errors.append("Application (client) ID must be a GUID.")
    if "'" in secret:
        errors.append("The client secret contains a single quote, which is not supported - create a new secret.")
    groups = {}
    for k in ("ENTRA_GROUP_ADMIN", "ENTRA_GROUP_READWRITE", "ENTRA_GROUP_READONLY"):
        val, bad = _guid_list(f.get(k, ""))
        groups[k] = val
        if bad:
            errors.append(f"{k.replace('ENTRA_GROUP_', '').title()} groups: '{bad[0]}' is not a group Object ID (GUID).")
    if enabled:
        if not (tenant and client):
            errors.append("Tenant ID and Client ID are required to turn Microsoft sign-in on.")
        if not (secret or _secret_is_set("ENTRA_CLIENT_SECRET")):
            errors.append("A client secret is required to turn Microsoft sign-in on.")
        if not redirect_uri:
            errors.append("The redirect URI is required.")
        elif redirect_uri_bad(redirect_uri):
            errors.append(redirect_uri_bad(redirect_uri))
    if errors:
        for e in errors:
            flash(e, "danger")
        return redirect(url_for("admin.signin_settings") + "#entra")

    values = {
        "ENTRA_ENABLED": enabled, "ENTRA_TENANT_ID": tenant, "ENTRA_CLIENT_ID": client, "ENTRA_CLIENT_SECRET": secret,
        "ENTRA_REDIRECT_URI": redirect_uri,
        "ENTRA_ROLE_ADMIN": f.get("ENTRA_ROLE_ADMIN", "").strip() or "IPAM.Admin",
        "ENTRA_ROLE_READWRITE": f.get("ENTRA_ROLE_READWRITE", "").strip() or "IPAM.ReadWrite",
        "ENTRA_ROLE_READONLY": f.get("ENTRA_ROLE_READONLY", "").strip() or "IPAM.ReadOnly",
        "ENTRA_ADMIN_USERS": f.get("ENTRA_ADMIN_USERS", "").replace(";", ","),
        "ENTRA_REQUIRE_ROLE": _form_bool("ENTRA_REQUIRE_ROLE"), "ENTRA_LOCAL_LOGIN": _form_bool("ENTRA_LOCAL_LOGIN"),
        **groups,
    }
    changed = store.save(values, current_user.username)
    log_action("UPDATE", "settings", resource_repr="Microsoft Entra ID sign-in",
               details={"changed": changed, "enabled": enabled})
    flash("Microsoft Entra ID settings saved." + (" Sign in with Microsoft is ON." if enabled else " (Sign in with Microsoft is off.)"), "success")
    if enabled and not current_app.config.get("ENTRA_LOCAL_LOGIN", True):
        flash("The local login form is hidden. If Microsoft sign-in ever breaks, use /login?local=1 for the local admin.", "info")
    return redirect(url_for("admin.signin_settings") + "#entra")


def redirect_uri_bad(uri):
    if not uri.lower().startswith(("https://", "http://")):
        return "The redirect URI must start with https:// ."
    if not uri.rstrip("/").endswith("/auth/entra/callback"):
        return "The redirect URI must end with /auth/entra/callback ."
    return ""


@admin_bp.route("/signin-settings/ldap", methods=["POST"])
def signin_settings_ldap():
    f = request.form
    g = lambda k: f.get(k, "").strip()
    enabled = _form_bool("AD_ENABLED")
    password = f.get("AD_BIND_PASS", "")
    errors = []
    if "'" in password:
        errors.append("The password contains a single quote, which is not supported here.")
    if enabled:
        if not g("AD_SERVER") or "dc01.prod.local" in g("AD_SERVER"):
            errors.append("Enter the real domain controller address, e.g. ldaps://<your-dc>.prod.local.")
        elif not g("AD_SERVER").lower().startswith(("ldap://", "ldaps://")):
            errors.append("The domain controller address must start with ldaps:// (or ldap://).")
        if not g("AD_BIND_USER"):
            errors.append("The service account (e.g. svc_netipam@prod.local) is required.")
        if not (password or _secret_is_set("AD_BIND_PASS")) or (not password and current_app.config.get("AD_BIND_PASS") == "CHANGEME"):
            errors.append("The service account password is required.")
    if errors:
        for e in errors:
            flash(e, "danger")
        return redirect(url_for("admin.signin_settings") + "#ldap")
    domain = g("AD_DOMAIN")
    base_dn = g("AD_BASE_DN") or (("DC=" + domain.replace(".", ",DC=")) if domain else "")
    values = {
        "AD_ENABLED": enabled, "AD_SERVER": g("AD_SERVER"), "AD_DOMAIN": domain, "AD_BASE_DN": base_dn,
        "AD_BIND_USER": g("AD_BIND_USER"), "AD_BIND_PASS": password,
        "AD_USER_SEARCH_BASE": g("AD_USER_SEARCH_BASE") or base_dn, "AD_GROUP_SEARCH_BASE": g("AD_GROUP_SEARCH_BASE") or base_dn,
        "AD_GROUP_ADMIN": g("AD_GROUP_ADMIN") or "IPAM-Admins", "AD_GROUP_READWRITE": g("AD_GROUP_READWRITE") or "IPAM-ReadWrite",
        "AD_GROUP_READONLY": g("AD_GROUP_READONLY") or "IPAM-ReadOnly",
        "AD_USE_SSL": g("AD_SERVER").lower().startswith("ldaps://"), "AD_TLS_VERIFY": _form_bool("AD_TLS_VERIFY"),
        "AD_CA_FILE": g("AD_CA_FILE"), "AD_FALLBACK_LOCAL": _form_bool("AD_FALLBACK_LOCAL"),
        "AD_ADMIN_USERS": f.get("AD_ADMIN_USERS", "").replace(";", ","),
    }
    changed = store.save(values, current_user.username)
    log_action("UPDATE", "settings", resource_repr="Active Directory (LDAP) sign-in",
               details={"changed": changed, "enabled": enabled})
    flash("Active Directory (LDAP) settings saved." + (" AD login is ON." if enabled else " (AD login is off.)"), "success")
    return redirect(url_for("admin.signin_settings") + "#ldap")


@admin_bp.route("/signin-settings/test/<which>", methods=["POST"])
def signin_settings_test(which):
    """Test the SAVED settings (works even while the method is switched off, so you can test before enabling)."""
    if which == "entra":
        res = entra_auth.test_connection(force=True)
    elif which == "ldap":
        from app.services.ad_auth import ADAuthService
        res = ADAuthService().test_connection(force=True)
    else:
        abort(404)
    flash(("Test passed: " if res["ok"] else "Test failed: ") + res["message"], "success" if res["ok"] else "danger")
    return redirect(url_for("admin.signin_settings") + ("#entra" if which == "entra" else "#ldap"))


# ─── DNS zone import ─────────────────────────

@admin_bp.route("/dns-import", methods=["GET", "POST"])
def dns_import_page():
    """
    Upload one DNS Manager zone export per domain (prod.local, flvs.net, qa.local, ...). Preview shows what would change,
    Apply saves it, CSV downloads the report. 'Align' re-checks server names against the zones already loaded.
    """
    from flask import Response, current_app
    import csv as _csv
    import io as _io
    from app.services import dns_import as di
    from app.services import settings_store as store

    def page(**kw):
        ctx = dict(report=None, mode=None, filename="", zone="", zones=di.imported_zones(),
                   env_map=current_app.config.get("DNS_ENV_DOMAINS", ""),
                   environments=[e for (e,) in db.session.query(Server.environment).distinct().order_by(Server.environment) if e])
        ctx.update(kw)
        return render_template("admin/dns_import.html", **ctx)

    if request.method == "GET":
        return page()

    mode = request.form.get("mode", "preview")
    if mode == "save_map":
        text = request.form.get("env_map", "")
        bad = [ln for ln in text.splitlines() if ln.strip() and "=" not in ln]
        if bad:
            flash(f"Each line must look like  Environment=domain  (problem: '{bad[0]}').", "danger")
            return page(env_map=text)
        store.save({"DNS_ENV_DOMAINS": "\n".join(ln.strip() for ln in text.splitlines() if ln.strip())}, current_user.username)
        log_action("UPDATE", "settings", resource_repr="DNS environment -> domain mapping")
        flash("Environment to domain mapping saved. Use 'Re-check server names' to apply it.", "success")
        return redirect(url_for("admin.dns_import_page"))

    if mode in ("align_preview", "align_apply"):
        report = di.run_align(dry_run=(mode != "align_apply"))
        if mode == "align_apply":
            log_action("UPDATE", "dns_names", resource_repr="aligned with server names", details=dict(report.counts))
            flash("Server DNS names updated.", "success")
        return page(report=report, mode="apply" if mode == "align_apply" else "preview", filename="server names (zones already imported)")

    f = request.files.get("zonefile")
    if not f or not f.filename:
        flash("Choose the exported DNS zone file first.", "danger")
        return page()
    text = f.read().decode("utf-8-sig", errors="replace")
    zone = request.form.get("zone", "").strip() or None
    report = di.run_import(text, dry_run=(mode != "apply"), zone=zone)
    if mode == "csv":
        buf = _io.StringIO()
        _csv.writer(buf).writerows(report.to_csv_rows())
        return Response(buf.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": f"attachment; filename=dns-import-report-{report.zone or 'zone'}.csv"})
    if mode == "apply":
        log_action("IMPORT", "dns_zone", resource_repr=f"{report.zone} ({f.filename})", details=dict(report.counts))
        flash(f"DNS zone {report.zone} imported into IPAM.", "success")
    return page(report=report, mode=mode, filename=f.filename, zone=zone or "")


# ─── DNS Check ───────────────────────────────

@admin_bp.route("/dns-check")
def dns_check():
    """
    Validate IPAM records against live DNS (forward A/AAAA + reverse PTR).
    Read-only; admin-only via the blueprint's before_request guard.
    Runs only when ?run=1 so opening the page never fires a burst of lookups.
    """
    subnets = Subnet.query.filter_by(is_active=True).order_by(Subnet.network).all()
    subnet_id = request.args.get("subnet_id", type=int)
    only_issues = request.args.get("only_issues") == "1"
    run = request.args.get("run") == "1"

    ctx = dict(subnets=subnets, subnet_id=subnet_id, only_issues=only_issues, ran=run,
               results=[], summary=None, truncated=False, total_candidates=0,
               unnamed=0, nameservers=dns.resolver_nameservers(), max_records=dns.MAX_RECORDS)

    if run:
        # In-use addresses only (free ones have nothing to validate)
        q = IPAddress.query.join(Subnet).filter(IPAddress.status != IPStatus.FREE)
        if subnet_id:
            q = q.filter(IPAddress.subnet_id == subnet_id)
        records, unnamed = [], 0
        for ip in q.all():
            name = (ip.dns_name or ip.hostname or "").strip()
            if not name:
                unnamed += 1
                continue
            records.append({"id": ip.id, "address": ip.address, "name": name,
                            "domain": ip.subnet.domain, "subnet": ip.subnet.network,
                            "status": ip.status})
        records.sort(key=lambda r: ipaddress.ip_address(r["address"]))
        ctx["total_candidates"] = len(records)
        ctx["truncated"] = len(records) > dns.MAX_RECORDS
        results = dns.run_checks(records[:dns.MAX_RECORDS])
        ctx["summary"] = dns.summarize(results)
        ctx["results"] = [r for r in results if not r["ok"]] if only_issues else results
        ctx["unnamed"] = unnamed
        log_action("DNS_CHECK", "dns", resource_repr=f"{len(results)} records checked",
                   details={"subnet_id": subnet_id, "ok": ctx["summary"]["ok"],
                            "issues": ctx["summary"]["issues"]})

    return render_template("admin/dns_check.html", **ctx)


# ─── Data Quality ────────────────────────────

@admin_bp.route("/data-quality")
def data_quality():
    """Work queue for cleaning up the imported inventory. Read-only; every change is an explicit POST below."""
    shared_all = dq.find_shared_ips()
    no_ip_total, no_ip = dq.find_servers_without_ip(limit=100)
    return render_template("admin/data_quality.html",
                           spelling=dq.find_spelling_variants(), subnet_names=dq.find_subnet_name_suggestions(),
                           shared=shared_all[:100], shared_total=len(shared_all),
                           unnamed=dq.find_unnamed_servers(), no_ip=no_ip, no_ip_total=no_ip_total)


@admin_bp.route("/data-quality/spelling", methods=["POST"])
def data_quality_spelling():
    n = dq.apply_spelling()
    log_action("CLEANUP", "data_quality", resource_repr=f"spelling variants unified ({n} servers)")
    flash(f"Unified spelling on {n} server field value(s).", "success")
    return redirect(url_for("admin.data_quality"))


@admin_bp.route("/data-quality/subnets", methods=["POST"])
def data_quality_subnets():
    n = dq.apply_subnet_names()
    log_action("CLEANUP", "data_quality", resource_repr=f"{n} auto-created subnets renamed")
    flash(f"Renamed {n} auto-created subnet(s).", "success")
    return redirect(url_for("admin.data_quality"))


@admin_bp.route("/data-quality/shared/<int:ip_id>", methods=["POST"])
def data_quality_shared(ip_id):
    action = request.form.get("action", "")
    msg = dq.resolve_shared_ip(ip_id, action, request.form.get("other"))
    log_action("CLEANUP", "data_quality", resource_id=ip_id, resource_repr=msg, details={"action": action})
    flash(msg, "success" if "no longer" not in msg and "not one of" not in msg and "Unknown" not in msg else "warning")
    return redirect(url_for("admin.data_quality") + "#shared")


@admin_bp.route("/data-quality/decisions", methods=["POST"])
def data_quality_decisions():
    """Apply a filled-in shared-ips-to-review.csv."""
    f = request.files.get("file")
    if not f or not f.filename:
        flash("Choose the CSV file first.", "warning")
        return redirect(url_for("admin.data_quality") + "#shared")
    preview = request.form.get("preview") == "1"
    try:
        rows = dq.read_decisions(f.stream)
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("admin.data_quality") + "#shared")
    results = dq.apply_decisions(rows, dry_run=preview)
    ok = sum(1 for r in results if r[2])
    problems = [r[3] for r in results if not r[2]]
    if not preview:
        log_action("CLEANUP", "data_quality", resource_repr=f"worksheet applied: {ok} done, {len(problems)} problem(s)")
    flash(("PREVIEW (nothing saved): " if preview else "") + f"{ok} decision(s) {'would be ' if preview else ''}applied"
          + (f", {len(problems)} could not be." if problems else "."), "info" if preview else "success")
    for m in problems[:15]:
        flash(m, "warning")
    return redirect(url_for("admin.data_quality") + "#shared")
