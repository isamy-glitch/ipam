"""Inventory pages: servers (with their IPs), Azure web apps, reference links."""
import csv
import io
import ipaddress
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, Response
from flask_login import login_required, current_user
from app import db
from app.models import Server, ServerStatus, IPAddress, WebApp, ResourceLink, DnsRecord
from app.services.audit import log_action, diff_objects
from app.services.ipam import release_ip

inventory_bp = Blueprint("inventory", __name__)

SERVER_FORM_FIELDS = ("name", "old_name", "function", "suite", "product", "technology", "os", "resource_group",
                      "site_name", "host_platform", "environment", "owner", "public_ip", "decom_info", "notes")
APP_FORM_FIELDS = ("name", "application", "default_hostname", "enabled_hostnames", "state", "pricing_tier",
                   "app_type", "priority", "owner", "note", "acl_contributors", "location", "resource_group",
                   "repo_url", "ftps_endpoint")


def _require_write():
    if not current_user.can_write():
        abort(403)


def _val(name):
    return request.form.get(name, "").strip() or None


def _distinct(column, where=None):
    q = db.session.query(column).filter(column.isnot(None), column != "")
    if where is not None:
        q = q.filter(where)
    return [r[0] for r in q.distinct().order_by(column).all()]


def _server_query():
    status = request.args.get("status", "active")
    q = request.args.get("q", "").strip()
    suite = request.args.get("suite", "")
    env = request.args.get("environment", "")
    query = Server.query
    if status in ServerStatus.ALL:
        query = query.filter(Server.status == status)
    if suite:
        query = query.filter(Server.suite == suite)
    if env:
        query = query.filter(Server.environment == env)
    if q:
        like = f"%{q}%"
        ip_match = db.session.query(IPAddress.server_id).filter(
            IPAddress.server_id.isnot(None), IPAddress.address.ilike(like))
        query = query.filter(db.or_(
            Server.name.ilike(like), Server.old_name.ilike(like), Server.function.ilike(like),
            Server.product.ilike(like), Server.technology.ilike(like), Server.site_name.ilike(like),
            Server.public_ip.ilike(like), Server.former_ips.ilike(like), Server.notes.ilike(like),
            Server.owner.ilike(like), Server.id.in_(ip_match)))
    return query, dict(status=status, q=q, suite=suite, environment=env)


def _ips_sorted(server):
    def key(ip):
        try:
            return ipaddress.ip_address(ip.address)
        except ValueError:
            return ipaddress.ip_address("0.0.0.0")
    return sorted(server.addresses.all(), key=key)


# ─── Servers ─────────────────────────────────

@inventory_bp.route("/servers")
@login_required
def servers():
    query, filters = _server_query()
    page = request.args.get("page", 1, type=int)
    rows = query.order_by(db.func.lower(Server.name)).paginate(page=page, per_page=50, error_out=False)
    ips_by_server = {}
    ids = [s.id for s in rows.items]
    if ids:
        for ip in IPAddress.query.filter(IPAddress.server_id.in_(ids)).all():
            ips_by_server.setdefault(ip.server_id, []).append(ip.address)
    for v in ips_by_server.values():
        v.sort(key=lambda a: tuple(int(p) for p in a.split(".")) if a.count(".") == 3 else (0,))
    return render_template("inventory/servers.html", servers=rows, ips_by_server=ips_by_server,
                           suites=_distinct(Server.suite), environments=_distinct(Server.environment),
                           total_active=Server.query.filter_by(status=ServerStatus.ACTIVE).count(),
                           total_decom=Server.query.filter_by(status=ServerStatus.DECOMMISSIONED).count(), **filters)


@inventory_bp.route("/servers/export.csv")
@login_required
def servers_export():
    query, _ = _server_query()
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["name", "status", "ip_addresses", "public_ip", "former_ips", "old_name", "function", "suite", "product",
                "technology", "os", "environment", "vlan", "site_name", "host_platform", "resource_group", "owner",
                "decom_info", "notes"])
    for s in query.order_by(db.func.lower(Server.name)).all():
        w.writerow([s.name, s.status, "; ".join(ip.address for ip in _ips_sorted(s)), s.public_ip or "",
                    s.former_ips or "", s.old_name or "", s.function or "", s.suite or "", s.product or "",
                    s.technology or "", s.os or "", s.environment or "", s.vlan_number or "", s.site_name or "",
                    s.host_platform or "", s.resource_group or "", s.owner or "", s.decom_info or "", s.notes or ""])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment;filename=servers.csv"})


@inventory_bp.route("/servers/<int:server_id>")
@login_required
def server_detail(server_id):
    server = Server.query.get_or_404(server_id)
    return render_template("inventory/server_detail.html", server=server, ips=_ips_sorted(server))


def _fill_server(server):
    for f in SERVER_FORM_FIELDS:
        setattr(server, f, _val(f))
    vn = request.form.get("vlan_number", type=int)
    server.vlan_number = vn
    status = request.form.get("status", ServerStatus.ACTIVE)
    server.status = status if status in ServerStatus.ALL else ServerStatus.ACTIVE
    server.former_ips = _val("former_ips")


@inventory_bp.route("/servers/new", methods=["GET", "POST"])
@login_required
def server_new():
    _require_write()
    if request.method == "POST":
        if not _val("name"):
            flash("Server name is required.", "danger")
            return render_template("inventory/server_form.html", server=None, form=request.form,
                                   suites=_distinct(Server.suite), environments=_distinct(Server.environment))
        server = Server()
        _fill_server(server)
        db.session.add(server)
        db.session.commit()
        log_action("CREATE", "server", resource_id=server.id, resource_repr=server.name)
        flash(f"Server {server.name} added.", "success")
        return redirect(url_for("inventory.server_detail", server_id=server.id))
    return render_template("inventory/server_form.html", server=None, form={},
                           suites=_distinct(Server.suite), environments=_distinct(Server.environment))


@inventory_bp.route("/servers/<int:server_id>/edit", methods=["GET", "POST"])
@login_required
def server_edit(server_id):
    _require_write()
    server = Server.query.get_or_404(server_id)
    if request.method == "POST":
        if not _val("name"):
            flash("Server name is required.", "danger")
        else:
            before = {f: getattr(server, f) for f in SERVER_FORM_FIELDS + ("status", "vlan_number", "former_ips")}
            _fill_server(server)
            db.session.commit()
            after = {f: getattr(server, f) for f in before}
            log_action("UPDATE", "server", resource_id=server.id, resource_repr=server.name,
                       details=diff_objects(before, after))
            flash(f"Server {server.name} updated.", "success")
            return redirect(url_for("inventory.server_detail", server_id=server.id))
    return render_template("inventory/server_form.html", server=server, form={},
                           suites=_distinct(Server.suite), environments=_distinct(Server.environment))


@inventory_bp.route("/servers/<int:server_id>/delete", methods=["POST"])
@login_required
def server_delete(server_id):
    """
    Delete a server. What happens to its IP addresses is the user's choice (form field `ips`):
      keep    - (default) the IP rows stay in their subnets, just no longer tied to this server
      release - the IPs go back to the free pool
      delete  - the IP records are removed
    """
    _require_write()
    server = Server.query.get_or_404(server_id)
    name = server.name
    mode = request.form.get("ips", "keep")
    if mode not in ("keep", "release", "delete"):
        mode = "keep"
    ips = server.addresses.all()
    labels = [ip.address for ip in ips]
    for ip in ips:
        if mode == "release":
            release_ip(ip)
        elif mode == "delete":
            DnsRecord.query.filter_by(ip_id=ip.id).update({"ip_id": None})
            db.session.delete(ip)
        else:
            ip.server_id = None
            ip.interface = None
    DnsRecord.query.filter_by(server_id=server.id).update({"server_id": None})
    db.session.delete(server)
    db.session.commit()
    log_action("DELETE", "server", resource_id=server_id, resource_repr=name,
               details={"ips": mode, "addresses": labels})
    msg = {"keep": "Its IP addresses are still in their subnets.",
           "release": f"{len(labels)} IP address(es) released to the free pool.",
           "delete": f"{len(labels)} IP record(s) deleted."}[mode]
    flash(f"Server {name} deleted. {msg}", "warning")
    return redirect(url_for("inventory.servers"))


# ─── Azure web apps ──────────────────────────

@inventory_bp.route("/apps")
@login_required
def apps():
    q = request.args.get("q", "").strip()
    state = request.args.get("state", "")
    priority = request.args.get("priority", "")
    rg = request.args.get("resource_group", "")
    query = WebApp.query
    if state:
        query = query.filter(WebApp.state == state)
    if priority:
        query = query.filter(WebApp.priority == priority)
    if rg:
        query = query.filter(WebApp.resource_group == rg)
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(WebApp.name.ilike(like), WebApp.application.ilike(like),
                                    WebApp.default_hostname.ilike(like), WebApp.enabled_hostnames.ilike(like),
                                    WebApp.owner.ilike(like), WebApp.repo_url.ilike(like)))
    rows = query.order_by(db.func.lower(WebApp.name)).all()
    return render_template("inventory/apps.html", apps=rows, q=q, state=state, priority=priority, resource_group=rg,
                           states=_distinct(WebApp.state), priorities=["Critical", "High", "Medium", "Low"],
                           groups=_distinct(WebApp.resource_group))


@inventory_bp.route("/apps/<int:app_id>")
@login_required
def app_detail(app_id):
    return render_template("inventory/app_detail.html", app=WebApp.query.get_or_404(app_id))


def _fill_app(app):
    for f in APP_FORM_FIELDS:
        setattr(app, f, _val(f))


@inventory_bp.route("/apps/new", methods=["GET", "POST"])
@login_required
def app_new():
    _require_write()
    if request.method == "POST":
        if not _val("name"):
            flash("Name is required.", "danger")
            return render_template("inventory/app_form.html", app=None)
        a = WebApp()
        _fill_app(a)
        db.session.add(a)
        db.session.commit()
        log_action("CREATE", "web_app", resource_id=a.id, resource_repr=a.name)
        flash(f"{a.name} added.", "success")
        return redirect(url_for("inventory.app_detail", app_id=a.id))
    return render_template("inventory/app_form.html", app=None)


@inventory_bp.route("/apps/<int:app_id>/edit", methods=["GET", "POST"])
@login_required
def app_edit(app_id):
    _require_write()
    a = WebApp.query.get_or_404(app_id)
    if request.method == "POST":
        if not _val("name"):
            flash("Name is required.", "danger")
        else:
            before = {f: getattr(a, f) for f in APP_FORM_FIELDS}
            _fill_app(a)
            db.session.commit()
            log_action("UPDATE", "web_app", resource_id=a.id, resource_repr=a.name,
                       details=diff_objects(before, {f: getattr(a, f) for f in APP_FORM_FIELDS}))
            flash(f"{a.name} updated.", "success")
            return redirect(url_for("inventory.app_detail", app_id=a.id))
    return render_template("inventory/app_form.html", app=a)


@inventory_bp.route("/apps/<int:app_id>/delete", methods=["POST"])
@login_required
def app_delete(app_id):
    if not current_user.is_admin():
        abort(403)
    a = WebApp.query.get_or_404(app_id)
    name = a.name
    db.session.delete(a)
    db.session.commit()
    log_action("DELETE", "web_app", resource_id=app_id, resource_repr=name)
    flash(f"{name} deleted.", "warning")
    return redirect(url_for("inventory.apps"))


# ─── Reference links ─────────────────────────

@inventory_bp.route("/resources")
@login_required
def resources():
    return render_template("inventory/resources.html", links=ResourceLink.query.order_by(ResourceLink.description).all())


@inventory_bp.route("/resources/add", methods=["POST"])
@login_required
def resource_add():
    _require_write()
    desc, url = _val("description"), _val("url")
    if not desc or not url or not url.lower().startswith(("http://", "https://")):
        flash("Enter a description and a link that starts with http:// or https://.", "danger")
        return redirect(url_for("inventory.resources"))
    link = ResourceLink(description=desc, url=url)
    db.session.add(link)
    db.session.commit()
    log_action("CREATE", "resource_link", resource_id=link.id, resource_repr=desc)
    flash("Link added.", "success")
    return redirect(url_for("inventory.resources"))


@inventory_bp.route("/resources/<int:link_id>/delete", methods=["POST"])
@login_required
def resource_delete(link_id):
    _require_write()
    link = ResourceLink.query.get_or_404(link_id)
    desc = link.description
    db.session.delete(link)
    db.session.commit()
    log_action("DELETE", "resource_link", resource_id=link_id, resource_repr=desc)
    flash("Link removed.", "warning")
    return redirect(url_for("inventory.resources"))
