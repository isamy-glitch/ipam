from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db
from app.models import VLAN
from app.services.audit import log_action

vlans_bp = Blueprint("vlans", __name__, url_prefix="/vlans")


def _require_write():
    if not current_user.can_write():
        abort(403)


@vlans_bp.route("/")
@login_required
def index():
    vlans = VLAN.query.order_by(VLAN.vlan_id).all()
    return render_template("vlans/index.html", vlans=vlans)


@vlans_bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    _require_write()
    if request.method == "POST":
        vlan_id = request.form.get("vlan_id", type=int)
        if not vlan_id or vlan_id < 1 or vlan_id > 4094:
            flash("VLAN ID must be between 1 and 4094.", "danger")
            return render_template("vlans/form.html", vlan=None)
        if VLAN.query.filter_by(vlan_id=vlan_id).first():
            flash(f"VLAN {vlan_id} already exists.", "danger")
            return render_template("vlans/form.html", vlan=None)
        vlan = VLAN(
            vlan_id=vlan_id,
            name=request.form.get("name", "").strip(),
            description=request.form.get("description", "").strip() or None,
            site=request.form.get("site", "").strip() or None,
        )
        db.session.add(vlan)
        db.session.commit()
        log_action("CREATE", "vlan", resource_id=vlan.id, resource_repr=f"VLAN {vlan_id}")
        flash(f"VLAN {vlan_id} created.", "success")
        return redirect(url_for("vlans.index"))
    return render_template("vlans/form.html", vlan=None)


@vlans_bp.route("/<int:vlan_pk>/edit", methods=["GET", "POST"])
@login_required
def edit(vlan_pk):
    _require_write()
    vlan = VLAN.query.get_or_404(vlan_pk)
    if request.method == "POST":
        vlan.name = request.form.get("name", "").strip()
        vlan.description = request.form.get("description", "").strip() or None
        vlan.site = request.form.get("site", "").strip() or None
        db.session.commit()
        log_action("UPDATE", "vlan", resource_id=vlan.id, resource_repr=f"VLAN {vlan.vlan_id}")
        flash("VLAN updated.", "success")
        return redirect(url_for("vlans.index"))
    return render_template("vlans/form.html", vlan=vlan)


@vlans_bp.route("/<int:vlan_pk>/delete", methods=["POST"])
@login_required
def delete(vlan_pk):
    if not current_user.is_admin():
        abort(403)
    vlan = VLAN.query.get_or_404(vlan_pk)
    if vlan.subnets.count() > 0:
        flash("Cannot delete VLAN with associated subnets.", "danger")
        return redirect(url_for("vlans.index"))
    label = f"VLAN {vlan.vlan_id}"
    db.session.delete(vlan)
    db.session.commit()
    log_action("DELETE", "vlan", resource_id=vlan_pk, resource_repr=label)
    flash(f"{label} deleted.", "warning")
    return redirect(url_for("vlans.index"))
