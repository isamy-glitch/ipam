from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, session
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime, timezone
from app import db
from app.models import User, Role
from app.services.audit import log_action

auth_bp = Blueprint("auth", __name__)


def _safe_next(target):
    """Only follow same-site relative redirects (blocks //evil.com and http://evil.com)."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return None


def _show_local_form():
    return (not current_app.config.get("ENTRA_ENABLED")) or current_app.config.get("ENTRA_LOCAL_LOGIN", True) \
        or request.args.get("local") == "1"


def _login_page():
    return render_template("auth/login.html", entra_enabled=bool(current_app.config.get("ENTRA_ENABLED")),
                           show_local_form=_show_local_form())


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        remember = bool(request.form.get("remember"))

        if not username or not password:
            flash("Username and password are required.", "danger")
            return _login_page()

        user = None

        # Try AD first if enabled
        if current_app.config.get("AD_ENABLED"):
            from app.services.ad_auth import ADAuthService
            ad = ADAuthService()
            success, info, error = ad.authenticate_user(username, password)
            if success and info:
                user = User.query.filter_by(username=info["username"]).first()
                if not user:
                    # Auto-provision AD user on first login
                    user = User(
                        username=info["username"],
                        email=info["email"],
                        display_name=info["display_name"],
                        role=info["role"],
                        is_ad_user=True,
                        ad_dn=info["dn"],
                    )
                    db.session.add(user)
                else:
                    # Refresh role from AD on each login
                    user.role = info["role"]
                    user.ad_dn = info["dn"]
                db.session.commit()
            elif error and not current_app.config.get("AD_FALLBACK_LOCAL", True):
                flash(f"Login failed: {error}", "danger")
                return _login_page()

        # Fall back to local auth
        if not user:
            user = User.query.filter_by(username=username).first()
            if not user or not user.check_password(password):
                flash("Invalid username or password.", "danger")
                log_action("LOGIN_FAILED", "auth", resource_repr=username,
                           details={"reason": "bad_credentials"}, username=username)
                return _login_page()

        if not user.is_active:
            flash("Your account is disabled. Contact an administrator.", "danger")
            return _login_page()

        login_user(user, remember=remember)
        user.last_login = datetime.now(timezone.utc)
        db.session.commit()
        log_action("LOGIN", "auth", resource_id=user.id, resource_repr=user.username,
                   user_id=user.id, username=user.username)

        return redirect(_safe_next(request.args.get("next")) or url_for("dashboard.index"))

    return _login_page()


# ─── Microsoft Entra ID (app registration) ───────────────────────────────────

@auth_bp.route("/auth/entra/login")
def entra_login():
    from app.services import entra_auth
    if not current_app.config.get("ENTRA_ENABLED"):
        flash("Microsoft sign-in is not enabled.", "warning")
        return redirect(url_for("auth.login"))
    try:
        flow = entra_auth.begin_login(url_for("auth.entra_callback", _external=True))
    except entra_auth.EntraError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("auth.login"))
    session["entra_flow"] = flow
    session["entra_next"] = _safe_next(request.args.get("next")) or ""
    return redirect(flow["auth_uri"])


@auth_bp.route("/auth/entra/callback")
def entra_callback():
    from app.services import entra_auth
    if not current_app.config.get("ENTRA_ENABLED"):
        return redirect(url_for("auth.login"))
    flow = session.pop("entra_flow", None)
    next_page = session.pop("entra_next", "")
    if request.args.get("error"):
        msg = (request.args.get("error_description") or request.args["error"]).splitlines()[0]
        flash(f"Microsoft sign-in was not completed: {msg}", "danger")
        log_action("LOGIN_FAILED", "auth", resource_repr="entra", details={"reason": request.args.get("error")},
                   username="entra")
        return redirect(url_for("auth.login"))
    try:
        info = entra_auth.finish_login(flow, request.args.to_dict())
    except entra_auth.EntraError as exc:
        flash(f"Microsoft sign-in failed: {exc}", "danger")
        log_action("LOGIN_FAILED", "auth", resource_repr="entra", details={"reason": str(exc)[:200]}, username="entra")
        return redirect(url_for("auth.login"))

    user = entra_auth.provision_user(info)
    if not user.is_active:
        db.session.rollback()
        flash("Your account is disabled. Contact an administrator.", "danger")
        return redirect(url_for("auth.login"))
    login_user(user)
    user.last_login = datetime.now(timezone.utc)
    db.session.commit()
    log_action("LOGIN", "auth", resource_id=user.id, resource_repr=user.username,
               details={"method": "entra"}, user_id=user.id, username=user.username)
    return redirect(_safe_next(next_page) or url_for("dashboard.index"))


@auth_bp.route("/logout")
@login_required
def logout():
    log_action("LOGOUT", "auth", resource_id=current_user.id,
               resource_repr=current_user.username)
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST" and not current_user.is_ad_user:
        current_pw = request.form.get("current_password", "")
        new_pw = request.form.get("new_password", "")
        confirm_pw = request.form.get("confirm_password", "")
        if not current_user.check_password(current_pw):
            flash("Current password is incorrect.", "danger")
        elif len(new_pw) < 10:
            flash("New password must be at least 10 characters.", "danger")
        elif new_pw != confirm_pw:
            flash("Passwords do not match.", "danger")
        else:
            current_user.set_password(new_pw)
            db.session.commit()
            log_action("UPDATE", "user", resource_id=current_user.id,
                       resource_repr=current_user.username, details="Password changed")
            flash("Password updated.", "success")
    return render_template("auth/profile.html")


@auth_bp.route("/profile/token", methods=["POST"])
@login_required
def generate_token():
    token = current_user.generate_api_token()
    db.session.commit()
    log_action("GENERATE_API_TOKEN", "user", resource_id=current_user.id,
               resource_repr=current_user.username)
    flash(f"New API token generated. Copy it now — it won't be shown again: {token}", "success")
    return redirect(url_for("auth.profile"))
