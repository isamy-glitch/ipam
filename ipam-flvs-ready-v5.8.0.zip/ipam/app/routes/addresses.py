from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Subnet, IPAddress, IPStatus, DnsRecord
from app.services.audit import log_action, diff_objects
from app.services.ipam import get_next_free_ip, validate_ip_in_subnet, release_ip

addresses_bp = Blueprint("addresses", __name__, url_prefix="/addresses")


def _require_write():
    if not current_user.can_write():
        abort(403)


@addresses_bp.route("/search")
@login_required
def search():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()   # "", "in_use", "free", or an IPStatus value
    limit = 500
    results = []
    total = 0
    if q or status:
        query = IPAddress.query
        if q:
            query = query.filter(
                db.or_(
                    IPAddress.address.ilike(f"%{q}%"),
                    IPAddress.hostname.ilike(f"%{q}%"),
                    IPAddress.description.ilike(f"%{q}%"),
                    IPAddress.owner.ilike(f"%{q}%"),
                    IPAddress.mac_address.ilike(f"%{q}%"),
                )
            )
        if status == "in_use":
            query = query.filter(IPAddress.status != IPStatus.FREE)
        elif status in IPStatus.ALL:
            query = query.filter(IPAddress.status == status)
        total = query.count()
        results = query.order_by(IPAddress.subnet_id, IPAddress.id).limit(limit).all()
    return render_template("addresses/search.html", results=results, q=q, status=status,
                           total=total, limit=limit)


@addresses_bp.route("/<int:ip_id>")
@login_required
def detail(ip_id):
    ip = IPAddress.query.get_or_404(ip_id)
    return render_template("addresses/detail.html", ip=ip)


@addresses_bp.route("/<int:ip_id>/edit", methods=["GET", "POST"])
@login_required
def edit(ip_id):
    _require_write()
    ip = IPAddress.query.get_or_404(ip_id)

    if request.method == "POST":
        before = {
            "status": ip.status, "hostname": ip.hostname,
            "owner": ip.owner, "mac_address": ip.mac_address,
            "description": ip.description, "device_type": ip.device_type,
        }
        ip.status = request.form.get("status", IPStatus.FREE)
        ip.hostname = request.form.get("hostname", "").strip() or None
        ip.mac_address = request.form.get("mac_address", "").strip() or None
        ip.owner = request.form.get("owner", "").strip() or None
        ip.description = request.form.get("description", "").strip() or None
        ip.device_type = request.form.get("device_type", "").strip() or None
        ip.dns_name = request.form.get("dns_name", "").strip() or None
        ip.location = request.form.get("location", "").strip() or None
        ip.tags = request.form.get("tags", "").strip() or None
        db.session.commit()
        after = {
            "status": ip.status, "hostname": ip.hostname,
            "owner": ip.owner, "mac_address": ip.mac_address,
            "description": ip.description, "device_type": ip.device_type,
        }
        log_action("UPDATE", "ip_address", resource_id=ip.id,
                   resource_repr=f"{ip.address} ({ip.hostname})",
                   details=diff_objects(before, after))
        flash(f"IP {ip.address} updated.", "success")
        return redirect(url_for("subnets.detail", subnet_id=ip.subnet_id))

    statuses = IPStatus.ALL
    return render_template("addresses/edit.html", ip=ip, statuses=statuses)


@addresses_bp.route("/subnet/<int:subnet_id>/assign", methods=["GET", "POST"])
@login_required
def assign(subnet_id):
    _require_write()
    subnet = Subnet.query.get_or_404(subnet_id)

    if request.method == "POST":
        ip_str = request.form.get("address", "").strip()
        if not ip_str:
            ip_str = get_next_free_ip(subnet)
            if not ip_str:
                flash("No free IPs available in this subnet.", "danger")
                return redirect(url_for("subnets.detail", subnet_id=subnet_id))

        if not validate_ip_in_subnet(ip_str, subnet):
            flash(f"{ip_str} is not within {subnet.network}.", "danger")
            return redirect(url_for("subnets.detail", subnet_id=subnet_id))

        ip = IPAddress.query.filter_by(address=ip_str, subnet_id=subnet_id).first()
        if ip and ip.status != IPStatus.FREE:
            flash(f"{ip_str} is already {ip.status}.", "danger")
            return redirect(url_for("subnets.detail", subnet_id=subnet_id))

        if not ip:
            ip = IPAddress(address=ip_str, subnet_id=subnet_id)
            db.session.add(ip)

        ip.status = request.form.get("status", IPStatus.ASSIGNED)
        ip.hostname = request.form.get("hostname", "").strip() or None
        ip.mac_address = request.form.get("mac_address", "").strip() or None
        ip.owner = request.form.get("owner", "").strip() or None
        ip.description = request.form.get("description", "").strip() or None
        ip.device_type = request.form.get("device_type", "").strip() or None
        db.session.commit()
        log_action("CREATE", "ip_address", resource_id=ip.id,
                   resource_repr=f"{ip.address} ({ip.hostname})",
                   details={"subnet": subnet.network, "status": ip.status})
        flash(f"IP {ip_str} assigned.", "success")
        return redirect(url_for("subnets.detail", subnet_id=subnet_id))

    next_free = get_next_free_ip(subnet)
    statuses = [IPStatus.ASSIGNED, IPStatus.RESERVED, IPStatus.DHCP]
    return render_template("addresses/assign.html", subnet=subnet,
                           next_free=next_free, statuses=statuses)


@addresses_bp.route("/<int:ip_id>/release", methods=["POST"])
@login_required
def release(ip_id):
    _require_write()
    ip = IPAddress.query.get_or_404(ip_id)
    subnet_id = ip.subnet_id
    old_repr = f"{ip.address} ({ip.hostname})"
    release_ip(ip)
    db.session.commit()
    log_action("UPDATE", "ip_address", resource_id=ip.id,
               resource_repr=old_repr, details="Released to free pool")
    flash(f"{ip.address} released.", "success")
    return redirect(url_for("subnets.detail", subnet_id=subnet_id))


@addresses_bp.route("/<int:ip_id>/delete", methods=["POST"])
@login_required
def delete(ip_id):
    """Remove the IP record entirely (Release keeps the row as a free address; Delete takes it out of the list)."""
    _require_write()
    ip = IPAddress.query.get_or_404(ip_id)
    subnet_id = ip.subnet_id
    label = f"{ip.address} ({ip.hostname})" if ip.hostname else ip.address
    details = {"subnet": ip.subnet.network, "status": ip.status}
    if ip.server_id:
        details["server"] = ip.server.name if ip.server else ip.server_id
    DnsRecord.query.filter_by(ip_id=ip.id).update({"ip_id": None})
    db.session.delete(ip)
    db.session.commit()
    log_action("DELETE", "ip_address", resource_id=ip_id, resource_repr=label, details=details)
    flash(f"IP {label} deleted.", "warning")
    return redirect(url_for("subnets.detail", subnet_id=subnet_id))
