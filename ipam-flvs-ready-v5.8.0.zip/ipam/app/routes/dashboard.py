"""Dashboard route"""
import platform
import os
from flask import Blueprint, render_template, current_app, send_file, Response, abort, url_for
from flask_login import login_required
from app.models import Subnet, IPAddress, VLAN, IPStatus, AuditLog

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@dashboard_bp.route("/dashboard")
@login_required
def index():
    total_subnets = Subnet.query.filter_by(is_active=True).count()
    total_ips = IPAddress.query.count()
    assigned_ips = IPAddress.query.filter(IPAddress.status != IPStatus.FREE).count()
    total_vlans = VLAN.query.count()
    recent_logs = AuditLog.query.order_by(AuditLog.timestamp.desc()).limit(10).all()
    subnets = Subnet.query.filter_by(is_active=True).order_by(Subnet.network).all()
    return render_template(
        "dashboard/index.html",
        total_subnets=total_subnets,
        total_ips=total_ips,
        assigned_ips=assigned_ips,
        total_vlans=total_vlans,
        recent_logs=recent_logs,
        subnets=subnets,
    )


@dashboard_bp.route("/about")
@login_required
def about():
    """Version, creator and (for admins) runtime details."""
    import flask, sqlalchemy
    from app import db
    from app import version as v
    info = {
        "python": platform.python_version(),
        "flask": flask.__version__,
        "sqlalchemy": sqlalchemy.__version__,
        "database": db.engine.dialect.name,
    }
    if current_app.config.get("ENTRA_ENABLED"):
        signin = "Microsoft Entra ID (app registration)" + (" + local accounts" if current_app.config.get("ENTRA_LOCAL_LOGIN", True) else "")
    elif current_app.config.get("AD_ENABLED"):
        signin = "Active Directory (LDAP)"
    else:
        signin = "Local accounts"
    return render_template("about.html", v=v, info=info, signin=signin)


# ─── User guide (the same HTML/PDF that is handed out on SharePoint) ─────────
GUIDE_BASENAME = "IPAM-User-Guide-5.8.0"


def _guide_path(ext):
    path = os.path.join(current_app.root_path, "docs", f"{GUIDE_BASENAME}.{ext}")
    if not os.path.isfile(path):
        abort(404)
    return path


@dashboard_bp.route("/user-guide")
@login_required
def user_guide():
    """The user guide page. The file is fully self-contained; only the small bar at the top is added here."""
    with open(_guide_path("html"), encoding="utf-8") as fh:
        html = fh.read()
    bar = ('<div id="appbar"><a href="%s">&larr; Back to IPAM</a><span style="flex:1"></span>'
           '<a href="%s">Download PDF</a><a href="%s">Download HTML</a></div>'
           % (url_for("dashboard.index"), url_for("dashboard.user_guide_pdf"), url_for("dashboard.user_guide_download")))
    return Response(html.replace("<!--IPAM-APP-BAR-->", bar, 1), mimetype="text/html")


@dashboard_bp.route("/user-guide/pdf")
@login_required
def user_guide_pdf():
    return send_file(_guide_path("pdf"), mimetype="application/pdf", download_name=f"{GUIDE_BASENAME}.pdf")


@dashboard_bp.route("/user-guide/download")
@login_required
def user_guide_download():
    return send_file(_guide_path("html"), mimetype="text/html", as_attachment=True, download_name=f"{GUIDE_BASENAME}.html")
