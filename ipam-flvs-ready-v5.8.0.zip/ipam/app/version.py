"""IPAM version. Bump on every delivery; shown in the sidebar, /api/v1/health, `ipam-admin version` and by update.sh."""
__version__ = "5.8.0"
CREATOR = "ILA Periasamy"
ORGANIZATION = "Florida Virtual School"
PRODUCT = "IPAM - Network IP Address Manager"
RELEASED = "2026-10-20"

# What this build can do - `ipam-admin version` prints these so you can tell at a glance what an install supports.
FEATURES = [
    "ad-login (svc_netipam, ipam-enable-ad)",
    "dns-check page",
    "server inventory (Servers / Web Apps / Resources)",
    "runbook import (import-runbook)",
    "data quality page (data-cleanup, apply-decisions)",
    "reset-password, upgrade-db",
    "clickable dashboard cards, IP search status filter",
    "about page",
    "entra-login (app registration, OIDC)",
    "https helper (ipam-enable-https)",
    "sign-in settings GUI (Entra ID + AD, encrypted secrets)",
    "dns zone import per domain (import-dns, Administration > DNS Import)",
    "server-name based DNS names + missing/mismatch report (align-dns-names)",
    "load all DNS zones in one step (ipam-load-dns), public IPs kept out of IPAM, dns-reset",
    "user guide inside IPAM (/user-guide, HTML + PDF)",
    "delete server (choose what happens to its IPs) / delete IP",
]
