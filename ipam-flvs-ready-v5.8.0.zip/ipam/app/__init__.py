from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect
import logging
from logging.handlers import RotatingFileHandler
import os

db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()
csrf = CSRFProtect()


def create_app(config_name=None):
    app = Flask(__name__)

    # Load config
    from config.settings import config
    cfg_name = config_name or os.environ.get("FLASK_ENV", "production")
    app.config.from_object(config[cfg_name])

    # Extensions
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)

    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.subnets import subnets_bp
    from app.routes.addresses import addresses_bp
    from app.routes.vlans import vlans_bp
    from app.routes.admin import admin_bp
    from app.routes.api import api_bp
    from app.routes.inventory import inventory_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(subnets_bp)
    app.register_blueprint(addresses_bp)
    app.register_blueprint(vlans_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(api_bp, url_prefix="/api/v1")

    # The REST API authenticates with a Bearer token (see app/routes/api.py), not the
    # session cookie — CSRF protection exists to stop a browser's ambient cookie auth
    # being abused cross-site, which doesn't apply here, and PowerShell/curl callers
    # have no CSRF token to send. Without this exemption every POST/PUT/PATCH/DELETE
    # under /api/v1 fails with "400 The CSRF token is missing."
    csrf.exempt(api_bp)

    # Version (sidebar, login page)
    from app.version import __version__

    @app.context_processor
    def inject_version():
        return {"ipam_version": __version__}

    # Sign-in settings saved from the GUI override the env file; pick up changes made in any worker.
    from flask import request as _request

    @app.before_request
    def _refresh_gui_settings():
        if _request.endpoint != "static":
            from app.services import settings_store
            settings_store.refresh_if_changed(app)

    # Logging
    if not app.debug:
        log_dir = app.config.get("LOG_DIR", "/var/log/ipam")
        os.makedirs(log_dir, exist_ok=True)
        handler = RotatingFileHandler(
            os.path.join(log_dir, "ipam.log"),
            maxBytes=10 * 1024 * 1024,
            backupCount=10,
        )
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s [%(name)s] %(message)s"
            )
        )
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)

    return app
