# IPAM REST API v1

Base URL: `https://ipam.yourdomain/api/v1`

## Authentication

All endpoints (except `/health`) require a Bearer token in the Authorization header.

Generate a token in the web UI under **Profile → API Token**, or via the CLI:
```bash
sudo ipam-admin generate-token admin
```

Include in all requests:
```
Authorization: Bearer <your_token>
```

---

## Endpoints

### Health
```
GET /api/v1/health
```
Returns `{"status": "ok", "service": "IPAM"}` — no auth required.

---

### Subnets

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/subnets` | List all active subnets |
| GET | `/subnets/{id}` | Get subnet details |
| GET | `/subnets/{id}/next-free` | Get next available IP |
| GET | `/subnets/{id}/ips` | List IPs in subnet |
| POST | `/subnets/{id}/ips` | Assign an IP |

**List subnets:**
```bash
curl -H "Authorization: Bearer $TOKEN" https://ipam.local/api/v1/subnets
```

**Get next free IP:**
```bash
curl -H "Authorization: Bearer $TOKEN" https://ipam.local/api/v1/subnets/1/next-free
# Response: {"subnet": "10.10.20.0/24", "next_free": "10.10.20.5"}
```

**Assign an IP:**
```bash
curl -X POST -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"hostname":"web-01","owner":"infra-team","device_type":"server","status":"assigned"}' \
     https://ipam.local/api/v1/subnets/1/ips
# Omit "address" to auto-assign the next free IP
```

---

### IP Addresses

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/ips/search?q=<query>` | Search IPs by address/hostname/MAC/owner |
| GET | `/ips/{id}` | Get IP details |
| PATCH | `/ips/{id}` | Update IP fields |

**Search:**
```bash
curl -H "Authorization: Bearer $TOKEN" "https://ipam.local/api/v1/ips/search?q=web-01"
```

**Update an IP:**
```bash
curl -X PATCH -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"hostname":"web-01-renamed","status":"assigned"}' \
     https://ipam.local/api/v1/ips/42
```

---

### VLANs

```
GET /api/v1/vlans
```

---

## PowerShell Integration

```powershell
$BaseUrl = "https://ipam.local/api/v1"
$Token   = "your_api_token_here"
$Headers = @{ Authorization = "Bearer $Token"; "Content-Type" = "application/json" }

# Get next free IP in subnet ID 3
$NextFree = Invoke-RestMethod -Uri "$BaseUrl/subnets/3/next-free" -Headers $Headers

# Assign it
$Body = @{
    address     = $NextFree.next_free
    hostname    = "srv-new-01"
    owner       = "infra-team"
    device_type = "server"
    status      = "assigned"
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "$BaseUrl/subnets/3/ips" -Headers $Headers -Body $Body
```
