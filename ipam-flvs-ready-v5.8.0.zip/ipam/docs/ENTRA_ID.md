# Sign in with Microsoft (Entra ID app registration)

IPAM can authenticate people through a Microsoft Entra ID **app registration** instead of LDAP. There is no service
account password, no LDAP/LDAPS connection to a domain controller and nothing to open towards your DCs: the browser
goes to Microsoft, the user signs in there (MFA and Conditional Access apply), and Microsoft sends the browser back to
IPAM. IPAM only needs outbound HTTPS to `login.microsoftonline.com` (and `graph.microsoft.com` for the connection test).

> **Prerequisite:** people must exist in Entra ID (cloud accounts, or on-prem `prod.local` accounts synced with
> Entra Connect / Cloud Sync). **Microsoft only accepts `https://` redirect addresses**, so IPAM must be served over HTTPS
> under a host name (an internal name such as `netipam1010.prod.local` is fine) - a plain `http://10.50.3.30` install
> cannot use it. `sudo ipam-enable-https` fixes that in one step.

## 1. Make IPAM available over HTTPS (on the server)

```bash
sudo ipam-enable-https --host netipam1010.prod.local
# own/internal-CA certificate instead of a self-signed one:
# sudo ipam-enable-https --host netipam1010.prod.local --cert /tmp/ipam.pem --key /tmp/ipam.key
```

Make sure the host name resolves (DNS A record) for the people who will sign in. A self-signed certificate works - only the
user's browser sees it, Microsoft never connects to IPAM - but browsers warn until it is trusted.

## 2. Create the app registration (Azure portal)

1. **Microsoft Entra ID > App registrations > New registration**
   - Name: `IPAM`
   - Supported account types: **Accounts in this organizational directory only (single tenant)**
   - Redirect URI: platform **Web**, value `https://netipam1010.prod.local/auth/entra/callback`
2. On the **Overview** page copy the **Directory (tenant) ID** and **Application (client) ID**.
3. **Certificates & secrets > New client secret.** Copy the **Value** immediately (not the *Secret ID*).
   Secrets expire (max 24 months) - put the expiry date in your calendar; to rotate, create a new secret and re-run
   `sudo ipam-enable-entra`.
4. **API permissions:** the default *Microsoft Graph > User.Read (delegated)* is all IPAM needs. No admin consent is
   required unless your tenant blocks user consent (then click *Grant admin consent*).
5. **Authentication:** nothing else to tick - leave *Implicit grant* unchecked.

## 3. Decide who gets which IPAM role

**Option A - App roles (recommended).** On the app registration go to **App roles > Create app role** three times:

| Display name | Allowed member types | Value |
|---|---|---|
| IPAM Admin | Users/Groups | `IPAM.Admin` |
| IPAM Read/Write | Users/Groups | `IPAM.ReadWrite` |
| IPAM Read-only | Users/Groups | `IPAM.ReadOnly` |

Then **Enterprise applications > IPAM > Users and groups > Add user/group** and assign your Entra groups (or people) to a
role. (Assigning *groups* to app roles needs Entra ID P1 or higher; on the free tier assign individual users.)
Under **Properties** set **Assignment required? = Yes** so only assigned people can sign in at all.

**Option B - Group IDs.** **Token configuration > Add groups claim > Security groups** (or *Groups assigned to the
application*), then give `ipam-enable-entra` the groups' **Object IDs**. Works on any tier; if someone is in more than ~200
groups Microsoft leaves the list out and IPAM looks it up through Graph automatically.

Either way the highest role wins (Admin > Read/Write > Read-only) and the role is refreshed at every sign-in.
Names of roles other than `IPAM.*` can be changed with `ENTRA_ROLE_ADMIN` / `ENTRA_ROLE_READWRITE` / `ENTRA_ROLE_READONLY`.

## 4. Turn it on

**In the web GUI (v5.5+):** sign in as an admin, open **Administration > Sign-in Settings**, fill in the *Microsoft Entra ID*
card (tenant ID, client ID, client secret, redirect URI, roles/groups), click **Save**, then **Test saved settings**, then
tick **Enable** and Save again. Changes apply immediately - no restart. The secret is stored encrypted and is never shown
back. The same page has an *Active Directory (LDAP)* card for the legacy method. Settings saved in the GUI override
`/etc/ipam/ipam.env`; `sudo ipam-admin entra-test` and the status page use them too.

**Or on the server:**

```bash
sudo ipam-enable-entra
```

It asks for the tenant ID, client ID, secret (hidden), the redirect URI, optional group IDs, the sign-in names that must
always be admins (put your own here so you can't lock yourself out) and whether to keep the local username/password form.
It then restarts IPAM and asks Microsoft to accept the registration (`sudo ipam-admin entra-test` repeats that check).

The login page now shows **Sign in with Microsoft**. The local form stays underneath by default as a break-glass for the
local `admin`; hide it with `ENTRA_LOCAL_LOGIN=false` (it is always reachable at `/login?local=1`).
**Administration > Sign-in Status** shows the live test result and the exact redirect URI to register.

## Settings (`/etc/ipam/ipam.env`)

| Setting | Meaning |
|---|---|
| `ENTRA_ENABLED` | `true` turns the feature on |
| `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `ENTRA_CLIENT_SECRET` | from the app registration |
| `ENTRA_REDIRECT_URI` | `https://<host>/auth/entra/callback` - must match the registration exactly |
| `ENTRA_ROLE_ADMIN` / `_READWRITE` / `_READONLY` | app-role values (default `IPAM.Admin`, `IPAM.ReadWrite`, `IPAM.ReadOnly`) |
| `ENTRA_GROUP_ADMIN` / `_READWRITE` / `_READONLY` | group Object IDs, comma-separated |
| `ENTRA_ADMIN_USERS` | sign-in names that are always admins |
| `ENTRA_REQUIRE_ROLE` | `true` refuses people who match no role/group (default: they get read-only) |
| `ENTRA_LOCAL_LOGIN` | `false` hides the local username/password form |
| `ENTRA_AUTHORITY_HOST` | `login.microsoftonline.us` for GCC High / DoD |

## How users are matched

* Primary key is the immutable Entra **object id**, so renames and UPN changes never create duplicates.
* First sign-in creates the IPAM user (username = sign-in name, no IPAM password).
* A person who previously signed in through LDAP is **linked** to their existing record by sign-in name / e-mail, keeping
  history and audit trail. **Local accounts are never linked or taken over** - an Entra user with the same name gets a
  separate account.
* Disable a person in IPAM (Users & Groups) to block them even though Microsoft accepts them.

## Troubleshooting

| Message | Cause / fix |
|---|---|
| `AADSTS50011` redirect URI mismatch | The URI in *Authentication* must equal `ENTRA_REDIRECT_URI` exactly (scheme, host, path). Browse IPAM by the same host name. |
| `AADSTS7000215` invalid client secret | You pasted the *Secret ID*, or the secret expired. Create a new one, copy the **Value**. |
| `AADSTS700016` application not found | Wrong tenant ID or client ID. |
| `AADSTS50105` user not assigned to a role | *Assignment required* is on and the person (or one of their groups) isn't assigned to the IPAM app. |
| `AADSTS65001` consent required | Click *Grant admin consent* on **API permissions**. |
| `State mismatch` / "sign-in session expired" | The browser lost the IPAM cookie between *Sign in* and the return (different host name, cookie blocked, or HTTP/HTTPS mix). Start again from the same address. |
| "cannot reach login.microsoftonline.com" | The server has no outbound HTTPS to Microsoft - open it in the firewall/proxy. |
| Everyone is read-only | No role claim arrived: check the app-role assignment, or that the groups claim is on and `ENTRA_GROUP_*` hold **Object IDs**. |

Locked out? Use the local admin at `/login?local=1`, or `sudo ipam-admin reset-password admin`.
To go back to LDAP/local only, set `ENTRA_ENABLED=false` in `/etc/ipam/ipam.env` and `sudo systemctl restart ipam`.
