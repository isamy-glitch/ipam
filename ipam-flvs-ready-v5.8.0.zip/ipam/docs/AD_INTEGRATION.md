# AD / LDAP Integration Guide

> **Prefer Microsoft sign-in?** Since v5.4 IPAM can use an Entra ID app registration instead of LDAP - no service
> account or domain-controller connection needed. See [ENTRA_ID.md](ENTRA_ID.md). This LDAP guide still works. Since v5.5 the LDAP settings can also be edited in the web GUI
> (**Administration > Sign-in Settings**) instead of running `sudo ipam-enable-ad`.

IPAM supports Active Directory authentication via LDAP/LDAPS. AD users are
auto-provisioned on first login and their IPAM role is driven entirely by AD
group membership.

---

## Quick path (lab server)

1. In AD, create the service account **`svc_netipam`** (see below).
2. On the IPAM server: `sudo ipam-enable-ad` — it asks for the domain controller, the account
   and its password, writes the settings, restarts IPAM and tests the bind.
3. Sign in with an AD username. Staff land as read-only unless they are in an IPAM AD group
   or listed in `AD_ADMIN_USERS`.

The local `admin` account keeps working as a break-glass login.

---

## The svc_netipam service account

IPAM uses it for exactly two things: to look a user up by username, and to read that user's group
membership. It never writes to AD, and users' own passwords are checked by binding as the user.

| Setting | Value |
|---|---|
| Account | `svc_netipam` (UPN `svc_netipam@prod.local`) — a normal domain user |
| Rights | **Read-only.** A default Domain User can already read users and groups; nothing extra to delegate |
| Password | Long and random; "Password never expires" and "User cannot change password" |
| Not needed | **Local Administrator, Domain Admin, or any other elevated group.** IPAM does not log on to the server as this account and does not need to change anything on it |

Giving it local admin would add risk and no capability: if the IPAM server were compromised, the
attacker would get an account with admin rights on the box and a directory password. Keep it
unprivileged. If you want the *server itself* joined to prod.local (SSSD/realmd) so that domain
admins can SSH in, that is a separate task and uses a join account, not this one.

Network: the IPAM server must reach a domain controller on **636/tcp** (LDAPS) — or 389/tcp for a
clear-text lab test — and resolve its name through the domain DNS servers (10.50.3.20 / 10.50.3.22).

---

## Prerequisites

1. The `svc_netipam` account above.
2. Optional: three AD Security Groups (names are configurable). Without them, use `AD_ADMIN_USERS`
   for admins and everyone else is read-only:
   - `IPAM-Admins`     → full admin access
   - `IPAM-ReadWrite`  → create/edit subnets and IPs
   - `IPAM-ReadOnly`   → view-only

3. `ldap3` Python package (included in `requirements.txt`).

---

## Configuration (`/etc/ipam/ipam.env`)

```bash
AD_ENABLED=true

# LDAP server URI — use ldaps:// (port 636) for encrypted connections
AD_SERVER=ldaps://dc01.prod.local

# NetBIOS / UPN domain
AD_DOMAIN=prod.local

# Root base DN
AD_BASE_DN=DC=prod,DC=local

# Service account UPN
AD_BIND_USER=svc_netipam@prod.local
AD_BIND_PASS='<service-account-password>'   # single quotes: keeps $ # & and spaces literal

# Where to search for users / groups (the whole domain by default; narrow to an OU if you like)
AD_USER_SEARCH_BASE=DC=prod,DC=local
AD_GROUP_SEARCH_BASE=DC=prod,DC=local

# Lab shortcut: these AD usernames are always IPAM admins, whatever their groups (comma-separated)
AD_ADMIN_USERS=alice,bob

# AD group names mapped to IPAM roles
AD_GROUP_ADMIN=IPAM-Admins
AD_GROUP_READWRITE=IPAM-ReadWrite
AD_GROUP_READONLY=IPAM-ReadOnly

# SSL/TLS options
AD_USE_SSL=true
AD_TLS_VERIFY=true    # set false only for internal self-signed CA (not recommended)
AD_CA_FILE=/etc/ipam/ad-ca.pem   # CA that signed the DC certificate (optional, see below)
AD_FALLBACK_LOCAL=true           # local accounts still work if AD rejects/can't be reached
```

`ipam-enable-ad` edits these for you; edit the file by hand only for fine-tuning. After editing:
`systemctl restart ipam`.

Use the DC's **name** in `AD_SERVER` (`ldaps://dc01.prod.local`), not its IP — the certificate is
issued to the name, so verification fails against a bare IP.

After editing, restart: `systemctl restart ipam`

---

## More than one domain

IPAM binds to one directory at a time (`prod.local` in the examples above). To also
accept accounts from another domain, either run a second IPAM instance with its own
env file, or use a forest trust and point IPAM at the forest-root DC with a service
account that can read both domains.

---

## How Role Resolution Works

On every login IPAM queries AD for the user's `memberOf` attribute and maps
the CN of each group to a role:

| AD Group        | IPAM Role  |
|-----------------|------------|
| IPAM-Admins     | admin      |
| IPAM-ReadWrite  | readwrite  |
| IPAM-ReadOnly   | readonly   |

**Highest role wins.** A user in both `IPAM-ReadOnly` and `IPAM-Admins` gets
`admin`.

Roles are re-evaluated on every login, so AD group changes take effect at
next sign-in without any IPAM-side changes.

---

## Testing the Connection

As an admin, navigate to **Administration → AD Integration** in the web UI
to run a live connectivity test against your configured DC.

Or from the CLI:
```bash
sudo ipam-admin ad-test
```

---

## TLS Certificate Trust (LDAPS)

If your DC uses an internal CA certificate, the simplest route is to export the CA certificate
(PEM) to `/etc/ipam/ad-ca.pem` and set `AD_CA_FILE` to it (`ipam-enable-ad` asks for it).
Make it readable by the `ipam` user: `chown root:ipam /etc/ipam/ad-ca.pem && chmod 640 /etc/ipam/ad-ca.pem`.

Alternatively, trust it system-wide:

```bash
# Ubuntu
cp your-ca.crt /usr/local/share/ca-certificates/
update-ca-certificates

# RHEL
cp your-ca.crt /etc/pki/ca-trust/source/anchors/
update-ca-trust
```

Then set `AD_TLS_VERIFY=true` and restart IPAM.

---

## Fallback to Local Accounts

If AD is unreachable or rejects the login, IPAM falls back to local password
authentication (set `AD_FALLBACK_LOCAL=false` to turn that off). The built-in `admin` account created during installation
always uses local auth regardless of AD settings.
