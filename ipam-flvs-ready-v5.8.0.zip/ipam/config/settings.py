import os
from datetime import timedelta


def _build_db_url(default: str) -> str:
    """
    Normalize the DATABASE_URL to the correct SQLAlchemy dialect.
    Supports:
      mysql+pymysql://   (explicit — preferred)
      mysql://           (auto-upgraded to mysql+pymysql://)
    """
    url = os.environ.get("DATABASE_URL", default)
    if url.startswith("mysql://"):
        url = url.replace("mysql://", "mysql+pymysql://", 1)
    return url


class BaseConfig:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-this-in-production-use-secrets-gen")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    LOG_DIR = os.environ.get("IPAM_LOG_DIR", "/var/log/ipam")

    # AD / LDAP Settings
    AD_ENABLED = os.environ.get("AD_ENABLED", "false").lower() == "true"
    AD_SERVER = os.environ.get("AD_SERVER", "")          # e.g. ldaps://dc01.prod.local
    AD_DOMAIN = os.environ.get("AD_DOMAIN", "")          # e.g. prod.local
    AD_BASE_DN = os.environ.get("AD_BASE_DN", "")        # e.g. DC=prod,DC=local
    AD_BIND_USER = os.environ.get("AD_BIND_USER", "")    # svc_netipam@prod.local
    AD_BIND_PASS = os.environ.get("AD_BIND_PASS", "")
    AD_USER_SEARCH_BASE = os.environ.get("AD_USER_SEARCH_BASE", "")
    AD_GROUP_SEARCH_BASE = os.environ.get("AD_GROUP_SEARCH_BASE", "")
    AD_GROUP_ADMIN = os.environ.get("AD_GROUP_ADMIN", "IPAM-Admins")
    AD_GROUP_READWRITE = os.environ.get("AD_GROUP_READWRITE", "IPAM-ReadWrite")
    AD_GROUP_READONLY = os.environ.get("AD_GROUP_READONLY", "IPAM-ReadOnly")
    AD_USE_SSL = os.environ.get("AD_USE_SSL", "true").lower() == "true"
    AD_TLS_VERIFY = os.environ.get("AD_TLS_VERIFY", "true").lower() == "true"
    # PEM file with the CA that signed the domain controller's certificate (internal/enterprise CA).
    AD_CA_FILE = os.environ.get("AD_CA_FILE", "")
    # If AD is unreachable or rejects the login, still allow IPAM's own local accounts (break-glass admin).
    AD_FALLBACK_LOCAL = os.environ.get("AD_FALLBACK_LOCAL", "true").lower() == "true"
    # Comma-separated AD usernames (sAMAccountName) that are always IPAM admins, without needing the AD groups.
    AD_ADMIN_USERS = [u.strip().lower() for u in os.environ.get("AD_ADMIN_USERS", "").split(",") if u.strip()]

    # Microsoft Entra ID (Azure AD) sign-in through an App Registration (OpenID Connect, no LDAP needed)
    ENTRA_ENABLED = os.environ.get("ENTRA_ENABLED", "false").lower() == "true"
    ENTRA_TENANT_ID = os.environ.get("ENTRA_TENANT_ID", "")          # Directory (tenant) ID
    ENTRA_CLIENT_ID = os.environ.get("ENTRA_CLIENT_ID", "")          # Application (client) ID
    ENTRA_CLIENT_SECRET = os.environ.get("ENTRA_CLIENT_SECRET", "")  # client secret VALUE (not the secret ID)
    ENTRA_REDIRECT_URI = os.environ.get("ENTRA_REDIRECT_URI", "")    # https://<host>/auth/entra/callback
    ENTRA_AUTHORITY_HOST = os.environ.get("ENTRA_AUTHORITY_HOST", "login.microsoftonline.com")  # login.microsoftonline.us for GCC High
    # Role mapping, best option first: App Roles (token "roles" claim), then group object IDs (token "groups" claim).
    ENTRA_ROLE_ADMIN = os.environ.get("ENTRA_ROLE_ADMIN", "IPAM.Admin")
    ENTRA_ROLE_READWRITE = os.environ.get("ENTRA_ROLE_READWRITE", "IPAM.ReadWrite")
    ENTRA_ROLE_READONLY = os.environ.get("ENTRA_ROLE_READONLY", "IPAM.ReadOnly")
    ENTRA_GROUP_ADMIN = os.environ.get("ENTRA_GROUP_ADMIN", "")            # group Object IDs (GUIDs), comma-separated
    ENTRA_GROUP_READWRITE = os.environ.get("ENTRA_GROUP_READWRITE", "")
    ENTRA_GROUP_READONLY = os.environ.get("ENTRA_GROUP_READONLY", "")
    # Comma-separated sign-in names (UPN/email) that are always IPAM admins, whatever the roles/groups say.
    ENTRA_ADMIN_USERS = [u.strip().lower() for u in os.environ.get("ENTRA_ADMIN_USERS", "").split(",") if u.strip()]
    # true: signed-in users with no matching role/group are refused. false: they get read-only.
    ENTRA_REQUIRE_ROLE = os.environ.get("ENTRA_REQUIRE_ROLE", "false").lower() == "true"
    # Keep the username/password form on the login page (break-glass local admin). /login?local=1 always shows it.
    ENTRA_LOCAL_LOGIN = os.environ.get("ENTRA_LOCAL_LOGIN", "true").lower() == "true"

    # Which DNS domain a server's name lives in, by its Environment (one "environment=domain" per line).
    # Editable in Administration > DNS Import. Only domains whose zone has been imported are used.
    DNS_ENV_DOMAINS = os.environ.get("DNS_ENV_DOMAINS", "Prod Colo=prod.local\nAzure=prod.local\nQA=qa.local").replace("\\n", "\n")

    # API
    API_TOKEN_EXPIRY = timedelta(days=int(os.environ.get("API_TOKEN_EXPIRY_DAYS", "30")))


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = _build_db_url("mysql+pymysql://ipam:ipam@localhost/ipam_dev")
    SESSION_COOKIE_SECURE = False


class ProductionConfig(BaseConfig):
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = _build_db_url("")
    # Browsers drop "Secure" cookies on plain-http pages, which breaks login. install.sh --no-ssl
    # (browsing by http://IP) writes SESSION_COOKIE_SECURE=false; leave it true whenever HTTPS is used.
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "true").lower() != "false"

    @classmethod
    def init_app(cls, app):
        if not cls.SQLALCHEMY_DATABASE_URI:
            raise RuntimeError("DATABASE_URL environment variable must be set in production")


class TestingConfig(BaseConfig):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": ProductionConfig,
}
